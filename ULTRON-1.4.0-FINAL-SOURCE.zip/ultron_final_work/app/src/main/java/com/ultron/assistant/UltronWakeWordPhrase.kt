package com.ultron.assistant

import java.util.Locale

/** Merges OEM speech-recognizer hypotheses without dispatching incomplete partial results. */
object UltronWakeWordPhrase {
    private val canonicalWakeTokens = setOf("ultron", "अल्ट्रॉन", "अल्ट्रोन")

    /**
     * Match a complete wake token. `ultra` is a narrow first-word/greeting fallback for
     * providers that truncate the final consonant; it is not accepted as an arbitrary
     * mid-sentence word (for example, "please use ultra settings").
     */
    fun containsWakeWord(value: String): Boolean = wakeTokenIndex(normalize(value)) != null

    /** Returns the words after a complete wake token, or null when none was recognized. */
    fun commandAfterWakeWord(value: String): String? {
        val tokens = normalize(value)
        val index = wakeTokenIndex(tokens) ?: return null
        return tokens.drop(index + 1).joinToString(" ").ifBlank { "" }
    }

    fun bestPhrase(partial: String, final: String): String {
        val p = partial.trim()
        val f = final.trim()
        if (f.isBlank()) return p
        if (p.isBlank()) return f
        if (containsWakeWord(p) && !containsWakeWord(f)) return mergeOverlappingWords(p, f)
        return if (p.length > f.length) p else f
    }

    private fun normalize(value: String): List<String> = value.lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9\\u0900-\\u097f]+"), " ")
        .trim()
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }

    private fun wakeTokenIndex(tokens: List<String>): Int? {
        val canonical = tokens.indexOfFirst { it in canonicalWakeTokens }
        if (canonical >= 0) return canonical
        if (tokens.firstOrNull() == "ultra") return 0
        if (tokens.size > 1 && tokens[0] in setOf("hey", "hello") && tokens[1] == "ultra") return 1
        return null
    }

    private fun mergeOverlappingWords(first: String, second: String): String {
        val left = first.split(Regex("\\s+")).filter { it.isNotBlank() }
        val right = second.split(Regex("\\s+")).filter { it.isNotBlank() }
        val maxOverlap = minOf(left.size, right.size)
        val overlap = (maxOverlap downTo 1).firstOrNull { count ->
            left.takeLast(count).map { it.lowercase(Locale.ROOT) } == right.take(count).map { it.lowercase(Locale.ROOT) }
        } ?: 0
        return (left + right.drop(overlap)).joinToString(" ")
    }
}
