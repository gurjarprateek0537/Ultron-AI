package com.ultron.assistant

import java.nio.charset.Charset
import java.security.MessageDigest
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** A compact description of the environment. Raw screen content is deliberately not retained. */
data class UltronWorldSnapshot(
    val packageName: String?,
    val screenGeneration: Long,
    val fingerprint: String,
    val visibleTokens: Set<String>,
    val observedAtMillis: Long = System.currentTimeMillis()
) {
    companion object {
        private val sensitivePatterns = listOf(
            Regex("(?i)\\b(?:otp|one[- ]time password|verification code|passcode)\\b[^\\d]{0,20}\\d{4,8}"),
            Regex("(?i)\\b(?:password|passphrase|secret|recovery code)\\s*[:=]?\\s*\\S+"),
            Regex("(?<!\\d)\\d{6}(?!\\d)"),
            Regex("\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b", RegexOption.IGNORE_CASE),
            Regex("(?<!\\w)\\+?[0-9][0-9 ()-]{7,}[0-9](?!\\w)")
        )

        fun fromScreen(packageName: String?, description: String, observedAtMillis: Long = System.currentTimeMillis()): UltronWorldSnapshot {
            val generation = Regex("(?:\\[screen_generation=|\\bgeneration=)(\\d+)").find(description)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: -1L
            val redacted = sensitivePatterns.fold(description) { value, regex -> regex.replace(value, "[private]") }
            val stable = UltronScreenFingerprint.stableDescription(redacted)
            val normalized = stable.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
            val tokens = normalized.split(Regex("\\s+")).asSequence()
                .filter { it.length >= 3 && it !in STOP_WORDS }
                .take(160).toSet()
            val digest = MessageDigest.getInstance("SHA-256")
                .digest("${packageName.orEmpty()}|$normalized".toByteArray(Charset.forName("UTF-8")))
                .take(12).joinToString("") { "%02x".format(it) }
            return UltronWorldSnapshot(packageName, generation, digest, tokens, observedAtMillis)
        }

        private val STOP_WORDS = setOf("the", "and", "for", "with", "this", "that", "from", "your", "you", "are", "was", "not", "but", "has", "have", "app", "button", "text", "view", "image", "clickable")
    }
}

enum class UltronTransitionExpectation { LIKELY, UNLIKELY, UNKNOWN }
enum class UltronActionRisk { LOW, MODERATE, HIGH, COMMITMENT }

data class UltronActionPrediction(
    val actionType: String,
    val sourcePackage: String?,
    val expectedTransition: UltronTransitionExpectation,
    val expectedPackageChange: Boolean,
    val risk: UltronActionRisk,
    val reversible: Boolean,
    val confidence: Float,
    val rationale: String
)

data class UltronWorldEvaluation(
    val transitionObserved: Boolean,
    val packageChanged: Boolean,
    val predictionAligned: Boolean?,
    val confidenceAfterObservation: Float,
    val explanation: String
)

/** Hybrid world model: deterministic transition priors plus measured screen deltas and confidence. */
object UltronWorldModel {
    private val likelyTransitions = setOf("open_app", "open_url", "home", "back", "click_text", "submit_search", "search_in_app", "scroll", "swipe", "tap", "double_tap", "long_press_text", "drag", "type_text")
    private val unlikelyTransitions = setOf("wait", "wait_for_text", "find_text_on_screen", "read_screen", "set_volume_percent", "adjust_volume", "set_brightness_percent", "adjust_brightness", "set_flashlight", "media_control")
    private val commitmentActions = setOf("call", "compose_whatsapp", "compose_sms", "send_message", "run_plugin_publish", "purchase", "payment", "delete_permanently", "factory_reset")
    private val moderateActions = setOf("lock_screen", "wake_screen", "open_power_menu", "open_quick_settings", "open_notifications", "open_recent_apps", "set_brightness_percent", "set_flashlight")

    fun predict(actionType: String, sourcePackage: String?): UltronActionPrediction {
        val type = actionType.lowercase(Locale.ROOT)
        val expectation = when (type) {
            in likelyTransitions -> UltronTransitionExpectation.LIKELY
            in unlikelyTransitions -> UltronTransitionExpectation.UNLIKELY
            else -> UltronTransitionExpectation.UNKNOWN
        }
        val risk = when {
            type in commitmentActions -> UltronActionRisk.COMMITMENT
            type in moderateActions -> UltronActionRisk.MODERATE
            type in setOf("delete", "share", "publish", "run_plugin") -> UltronActionRisk.HIGH
            else -> UltronActionRisk.LOW
        }
        val reversible = type in setOf("wait", "open_app", "open_url", "back", "home", "scroll", "swipe", "set_volume_percent", "adjust_volume", "set_brightness_percent", "adjust_brightness", "set_flashlight", "media_control")
        return UltronActionPrediction(
            actionType = type,
            sourcePackage = sourcePackage,
            expectedTransition = expectation,
            expectedPackageChange = type in setOf("open_app", "open_url", "home"),
            risk = risk,
            reversible = reversible,
            confidence = when (expectation) { UltronTransitionExpectation.LIKELY -> 0.72f; UltronTransitionExpectation.UNLIKELY -> 0.78f; UltronTransitionExpectation.UNKNOWN -> 0.35f },
            rationale = when (expectation) {
                UltronTransitionExpectation.LIKELY -> "This action commonly changes the visible UI; refresh the screen before using further targets."
                UltronTransitionExpectation.UNLIKELY -> "This action usually changes device state without changing the current app screen."
                UltronTransitionExpectation.UNKNOWN -> "There is not enough execution history to predict the visible result reliably."
            }
        )
    }

    fun evaluate(prediction: UltronActionPrediction, before: UltronWorldSnapshot, after: UltronWorldSnapshot, dispatched: Boolean, verified: Boolean): UltronWorldEvaluation {
        val transition = before.packageName != after.packageName || before.fingerprint != after.fingerprint
        val packageChanged = before.packageName != after.packageName
        val aligned: Boolean? = when (prediction.expectedTransition) {
            UltronTransitionExpectation.LIKELY -> transition
            UltronTransitionExpectation.UNLIKELY -> !transition
            UltronTransitionExpectation.UNKNOWN -> null
        }
        val confidence = when {
            !dispatched -> 0.95f
            verified -> 0.98f
            aligned == true -> min(0.92f, prediction.confidence + 0.16f)
            aligned == false -> max(0.18f, prediction.confidence - 0.22f)
            else -> max(0.25f, prediction.confidence - 0.08f)
        }
        val explanation = when {
            !dispatched -> "Action was not dispatched; no environment transition is attributed to it."
            verified -> "Executor reported a verified result; observed state is recorded as verified evidence."
            aligned == true -> "Observed screen transition matched the model's expected transition pattern."
            aligned == false -> "Observed screen transition differed from the model's prior; future confidence is reduced."
            else -> "Action was dispatched, but available observations do not establish its final effect."
        }
        return UltronWorldEvaluation(transition, packageChanged, aligned, confidence, explanation)
    }
}

enum class UltronFeedbackOutcome { VERIFIED_SUCCESS, DISPATCHED_UNVERIFIED, FAILED, BLOCKED, CANCELLED }

data class UltronActionFeedback(
    val packageName: String?,
    val actionType: String,
    val outcome: UltronFeedbackOutcome,
    val verified: Boolean,
    val durationMillis: Long,
    val strategyKey: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val recoveryUsed: Boolean = false
)

data class UltronStrategyScore(
    val strategyKey: String,
    val samples: Int,
    val verifiedSuccesses: Int,
    val unverifiedDispatches: Int,
    val failures: Int,
    val score: Float
)

/** Feedback learns strategy reliability only from execution reports; it never trains a live policy. */
class UltronFeedbackLearning(initial: List<UltronActionFeedback> = emptyList(), private val maximumRecords: Int = 240) {
    private val records = initial.takeLast(maximumRecords).toMutableList()

    @Synchronized fun record(feedback: UltronActionFeedback) {
        records += feedback.copy(actionType = feedback.actionType.take(48), strategyKey = feedback.strategyKey.take(96), durationMillis = feedback.durationMillis.coerceAtLeast(0))
        while (records.size > maximumRecords) records.removeAt(0)
    }

    @Synchronized fun recent(limit: Int = 20): List<UltronActionFeedback> = records.toList().takeLast(limit.coerceIn(1, maximumRecords))

    @Synchronized fun score(strategyKey: String): UltronStrategyScore {
        val matching = records.filter { it.strategyKey == strategyKey }
        val verified = matching.count { it.outcome == UltronFeedbackOutcome.VERIFIED_SUCCESS && it.verified }
        val dispatched = matching.count { it.outcome == UltronFeedbackOutcome.DISPATCHED_UNVERIFIED }
        val failures = matching.count { it.outcome == UltronFeedbackOutcome.FAILED || it.outcome == UltronFeedbackOutcome.BLOCKED }
        val samples = matching.size
        val raw = if (samples == 0) 0.5f else (verified * 1.0f + dispatched * 0.45f + 0.25f) / (samples + 0.5f)
        return UltronStrategyScore(strategyKey, samples, verified, dispatched, failures, raw.coerceIn(0f, 1f))
    }

    @Synchronized fun summary(packageName: String?, limit: Int = 6): String {
        val items = records.filter { packageName == null || it.packageName == packageName }
            .map { it.strategyKey }.distinct().takeLast(limit.coerceIn(1, 12))
            .map { key ->
                val strategy = score(key)
                "${key}: verified ${strategy.verifiedSuccesses}/${strategy.samples}, failures ${strategy.failures}, score ${"%.2f".format(Locale.US, strategy.score)}"
            }
        return items.joinToString("\n").take(1_200)
    }
}

/** Compact persistent task metadata. Sensitive user text/action payloads are stored encrypted by the Android store. */
data class UltronPersistentTaskState(
    val taskId: String,
    val objectiveCiphertext: String,
    val packageName: String?,
    val selectedRoles: List<String>,
    val completedActionTypes: List<String>,
    val plannedActionCount: Int,
    val status: String,
    val updatedAtMillis: Long = System.currentTimeMillis(),
    val controlRequest: String = "none"
)

data class UltronKnowledgeNode(val id: String, val kind: String, val label: String, val updatedAtMillis: Long = System.currentTimeMillis())
data class UltronKnowledgeEdge(val fromId: String, val relation: String, val toId: String, val confidence: Float = 0.5f, val updatedAtMillis: Long = System.currentTimeMillis())

/** Small explicit knowledge graph; callers decide what is safe and useful to store. */
class UltronKnowledgeGraph(initialNodes: List<UltronKnowledgeNode> = emptyList(), initialEdges: List<UltronKnowledgeEdge> = emptyList(), private val maxNodes: Int = 300, private val maxEdges: Int = 600) {
    private val nodes = LinkedHashMap<String, UltronKnowledgeNode>()
    private val edges = LinkedHashMap<String, UltronKnowledgeEdge>()
    init { initialNodes.takeLast(maxNodes).forEach { nodes[it.id] = it }; initialEdges.takeLast(maxEdges).forEach { edges[edgeKey(it)] = it } }

    @Synchronized fun putNode(node: UltronKnowledgeNode) {
        require(node.id.matches(Regex("[A-Za-z0-9_.:-]{1,120}")))
        require(node.kind.length in 1..40 && node.label.length <= 160)
        nodes[node.id] = node
        while (nodes.size > maxNodes) nodes.remove(nodes.keys.first())
    }

    @Synchronized fun link(edge: UltronKnowledgeEdge) {
        require(edge.relation.matches(Regex("[a-z_]{2,40}")))
        require(nodes.containsKey(edge.fromId) && nodes.containsKey(edge.toId))
        edges[edgeKey(edge)] = edge.copy(confidence = edge.confidence.coerceIn(0f, 1f))
        while (edges.size > maxEdges) edges.remove(edges.keys.first())
    }

    @Synchronized fun related(nodeId: String, limit: Int = 20): List<Pair<UltronKnowledgeEdge, UltronKnowledgeNode>> = edges.values
        .filter { it.fromId == nodeId || it.toId == nodeId }
        .take(limit.coerceIn(1, 50))
        .mapNotNull { edge -> nodes[if (edge.fromId == nodeId) edge.toId else edge.fromId]?.let { edge to it } }

    @Synchronized fun nodes(): List<UltronKnowledgeNode> = nodes.values.toList()
    @Synchronized fun edges(): List<UltronKnowledgeEdge> = edges.values.toList()
    private fun edgeKey(edge: UltronKnowledgeEdge) = "${edge.fromId}|${edge.relation}|${edge.toId}"
}

data class UltronResourceBudget(val maxSpecialists: Int, val maxParallelCalls: Int, val maxOutputTokens: Int, val deadlineMillis: Long, val allowVisionCall: Boolean, val rationale: String)

/** Cost-aware orchestration budgets prevent unnecessary calls and keep UI control responsive. */
object UltronAgentResourceManager {
    fun budget(request: String, hasScreen: Boolean, hasVision: Boolean, batteryConstrained: Boolean = false, networkAvailable: Boolean = true): UltronResourceBudget {
        val text = request.lowercase(Locale.ROOT)
        val complex = listOf("then", "after that", "and then", "across", "compare", "research", "multiple", "every", "all", "compound", "workflow").any { text.contains(it) } || request.length > 180
        val specialists = when { batteryConstrained -> if (complex) 8 else if (hasScreen) 7 else 4; complex -> 12; hasVision -> 11; hasScreen -> 10; else -> 5 }
        val tokens = when { batteryConstrained -> 256; complex && networkAvailable -> 640; complex -> 384; else -> 256 }
        return UltronResourceBudget(
            maxSpecialists = specialists,
            maxParallelCalls = if (batteryConstrained) 1 else if (complex) 3 else 2,
            maxOutputTokens = tokens,
            deadlineMillis = if (batteryConstrained) 25_000L else if (complex) 60_000L else 30_000L,
            allowVisionCall = hasVision && hasScreen && !batteryConstrained,
            rationale = when { batteryConstrained -> "Battery-aware budget: reduced parallel work and output size."; !networkAvailable -> "Offline budget: use local reasoning and avoid remote specialist calls."; complex -> "Complex-task budget: allow focused specialist analysis and dependency planning."; else -> "Fast-path budget: use a small team and concise output." }
        )
    }
}

/** Allow-listed structured functions. Descriptors are metadata; actual execution stays in the single Android executor. */
data class UltronFunctionContract(val name: String, val requiredFields: Set<String>, val capability: String, val risk: UltronActionRisk, val description: String)
object UltronFunctionCatalog {
    val contracts = listOf(
        UltronFunctionContract("inspect_screen", emptySet(), "SCREEN_ACCESSIBILITY", UltronActionRisk.LOW, "Read a fresh semantic screen snapshot."),
        UltronFunctionContract("launch_app", setOf("app"), "APP_LAUNCH", UltronActionRisk.LOW, "Launch an installed application."),
        UltronFunctionContract("tap_text", setOf("text"), "SCREEN_ACCESSIBILITY", UltronActionRisk.MODERATE, "Tap one visible, freshly inspected UI target."),
        UltronFunctionContract("type_text", setOf("text"), "SCREEN_ACCESSIBILITY", UltronActionRisk.MODERATE, "Enter text into the focused field after target validation."),
        UltronFunctionContract("search_app", setOf("query"), "SCREEN_ACCESSIBILITY", UltronActionRisk.LOW, "Search within the currently visible application."),
        UltronFunctionContract("set_volume", setOf("percent"), "DEVICE_AUDIO", UltronActionRisk.LOW, "Set media volume and read back actual level."),
        UltronFunctionContract("verify_screen", emptySet(), "SCREEN_ACCESSIBILITY", UltronActionRisk.LOW, "Compare fresh screen state with the expected result."),
        UltronFunctionContract("request_approval", setOf("action", "target", "payload_hash"), "USER_APPROVAL", UltronActionRisk.COMMITMENT, "Request explicit approval bound to one exact sensitive action.")
    )
    fun find(name: String): UltronFunctionContract? = contracts.firstOrNull { it.name == name }
}

/** Typed MCP/A2A contracts. Transports/adapters can be added later without letting protocol messages execute phone actions. */
data class UltronMcpToolDescriptor(val name: String, val description: String, val inputSchema: Map<String, String>, val capability: String)
data class UltronMcpCallRequest(val requestId: String, val toolName: String, val arguments: Map<String, String>, val issuedAtMillis: Long = System.currentTimeMillis())
data class UltronMcpCallResult(val requestId: String, val success: Boolean, val content: String, val errorCode: String? = null)
data class UltronMcpResourceDescriptor(val uri: String, val mimeType: String, val description: String)
data class UltronMcpPromptDescriptor(val name: String, val description: String, val argumentNames: List<String>)
interface UltronMcpConnector {
    suspend fun listTools(): List<UltronMcpToolDescriptor>
    suspend fun callTool(request: UltronMcpCallRequest): UltronMcpCallResult
}

data class UltronA2AAgentCard(val agentId: String, val displayName: String, val skills: List<String>, val protocolVersion: String = "1.0")
data class UltronA2ATaskEnvelope(val taskId: String, val fromAgent: String, val toAgent: String, val objective: String, val contextFingerprint: String, val deadlineMillis: Long)
data class UltronA2AMessage(val taskId: String, val sender: String, val recipient: String, val messageType: String, val payload: Map<String, String>, val sequence: Long)

data class UltronDiagnosticEvent(val code: String, val component: String, val durationMillis: Long = 0L, val success: Boolean, val timestampMillis: Long = System.currentTimeMillis())
object UltronDiagnosticCodes {
    const val PLAN_CREATED = "plan_created"
    const val ACTION_VERIFIED = "action_verified"
    const val ACTION_UNVERIFIED = "action_unverified"
    const val ACTION_FAILED = "action_failed"
    const val SCREEN_REPLANNED = "screen_replanned"
    const val RECOVERY_USED = "recovery_used"
    const val APPROVAL_BLOCKED = "approval_blocked"
    const val TASK_COMPLETED = "task_completed"
    const val WORLD_PREDICTION_MISMATCH = "world_prediction_mismatch"
}
