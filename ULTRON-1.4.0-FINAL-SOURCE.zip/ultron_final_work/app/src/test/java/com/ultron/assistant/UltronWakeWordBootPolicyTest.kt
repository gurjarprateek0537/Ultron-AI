package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UltronWakeWordBootPolicyTest {
    @Test fun wakeWordMatcherAcceptsCommonRecognizerTruncation() {
        assertTrue(UltronWakeWordPhrase.containsWakeWord("ultron open Instagram"))
        assertTrue(UltronWakeWordPhrase.containsWakeWord("ultra open Instagram"))
        assertTrue(UltronWakeWordPhrase.containsWakeWord("hey ultra open Instagram"))
        assertTrue(UltronWakeWordPhrase.containsWakeWord("अल्ट्रॉन खोलो"))
        assertFalse(UltronWakeWordPhrase.containsWakeWord("ultraviolet open Instagram"))
        assertFalse(UltronWakeWordPhrase.containsWakeWord("ultronic open Instagram"))
        assertFalse(UltronWakeWordPhrase.containsWakeWord("please use ultra settings"))
        assertEquals("open instagram", UltronWakeWordPhrase.commandAfterWakeWord("ULTRON, open Instagram"))
        assertEquals("", UltronWakeWordPhrase.commandAfterWakeWord("Hey Ultron"))
    }

    @Test fun microphoneServiceCanOnlyAutostartAtBootBeforeAndroid14() {
        assertFalse(UltronWakeWordPreferences.requiresUserResumeAfterBoot(26))
        assertFalse(UltronWakeWordPreferences.requiresUserResumeAfterBoot(33))
        assertTrue(UltronWakeWordPreferences.requiresUserResumeAfterBoot(34))
        assertTrue(UltronWakeWordPreferences.requiresUserResumeAfterBoot(35))
        assertTrue(UltronWakeWordPreferences.requiresUserResumeAfterBoot(36))
    }
}
