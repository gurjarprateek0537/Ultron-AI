# ULTRON 1.4 — Source delivery and verification audit

## Contents and scope

This release is based on the supplied 1.4.1 source archive. It preserves the application tree and adds a targeted safety-classification fix. Android `versionName` is `1.4` and `versionCode` remains `29`. This is source code, not a compiled APK.

## Changes in this release

1. Excludes read-only history destinations from the broad sensitive-label match, including `Purchase history` and related history labels.
2. Keeps explicit approval for commit controls such as `Purchase`, `Purchase now`, `Confirm purchase`, `Pay now`, `Place order`, `Send`, `Delete account`, and `Publish now`.
3. Removes the duplicate commitment-label regex from `UltronActionSimulation.kt`; preflight simulation delegates to `UltronAgentSafetyPolicy`, the same policy used by the executor.
4. Adds regression tests in `UltronAgentSafetyPolicyTest.kt` and `UltronActionSimulationTest.kt`.
5. Aligns app version name and CI artifact names with the requested `1.4` label.

## Checks actually run in this environment

- Base archive extraction and original ZIP integrity check completed before editing (152 entries; no ZIP corruption reported).
- Kotlin/JVM compiler `kotlinc 1.9.0` compiled a harness containing the exact safety-policy object extracted from `UltronAgentEngine.kt`.
- The harness passed 11 sensitive commit labels, 15 read-only/ordinary labels, direct-call approval, ordinary typing exclusion, and GET-vs-POST plugin approval checks.
- Source inspection confirmed that the action simulator now uses the same safety-policy function as the executor.
- The packaged Android project configuration was reviewed: app `versionName = 1.4`, `versionCode = 29`, Kotlin 2.0.21, Android Gradle Plugin 8.7.3, Room 2.6.1 through KAPT, compile/target SDK 35, minSdk 26, NDK 27.2.12479018, and CMake 3.22.1.

## Not run / not certified

- Full `:app:testDebugUnitTest` and `:app:assembleDebug` were not run: Gradle and Android SDK/NDK are not installed in this environment.
- The newly edited Android JUnit tests were not run through Gradle. The standalone harness validates the policy behavior but is not a substitute for the complete test suite.
- No new GitHub Actions run was triggered; no green CI result is claimed.
- No APK was assembled or installed. No physical-device test was run on OPPO CPH1803 / Android 8.1 / ColorOS.
- Wake-word recognition, background-service survival, app-by-app automation, notification workflows, device controls and all permissions remain subject to runtime/device verification.

## Feature completeness statement

The source contains the feature modules described in `IMPLEMENTATION_STATUS.md`. Some are foundations or partial implementations, not complete production systems. Specifically, universal UI automation is constrained by Accessibility exposure and protected screens; speech recognition is not a dedicated acoustic wake detector; the 28 specialist roles share three configured model profiles; MCP/A2A transports, an isolated code sandbox, public plugin marketplace, complete notification digest and full on-device APK-building pipeline are not present. Do not interpret feature modules or source-level tests as proof that every feature works on every app or device.

**Release status:** patched source archive; targeted Kotlin/JVM safety-policy harness passed; complete Android CI build and physical-device verification remain pending.
