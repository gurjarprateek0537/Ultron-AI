# ULTRON 1.4 — Implementation Status and Honest Boundaries

This source tree retains the 1.1.0 lineage and the 1.2.0–1.3.0 upgrades, with the 1.4.0 screen-state and wake-service reliability updates, the 1.4.1 Gradle build-resolution fix, and the 1.4 approval-policy regression fix. “Implemented” means source code exists; it does not imply every Android OEM/app path was runtime-tested.

## Implemented in source

- **Android screen automation:** user-enabled Accessibility service; bounded breadth-first semantic screen snapshots; interactive node prioritization; fresh node lookup for each action; clicks, focused text entry, search, long press, scroll, swipe, tap, double tap and drag; Android global navigation/system actions where supported.
- **Closed-loop execution:** dependency-aware bounded plans; preflight action vocabulary/capability simulation; fresh observations around meaningful actions; app/window transition checks; settle waits; adaptive replanning (bounded); one safe recovery path; pause/resume/cancel at action boundaries; persistent encrypted task checkpoints; action reports that distinguish accepted from independently verified operations.
- **Screen observation:** semantic Accessibility text; optional user-approved MediaProjection capture and on-device Latin/Devanagari OCR; `wait_for_text`; bounded local OCR fallback for finding text and tapping one unambiguous target after a fresh-screen stale-coordinate check; duplicate equally ranked Accessibility labels fail closed; screen fingerprints that ignore event-generation and IME metadata; local redaction for likely private values.
- **Wake-word service:** opt-in foreground microphone service; Android SpeechRecognizer provider; partial/final result handling; recognizer watchdog; bounded recovery/backoff; stale-callback suppression; notification and in-app health diagnostics; boot restoration where OS rules permit.
- **AI models/agents:** separate General, Vision and Coding profile routing; central General task planner; Vision profile for consented image/screen analysis; Coding profile for developer tasks; 28 logical specialist roles selected on demand; a single authoritative Android action executor; shared task/feedback/world-model state.
- **World and feedback models:** redacted screen fingerprints, heuristic transition priors, outcome comparison, strategy reliability scoring from verified/failed execution feedback, app/screen knowledge graph and bounded diagnostics.
- **Device and productivity controls:** supported volume/brightness/torch/media/navigation controls, alarm intents, notification-access helper, safe clipboard preview, network diagnostics, user-selected SAF folder browsing, encrypted routine definitions and WorkManager scheduling, local imported-document retrieval, browser, memory, plugin/skill contracts and project-file workspace.
- **Safety:** sensitive external commitments require explicit confirmation, including Send/Delete/Pay/Buy/Order/Transfer/Publish/Share commit controls; read-only purchase/order/payment history labels are excluded; the executor and preflight simulator share the same classifier; pending approvals/history/task text are stored in app-private encrypted storage where implemented; secret-like entry fields are not auto-filled; screen data is treated as untrusted; no arbitrary shell execution or downloaded plugin code loading.
- **Existing product assets:** Compose UI, avatar/hero image, voice GIF, native llama.cpp bridge and existing source assets are retained.

## Partial, dependent or not fully implemented

- **Universal UI automation:** the action framework is app-agnostic, but success depends on target UI exposure. There is no guarantee for every app, page, WebView, game, secure window, DRM surface, banking screen, lock screen or OEM system panel. Some apps require visual evidence or manual intervention.
- **Wake-word accuracy:** SpeechRecognizer is a speech transcription provider, not a dedicated acoustic wake-word detector. The service has lifecycle/recovery improvements but its false-negative/false-positive rate cannot be certified without the target phone and the installed recognition provider. ColorOS may stop background services unless the user configures autostart/battery settings.
- **Multi-agent model usage:** the 28 roles are logical specialists, not 28 independent LLM processes. They share configured General/Vision/Coding profiles. Vision is only invoked when configured and user consent allows relevant screen/image sharing. Full dynamic swarm execution is not present.
- **MCP/A2A:** typed schemas/contracts exist; no production remote MCP transport, discovery, authentication or A2A peer mesh is configured.
- **Memory/retrieval:** imported documents use local lexical/BM25-style retrieval, not a full embedding/vector database or comprehensive document knowledge graph.
- **Learning:** strategy scoring uses verified feedback; no online reinforcement-learning training or model weight updates occur.
- **Notification intelligence:** opt-in active notification reading/counting and privacy filtering exist; a complete background digest, priority classifier, universal inline reply and notification-management agent are not fully implemented.
- **Clipboard/file workflows:** safe clipboard preview and SAF browsing/checksum helpers exist; fully automatic cross-app clipboard pipelines, duplicate-file cleanup and destructive file operations remain limited.
- **Routines:** WorkManager one-shot/periodic dispatch is present; Android Doze, OEM battery policy, force-stop and minimum periodic interval can delay or prevent exact-time execution. Routine conditions are not a full event/condition engine.
- **App builder:** the app-private project workspace stores declarative generated files, but there is no on-device full IDE, build sandbox/remote compiler, APK signer or installer pipeline.
- **Local multimodal vision:** local OCR is present; image understanding still depends on configured online Vision AI for general visual reasoning. The bundled local llama.cpp runtime is text-only unless an appropriate multimodal runtime/model is separately integrated.
- **Plugin marketplace/security:** HTTPS/API plugin and skill contracts are present, but there is no signed public marketplace or process-isolated third-party code sandbox. Arbitrary downloaded code is not executed.

## Device-specific note: OPPO CPH1803 / Android 8.1

The phone meets the declared minSdk 26. To use general app control, manually enable ULTRON in Android Accessibility settings. To use local OCR below Android 11, start Screen Awareness and approve the Android MediaProjection prompt. Grant microphone permission and explicitly arm the wake listener. ColorOS may also require the user to enable ULTRON in Auto-launch, remove battery restrictions, permit background activity and retain the persistent notification. This cannot be configured silently by the app.

## Verification performed for 1.4.0 source

- Kotlin/JVM compiler (`kotlinc`) successfully compiled the pure core files: `UltronScreenFingerprint.kt`, `UltronWorldModel.kt`, `UltronActionSimulation.kt`, `UltronWakeWordPhrase.kt`.
- A standalone smoke harness passed wake-token matching, substring false-positive rejection, screen fingerprint stability across accessibility counter/IME diagnostic changes, genuine hierarchy-change detection and preflight acceptance checks.
- Gradle is not installed in this authoring environment; `ANDROID_HOME`/`ANDROID_SDK_ROOT` are unset and no Android SDK was found. Therefore the full Android/Compose/KAPT/NDK/JUnit build was not run and no APK was assembled.
- No emulator or OPPO CPH1803 physical-device tests were run. Accessibility event behavior, microphone wake accuracy, ColorOS background survival and actual app-specific UI paths remain unverified.


## 1.4.1 build repair

GitHub Actions run #32 was inspected directly. It failed during Gradle plugin resolution for KSP before compiling project source; the debug APK task was consequently skipped. Version 1.4.1 switches Room code generation to Kotlin KAPT 2.0.21. The repaired archive has not yet been run through GitHub Actions, so this change is a targeted build fix and not a claim of a green CI build. See `BUILD_FIX_1.4.1.md`.
