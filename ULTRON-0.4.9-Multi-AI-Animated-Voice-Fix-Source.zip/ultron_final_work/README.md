# ULTRON — Android Assistant Source

**Design:** crimson red + charcoal/black, restrained orange and minimal purple. Kotlin + Jetpack Compose, min SDK 26, compile/target SDK 35, Java 17.

This is an implementation-focused personal-use Android project. It includes real features in the source, but it is **not yet the fully completed assistant**: see the “Known missing work” section before treating the APK as finished.

## Implemented in this source

- **Compose chat UI** with villain-style crimson/black Compose UI, dashboard AI selector, multi-profile online/local provider setting, speech-recognition launcher, Android TextToSpeech, import action, and Permission Center.
- **Online inference adapter** for `POST {baseUrl}/chat/completions` using the OpenAI-compatible `model`, `messages`, and `stream: false` request format. HTTP errors are surfaced to the user; no fabricated answer is returned. The intended online host is the user-configured InstaBox gateway; the client does not hard-code another provider.
- **API token at rest:** new saves are AES-GCM encrypted with a non-exportable Android Keystore key. A legacy plain token from an earlier build is migrated where the keystore operation succeeds. For public apps, a restricted backend proxy is still the recommended architecture.
- **Private app database (Room):** persistent chat records, user-approved memories, notes, and extracted-document text. Chat transcript records older than three days are pruned on app start and by a periodic WorkManager job; saved facts, notes, and documents persist until deleted by the user.
- **On-device document extraction:** file picker supports text/Markdown/JSON/XML, images and PDFs. ML Kit extracts Latin and Devanagari text; PDFs are rendered and OCRed locally up to 20 pages. Imported material is stored in the private app database, and lexical matching adds small relevant excerpts to subsequent LLM prompts. Unsupported formats produce an error.
- **Explicit command routing:** `remember that …`, `what do you remember?`, `forget all memory`, `note: …`, `show notes`, `show documents`, `remind me in 10 minutes to …`, time/date/battery queries, flashlight on/off (camera permission and hardware required), media volume up/down/mute, web search, common app/site shortcuts, Wi-Fi/Bluetooth/location/display/notification/accessibility/alarms settings pages, and notification-count query.
- **Opt-in accessibility helper:** after the user explicitly enables the Accessibility Service, commands `read screen`, `click <visible label>`, and `scroll up/down` attempt supported actions. This service does not record content in the background. Check the active app to verify every action.
- **Biometric/device-credential app lock:** optional app gate backed by AndroidX BiometricPrompt. Android 11+ accepts strong biometrics or device credential; older releases require an enrolled biometric. The app re-locks after it leaves the foreground. This is an app screen lock, not a replacement for Android's lock screen.
- **More device actions:** `call <number>` opens the system dialer without placing a call; `sms <number>: <message>` opens the system SMS composer without sending; `open <app name>` attempts to find and launch an installed launcher app by its visible name.
- **Opt-in wake-word service:** foreground notification and continuous recognition for “Ultron”. It uses on-device recognition where supported and the installed Android recognizer on older Android versions; it can capture a follow-up command and send it to the command router.
- **Multi-AI profiles:** users can add named OpenAI-compatible profiles (for example Coding or Vision) with independent URL, model ID and encrypted API key. The dashboard selector switches active profiles. All-in-One gathers parallel answers, requests peer reviews, and synthesizes a final answer when at least two profiles are available.
- **Offline Model Vault:** separate from online profiles. Users can enable local inference, paste a direct HTTPS GGUF asset URL to download, import/replace GGUF files, or delete the local model. No RAM-based model tier or automatic model substitution.
- **Website plugin hub:** built-in YouTube, Google, Wikipedia, GitHub and Stack Overflow search routes plus user-added HTTPS URL templates. Custom commands support `search <query> on <plugin name>` and `open <plugin name>`.
- **Permission center:** live status checks and links to Android permission/special access pages for camera, microphone, location, contacts, calls, notifications, accessibility, notification-listener access, legacy device admin, overlay, battery optimization, DND access, exact alarms, and app permissions.
- **Reminder receiver:** posts a reminder notification when permitted and schedules exact alarms only when Android grants exact-alarm access; otherwise it uses Android's inexact alarm API.
- **CI workflow:** GitHub Actions installs Gradle 8.9 and Android SDK platform 35, runs unit tests, attempts a debug APK build, and uploads the APK artifact only if that build succeeds.

## What is still not implemented (important)

- **Vision profile limitation:** online Vision profiles can be configured and selected, but the current chat message schema does not yet transmit image bytes as multimodal input. Camera/OCR support must not be mistaken for a complete vision-language model pipeline.
- **Plugin limitation:** the current plugin hub supports website URL templates; OAuth accounts, authenticated third-party app integrations and arbitrary plugin SDKs are not included.
- The current OCR runs on user-selected images/PDF pages. It is not a live camera vision detector, object detector, full-screen VLM, or image segmentation system.
- Wake-word support depends on the installed Android speech service and needs real-device endurance, battery, background and false-trigger testing. On older Android versions the offline preference is not a guarantee of offline speech recognition. It is not a dedicated acoustic wake-word model or speaker identification.
- Notification access only reports a count and does not read or save message contents. Remote messaging commands, camera/microphone/location capture from remote requests, speaker profiles, and hidden background upload are not implemented.
- No generalized automation agent, arbitrary 250+ command catalog, 1,200 Easter-egg database, custom animated avatar, draggable floating overlay widget, live camera object detector/VLM, background geofence reminders, scam detector, call-log reader, WhatsApp/Telegram-specific composer, live weather/news/stocks integrations, camera burst/recording, screen recording, speaker identification, or complete UI-agent verification pipeline is included yet.
- Device admin activation is a legacy Android interface and has no wipe/password policy configured. It does not grant root or unrestricted system control.

## InstaBox / OpenAI-compatible online API setup

In ULTRON, open Settings and select Online LLM. Enter:

1. **Base URL**, for example `https://your-domain.example/v1` (do not append `/chat/completions`; the app appends it).
2. **Model ID** exactly as expected by your server.
3. **API token**, if required.

The app sends a JSON request to `${baseUrl}/chat/completions` with `model`, `messages`, and `stream: false`, and sends `Authorization: Bearer …` when a token is configured. Use HTTPS. Do not expose a privileged inference endpoint without authentication. The adapter expects an OpenAI-compatible Chat Completions endpoint. The user supplies the InstaBox gateway `/v1` URL, exact model path/name and gateway API key. Other APIs with different schemas need an adapter.

## Offline model setup

1. Open Dashboard → Model Manager (Local Model Vault) and enable Offline AI only when you want to use it.
2. The Qwen model search shortcut opens the model repository search. Select a compatible GGUF asset and copy its direct HTTPS download URL (a model webpage URL is not a direct asset URL).
3. Paste the direct HTTPS `.gguf` asset URL and choose Download, or use Import / Replace to select a GGUF from storage.
4. ULTRON checks the GGUF magic header and stores the model in app-private storage. You can delete it at any time. There are no RAM tiers or automatic substitutions.
5. Model architecture compatibility, peak memory and inference performance still require testing on the target device. A downloaded GGUF is not proof that it will fit or run.

## Build from a phone using GitHub Actions

1. Create a GitHub repository and upload these project files to the repository root (keep `.github/workflows/android.yml`).
2. Open the repository's **Actions** tab. Run **Build ULTRON debug APK** using **Run workflow**, or push a commit to `main`.
3. Wait for the workflow to finish. Open the successful run and download the `ultron-debug-apk` artifact. GitHub gives you a ZIP containing `app-debug.apk`.
4. Install the APK on your own device and test each feature. Android may show the usual side-load warning; only install builds from your own repository that you trust.

This archive contains source files, not a compiled APK. The current environment could not build it locally because Gradle and Android SDK components were unavailable. The workflow is configured but not yet proven successful. The new multi-AI, wake-word, website plugin and local model changes require a successful Actions run and physical-device verification.

## Useful user commands

- `remember that I prefer short Hinglish answers`
- `what do you remember?`
- `forget all memory`
- `note: revise plant anatomy at 7 pm`
- `show notes`
- `remind me in 25 minutes to take a break`
- `show documents`
- `search web for NEET 2027 official syllabus`
- `open Wi-Fi settings`
- `open Bluetooth settings`
- `turn on flashlight`
- `volume down`
- `read screen`
- `click Continue`
- `scroll down`
- `how many notifications`

`set alarm` opens the Android Clock app; it does not create an alarm automatically. For notifications/reminders, grant notification permission. For precise timing, optionally enable Android's Alarms & reminders access.

## Privacy and Android behavior

The document import is user-selected. OCR and document storage happen on device. Relevant stored excerpts may be sent to your configured cloud AI when you use Online LLM; avoid importing sensitive documents if you don't want them transmitted in context. Chat history cleanup does not delete saved memories, notes, or documents. Accessibility can see text in other apps only after you enable it and is used here only after explicit commands. The wake-word service uses the device's on-device recognition service and shows an ongoing notification while microphone listening is active.

## Jarvis feature port in this source refresh

ULTRON includes a local custom-reply trainer inspired by Jarvis's Easter-egg trainer. Try:

- `when I say hello you say welcome`
- `teach ultron jab mission shuru toh systems ready bolo`
- `list custom replies`
- `delete custom reply hello`
- `clear custom replies`

Rules are stored in ULTRON's private app preferences. The original Jarvis `easter_egg.json` is malformed and was not imported. Jarvis's fake model-download implementation was intentionally not copied.

An optional app-usage summary is available with `app usage today` or `screen time today`. Android will ask you to enable Usage access in system settings; this access is optional and can be revoked there.


## 0.4.6 revision notes
See [CHANGELOG_0.4.6.md](CHANGELOG_0.4.6.md) for implemented fixes and explicit verification gaps.

## 0.4.7 visual redesign
The home screen now uses a cinematic ULTRON hero panel, red/orange neon command tiles, purple accents, and a compact bottom navigation inspired by the supplied reference mockup. See `CHANGELOG_0.4.7.md` for implemented scope and limitations.


## 0.4.8 multi-AI / voice / plugin refresh
See [CHANGELOG_0.4.8.md](CHANGELOG_0.4.8.md) for implemented scope and remaining limitations.
