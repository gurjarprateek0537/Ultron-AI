# ULTRON 0.4.1 — source handoff and honest implementation map

This package is an upgrade of the supplied `ULTRON-Native-Local-AI-Source.zip`, not a claim that every requested capability is finished or verified. The original package's implementation-status notes remain important and must be read before testing.

## Changes in this handoff

- Version metadata advanced to 0.4.1 / versionCode 4.
- Retained `UltronBrowserActivity`: a real in-app Android WebView browser with URL/search entry, back/forward/reload/share, JavaScript and DOM storage for ordinary websites, file/content access disabled, safe browsing enabled, and non-http(s) schemes handed to Android. It is user-visible; it is not yet an autonomous background browsing agent controlled by an LLM.
- Wired the existing Browser navigation action to open this browser rather than launching the external browser.
- Set the requested default local-model profile label to `Qwen3.5-4B-Amadeus · Q4_K` and made model-page opening a user action. The model is NOT bundled, downloaded, or guaranteed compatible. The current LocalInferenceProvider limitation in `IMPLEMENTATION_STATUS.md` remains in force.
- Added a local custom-reply/Easter-egg trainer and optional app-usage summary using Android UsageStatsManager. Usage access must be enabled by the user in Android Settings.
- Included the three user-provided target-interface images under `design-reference/` for implementation reference.
- Retained the supplied GitHub Actions workflow using current v4 actions.

## Existing real implementations retained from source

See `IMPLEMENTATION_STATUS.md` for details. In summary: online OpenAI-compatible HTTP client; encrypted API token storage; Room chat/memory/note/document storage; document text extraction and OCR; reminders; explicit Android command routing; opt-in accessibility helper; biometric/device-credential app lock; permission centre; foreground wake-word prototype; native llama.cpp/JNI source; GGUF import path.

## Not complete / must not be represented as complete

- Native GGUF inference source is present: Kotlin import/load/generate calls, JNI declarations, C++ bridge, and llama.cpp CMake wiring. This is not an error-reporting placeholder, but the Android NDK build and actual GGUF inference have not been verified in this environment; model architecture, chat template, memory fit, and device performance remain unverified.
- The Qwen profile is a default label/search profile only. No model is shipped or silently downloaded. The exact model repository asset must be selected and verified by the user.
- Voice wake-word service is a prototype: it can notify after wake-word recognition but does not complete a full wake-word → command capture → AI → action → spoken confirmation loop.
- No speaker/voice biometric identification.
- Browser is a normal visible WebView, not an LLM-operated hidden browser agent.
- No full website-account plugin framework, credential vault for arbitrary websites, or account automation. Website login/MFA and site policies remain controlled by the site and user.
- Vision currently means user-selected file/image OCR and document extraction. A searchable three-day media gallery shared across chats is not yet complete.
- Memory is basic lexical retrieval, not vector-embedding RAG.
- PrivateTextVault is not a complete encrypted file vault with arbitrary file import/export.
- No universal ability to operate every Android screen/app. Accessibility actions are limited to exposed UI nodes and explicit commands.
- The Jarvis Easter egg JSON in the supplied archive is malformed (JSON parser reports an error at line 1286). It has not been copied. Its useful custom-reply training concept was reimplemented in ULTRON; the fake model downloader was deliberately excluded.

## Build/test status

No Android SDK/Gradle build was run in the authoring environment. The source archive can be submitted to the included GitHub Actions workflow. A successful CI build is not the same as real-device feature verification. Run the workflow, install the artifact, then test each permission and capability on the target Android device.

## User's fixed product requirements

- Product name: ULTRON.
- Visual target: supplied three red/black futuristic reference images; multiple themes, adjustable colors and selectable avatars are desired.
- Navigation: AI Chat, Voice, Vision (3-day chat/media history), Plugins, Browser (AI's own browsing capability), Memory (RAG), Model Manager, Permissions, Security, Appearance, Settings.
- Online LLM: user will configure and connect it separately; no credentials are embedded.
- Offline default: `Qwen3.5-4B-Amadeus-Q4_K.gguf`; download only after explicit user action; allow user-imported alternative GGUF models.
- Device automation: only through Android-supported APIs, explicit permissions, and confirmation for sensitive actions. Android lock/force-stop/security boundaries cannot be bypassed.
- No fake results, simulated downloads, or features reported as working when they are not.

## 0.4.1 source refresh

- `UltronPersonalityEngine.kt` stores custom trigger/reply rules in private app preferences and supports train/list/delete/clear commands.
- `UltronCommandRouter.kt` supports `app usage today` / `screen time today` after the user grants Android Usage access.
- Android manifest declares the special usage-stats permission; Android still requires the user to grant access manually.

## 0.4.8 source refresh (2026-11-23)

This revision adds named online AI profiles, All-in-One multi-model review/synthesis, a separate Offline Model Vault with direct HTTPS GGUF download/import/delete, Android 8.x-compatible speech recognizer selection and follow-up voice-command routing, and user-configurable HTTPS website plugins. The latest APK screenshots supplied by the user are preserved under `design-reference/latest-apk-screenshots/`.

Validation in this environment: AndroidManifest XML parsed; GitHub Actions YAML parsed; Kotlin delimiter scan passed. Full Kotlin/Android compilation and unit tests were not run because Gradle and Android SDK are unavailable in this environment. Vision model image-payload transport, general OAuth plugins, wake-word reliability on the user's Android 8.1 handset, and all-in-one/live InstaBox behavior still need implementation/testing as documented in `CHANGELOG_0.4.8.md`.
