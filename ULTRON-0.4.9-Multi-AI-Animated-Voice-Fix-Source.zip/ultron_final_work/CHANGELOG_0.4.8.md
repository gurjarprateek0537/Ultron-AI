# ULTRON 0.4.8 — Multi-AI, offline vault, voice and plugin refresh

## Implemented in source

- Added user-named OpenAI-compatible online AI profiles with independent role, base URL, model ID and Android-Keystore-encrypted API key. The primary InstaBox endpoint remains the General AI profile.
- Added dashboard AI selection and an All-in-One pipeline: parallel candidate answers, peer-review/cross-check pass, then final synthesis. At least two configured online profiles must respond successfully.
- Separated the Offline Model Vault from online endpoint settings. Users explicitly enable offline inference, find Qwen GGUF assets, paste a direct HTTPS GGUF asset URL for download, import/replace a local GGUF, or delete it. No RAM-based model tier or automatic model substitution.
- Fixed a hard wake-word compatibility bug: previous code stopped the service on every Android version below API 31. The service now uses Android's on-device recognizer when available and the installed system recognizer on older versions (including Android 8.x).
- Added two-stage wake flow: say “ULTRON”, then speak a command; or say “ULTRON, open YouTube and search BMW” in one utterance. The service launches ULTRON with the recognized command and the chat router executes it.
- Microphone permission grant now automatically starts the requested foreground wake-word service.
- Reworked the voice command screen with a layered crimson/orange/purple sci-fi interface and command examples.
- Replaced the static plugin list with a working website plugin hub. Built-in YouTube, Google, Wikipedia, GitHub and Stack Overflow searches are routed; users can add/remove custom HTTPS URL templates and use “search <query> on <plugin name>”.
- Updated GitHub Actions SDK setup to locate sdkmanager directly instead of relying on the legacy setup-android action.
- Bumped Android version to 0.4.8 (versionCode 7).

## Explicit limitations / verification still required

- The Vision profile currently configures a specialist text endpoint, but image bytes are not yet passed through a multimodal chat payload. Camera launch/OCR is not equivalent to full VLM image analysis.
- Website plugins are implemented; OAuth-connected services and arbitrary third-party plugin SDK integrations are not.
- Wake-word recognition depends on the installed Android speech service. On older phones, `EXTRA_PREFER_OFFLINE` is only a recognizer preference, not a guarantee of offline recognition. Background microphone availability, false triggers, battery behavior and OEM restrictions require physical-device testing.
- Direct GGUF download requires a direct HTTPS asset URL, not a Hugging Face model webpage. Large downloads have no in-app progress/cancel UI yet. Model architecture, RAM fit and native llama.cpp compatibility still need device testing.
- The All-in-One pipeline can make multiple requests per user prompt and therefore uses more gateway capacity/tokens. It requires at least two healthy profiles; it reports failure instead of silently falling back to one model.
- Android Gradle compilation, unit tests, InstaBox live inference, voice operation and UI interaction have not been verified in this environment because Android SDK/Gradle are unavailable here. A successful GitHub Actions run and physical-device tests are required before calling this APK working.
