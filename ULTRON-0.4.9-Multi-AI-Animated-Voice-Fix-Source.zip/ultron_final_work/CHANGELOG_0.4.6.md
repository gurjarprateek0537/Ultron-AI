# ULTRON 0.4.6 source revision

## Implemented in this revision
- Removed Oracle-specific endpoint defaults, labels, and error messages. Online provider is configured by the user with an InstaBox-compatible HTTPS gateway URL, exact model ID/path, and gateway bearer key.
- Online requests use `/chat/completions` (or accept a base URL already ending in that route), an extended inference timeout, and up to three attempts for HTTP 502/503/504 responses. Error details from the gateway are surfaced to the chat.
- Online mode remains the default. Local mode remains opt-in; local GGUF import/replacement and model deletion are available. Qwen3.5-4B-Amadeus Q4_K is presented as the suggested model, while other compatible GGUF files can be imported.
- Removed the obsolete model RAM-tier policy and its unit-test expectations.
- Added direct YouTube search navigation for commands such as “open YouTube then search BMW”, “YouTube search BMW”, and “search BMW on YouTube”.
- Incremented Android app version to 0.4.6.

## Not completed / not verified
- The Qwen link opens a Hugging Face model search page; this revision does not implement a verified in-app binary downloader for a particular Qwen asset.
- The existing wake-word service can detect “Ultron” and notify the user, but does not yet capture and execute the follow-up command in the background. Android background microphone restrictions also vary by OS/device.
- The full cinematic UI shown in the supplied reference image has not yet been rebuilt to match. This archive is not being represented as feature-complete.
- No Android SDK/Gradle installation is available in this build environment. APK compilation, unit tests, InstaBox live requests, voice wake-word behavior, and device automation have not been verified here.
