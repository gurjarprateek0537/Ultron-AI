package com.ultron.assistant

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID

data class WebPlugin(val id: String, val name: String, val urlTemplate: String)

class PluginStore(context: Context) {
    private val prefs = context.getSharedPreferences("ultron_web_plugins", Context.MODE_PRIVATE)
    private val gson = Gson()
    fun load(): List<WebPlugin> = runCatching {
        val type = object : TypeToken<List<WebPlugin>>() {}.type
        gson.fromJson<List<WebPlugin>>(prefs.getString("plugins", "[]"), type).orEmpty()
    }.getOrDefault(emptyList())
    fun save(items: List<WebPlugin>) { prefs.edit().putString("plugins", gson.toJson(items)).apply() }
    fun add(name: String, template: String): WebPlugin {
        val safeName = name.trim().take(40)
        require(safeName.isNotBlank()) { "Enter a plugin name." }
        require(template.startsWith("https://", true)) { "Website plugins must use HTTPS." }
        require(Uri.parse(template.replace("{query}", "test")).host?.isNotBlank() == true) { "Enter a valid HTTPS URL or URL template." }
        val plugin = WebPlugin(UUID.randomUUID().toString(), safeName, template.trim())
        save(load() + plugin)
        return plugin
    }
    companion object {
        fun expand(template: String, query: String? = null): String {
            val encoded = URLEncoder.encode(query.orEmpty(), StandardCharsets.UTF_8.name())
            return template.replace("{query}", encoded)
        }
    }
}
