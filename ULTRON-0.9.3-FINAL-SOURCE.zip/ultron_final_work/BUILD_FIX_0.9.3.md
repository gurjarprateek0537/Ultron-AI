# ULTRON 0.9.3 compile fixes

This source archive includes two targeted Kotlin compilation fixes reported by GitHub Actions:

1. `MainActivity.kt`: imports `androidx.compose.ui.text.style.TextAlign` for the centered wake-word persistence message.
2. `UltronAccessibilityService.kt`: invokes the IME-enter accessibility action through `AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id`, the action ID expected by `performAction`.

No unrelated Kotlin implementation or Android resources were changed for this repair. The GitHub Actions workflow remains in `.github/workflows/android.yml`.

Validation performed here: source patch inspection and ZIP integrity. A full Android Gradle build was not run in this environment; GitHub Actions remains the build verification step.
