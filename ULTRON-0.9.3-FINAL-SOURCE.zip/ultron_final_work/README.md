# ULTRON 0.9.6 — Advanced Android Assistant Source

Current source release: **0.9.6** (versionCode 21). This single Android project was reconstructed from the complete 0.8.0 source tree, then updated with the 0.9.0 implementation changes file by file. No source files unique to 0.8.0 were dropped. It adds the persistent wake-word opt-in and reboot-resume flow, expanded Accessibility/device controls, local OCR on Android 11+, improved action reporting, and the new dashboard/voice artwork. It is one project, not a pair of nested ZIP archives.

See [CHANGELOG_0.9.1.md](CHANGELOG_0.9.1.md), [FINAL_DELIVERY_AUDIT.md](FINAL_DELIVERY_AUDIT.md), and [BUILDING_0.9.1.md](BUILDING_0.9.1.md) for the exact source changes, build workflow, and verification boundaries.

---

## ULTRON 0.8.0 update

This source includes improved compound app-search routing, semantic AccessibilityService targeting, focused-only text entry, foreground-app verification and one bounded safe recovery attempt for navigation/search failures. It also includes Online, Local and Hybrid inference modes; Hybrid tries the selected online endpoint, same-role online profile failover, then a configured local text GGUF model. Local GGUF inference uses the model's declared chat template with conservative context budgeting. See `CHANGELOG_0.8.0.md`, `ULTRON_0.8.0_AUDIT.md` and `BUILDING_0.8.0.md`.

Important: Android app UI automation is not universal. Accessibility control must be explicitly enabled, some app controls are not exposed semantically, and background activity launch may be blocked by Android/OEM restrictions. ULTRON will stop instead of typing into an ambiguous field. A complete Gradle/NDK build and physical-device test are still required.

# ULTRON 0.8.0 — Android AI Assistant Source

ULTRON is a personal Android assistant combining an OpenAI-compatible AI client, optional local GGUF inference, an accessibility-based action executor, background voice command processing, memory, camera image analysis, a built-in browser, and user-configurable website/API integrations.

## 0.8.0 upgrade notes

- Compound search commands for YouTube, Chrome, Google, Google Maps/Maps, Play Store, Gmail and Spotify run a deterministic open → wait → semantic search → inspect flow. English, common Hinglish and selected Hindi-script forms are parsed locally. The app-scoped results-link fallback remains YouTube-only.
- The AI agent planner now explicitly plans complete search workflows: open app, verify the foreground window, wait, inspect visible controls, focus a semantic search field, enter the exact query, submit, wait and inspect results. Added a `submit_search` action using the focused Android input's IME action or clearly labelled Search controls; it will not tap generic Submit/Go buttons.
- Added parser unit tests for YouTube and common-app compound searches, quoted queries, Hinglish/Hindi forms, wake-word normalization and unsupported-app rejection.
- Creator identity questions return the supplied creator name, Prateek Gurjar, with only project skills supported by the provided project context; no unverified awards or qualifications are claimed.
- Existing online/local inference modes, endpoint profiles, local GGUF model support, vision endpoint path, memory, plugins, browser, voice, and safety confirmations are retained.
- Version is now 0.8.0 (versionCode 14).

## What's in this release

- **AI-driven action plans:** the selected online AI profile can convert English, Hindi, or Hinglish phone requests into a bounded JSON plan of up to 24 allow-listed actions. ULTRON validates the plan and never executes model-generated scripts or code.
- **Phone actions:** launch installed apps, click visible labels, enter text in exposed editable controls, scroll, swipe, tap normalized coordinates, read visible screen text, navigate Back/Home, open HTTPS URLs, compose WhatsApp/SMS messages, place a call after confirmation, and invoke saved plugins.
- **Background command processing:** wake-word commands are encrypted in app-private storage and placed into a serial WorkManager queue using opaque IDs. The worker plans and executes without opening the ULTRON activity, then posts a result notification and uses the chosen installed Android TTS voice. Background app launches can still be blocked by Android/OEM policy.
- **Safety gate:** message sending, calls, coordinate taps, risky button labels and REST/OAuth API operations require a separate YES/NO approval. Pending approvals are encrypted, expire after 10 minutes, and appear in a notification. Actions are recorded in an encrypted local audit history. A report distinguishes accepted operations from those whose effect was independently observed.
- **Contact workflows:** WhatsApp and SMS use Contacts permission when a number is not supplied. Ambiguous contact matches fail closed. WhatsApp may open a prefilled conversation and activate a visible Send control only after approval; delivery/read status is not available to ULTRON.
- **Vision:** the user launches Android's camera capture flow. ULTRON downsamples the captured photo and sends it as an OpenAI-compatible `image_url` payload to an enabled Vision profile (or the default online model if configured). The chosen endpoint must accept multimodal image input.
- **Plugins:** add HTTPS website shortcuts and REST API integrations from Plugin Armory. REST integrations support GET/POST/PUT/PATCH/DELETE, no auth, Bearer, API-key header/query and Basic auth. OAuth 2.0 Authorization Code + PKCE is available with encrypted credentials/tokens and refresh where the provider returns a compatible refresh token.
- **Hindi/English speech:** choose English (India), English (US) or Hindi (India), plus male/female preference. ULTRON selects the closest matching voice from the Android TTS engine and provides the engine's voice-data installer. Voice binaries are not redistributed in this source.
- **Memory and UI:** persistent Room memory, notes and imported documents; searchable memory screen with item deletion and agent action history; cinematic crimson/charcoal dashboard and a distinct 32-frame 360×360 animated ULTRON voice GIF.
- **Smart context and chat archive:** explicit `max_tokens` output cap, adjustable General AI app-side context budget, oldest-turn trimming, automatic conversation rollover, encrypted three-day archives, New Chat control and relevance-based retrieval of earlier discussions.
- **Connection diagnostics and fast local actions:** Settings includes a General AI connection test from the Android device. Wake-word prefixes are normalized; time/date/battery, simple app launches, YouTube searches and basic web searches are routed locally before the LLM, so these safe actions remain available during a temporary gateway outage.
- **Optional local AI:** the existing GGUF model vault and native llama.cpp bridge remain separate from online AI. Image input is not supported by the local text runtime.

## Configure online AI

In ULTRON Settings, choose Online mode and enter the InstaBox OpenAI-compatible gateway's base URL (normally ending `/v1`), the exact model ID/path and the gateway API key. ULTRON calls `POST {baseUrl}/chat/completions`. The app retries selected transient 502–504 responses, but a down gateway/upstream still needs to be fixed at the host.

Add named AI profiles for separate roles such as General, Coding and Vision. The dashboard's selected profile is used by the task planner. Use **Settings → Test General AI Connection** to send a small probe from the phone itself; this separates an Android-to-gateway problem from a chat/agent-prompt problem. The General AI context budget defaults to 4096 tokens and reply cap to 256 tokens. These are app-side request controls; if you choose 8192, 16384 or another larger context, configure the InstaBox model server with `n_ctx` at least that large and confirm it is supported by available RAM. A Vision profile must accept OpenAI-style multimodal `image_url` message content.

## Configure Android access

1. Grant microphone permission and start the foreground wake-word listener from Voice settings.
2. Enable ULTRON Accessibility in Android Accessibility settings for screen actions.
3. Grant Contacts permission for name-to-number resolution.
4. Allow notifications so execution results and YES/NO requests are visible.
5. Exempt ULTRON from battery optimization only if you understand the battery trade-off and your device otherwise kills the listener.

Say “ULTRON” followed by a command, or say the wake word and wait for the follow-up capture. You can answer a pending confirmation with “ULTRON yes” or “ULTRON no”, or use the notification buttons. The service uses Android `SpeechRecognizer`, not a dedicated offline acoustic wake-word detector.

## Plugin setup

Open Modules → Plugin Armory. Website shortcuts use HTTPS URL templates with `{query}`. API integrations need the API name, HTTPS resource endpoint, method, authentication type, credentials and optional JSON body template. Use `run plugin <name> with <request>` in chat/voice.

For OAuth, enter the provider authorization URL, token URL, client ID/secret (if required), scopes and exact registered redirect URI. The default callback is `ultron://oauth/callback`. The implementation is generic OAuth 2.0 Authorization Code + PKCE; providers that require additional parameters, client authentication methods, app-link verification or server-side confidential clients may need provider-specific support. Register the exact redirect URI with the provider and use only the minimum scopes required.

## Android compatibility and build

- `minSdk`: 26 (Android 8.0)
- `compileSdk` / `targetSdk`: 35
- Java/Kotlin target: 17
- Native ABI filters: `arm64-v8a`, `armeabi-v7a`, `x86_64`
- CMake: 3.22.1; Android NDK: 27.2.12479018
- GitHub Actions workflow: `.github/workflows/android.yml`

The workflow installs JDK 17, Gradle 8.9, Android SDK 35, NDK 27.2.12479018 and CMake 3.22.1; runs `:app:testDebugUnitTest`; builds `:app:assembleDebug`; and uploads the installable debug APK with its SHA-256 checksum. Push the project root to the `main` or `master` branch, or run **Actions → ULTRON Android CI → Run workflow**.

## Important behavior limits

- This is not root access or unrestricted device control. Android system UI, lock screens, secure/password fields, protected apps, inaccessible custom views and OEM-specific interfaces may block accessibility reading or gestures.
- Android 8–16 is the target range, not proof of uniform compatibility. Android 14+ microphone foreground-service rules, background activity launch restrictions, speech-recognizer availability and OEM battery policies require physical-device tests. Continuous wake-word performance and false-trigger rate are not guaranteed.
- WorkManager survives normal activity closure but is scheduled work, not a real-time daemon. The microphone listener itself remains an explicit foreground service and is subject to OS/OEM restrictions.
- The planner is an instruction model, not deterministic automation. ULTRON bounds and checks its proposed actions, but a complex request can still be misunderstood. Review the full confirmation notification before approving it.
- UI verification is best-effort: ULTRON can observe visible text/package changes, but it cannot prove every server-side action, message delivery, payment, or app-internal state.
- WhatsApp/SMS workflows depend on contact data and exposed app controls. WhatsApp send may be activated only after YES if its UI exposes the Send control. ULTRON cannot verify delivery or read receipts. Other messaging apps use general accessibility actions and are not guaranteed.
- Camera analysis is an explicit foreground capture, not live video, continuous monitoring or silent background capture. It requires a compatible online multimodal model.
- Generic OAuth does not automatically fit every provider. Provider-specific setup or code may be needed. API credentials are encrypted at rest, but they are still sent to the URLs you configure; only connect services you trust.
- Male/female Hindi/English voice options depend on the Android speech engine's installed voices and metadata. ULTRON does not bundle third-party voice binaries.
- The source archive is **not a compiled or signed APK**. No Android SDK, Gradle or NDK toolchain is available in the authoring workspace, so the build and hardware tests have not been run here. Treat the APK as build-verified only after the included GitHub Actions workflow succeeds.

See `CHANGELOG_0.9.1.md`, `FINAL_DELIVERY_AUDIT.md`, `IMPLEMENTATION_STATUS.md`, and the historical 0.4–0.8 changelogs for implementation details and test boundaries.


## Build and device verification

This archive is source code, not a prebuilt APK. The authoring environment used for this upgrade does not have a verified Android SDK/Gradle build result. Run the repository's CI workflow or build on an Android SDK machine before installing. Accessibility-driven app workflows depend on the target app exposing searchable UI nodes and on Android/OEM background-launch rules; no assistant can guarantee identical behavior across every YouTube version/device.

## 0.9.4 reliability update

See [ULTRON 0.9.4 upgrade notes](ULTRON_0.9.4_UPGRADE_NOTES.md) and [build instructions](BUILDING_0.9.4.md) for the wake-word partial-result fix, concise speech summaries, sensitive-only confirmations, draft-before-send messaging, chat/voice YES-NO handling, volume readback and screen wake support. Build and physical-device verification are still required before claiming runtime reliability.


## 0.9.5 advanced capability foundations

See [CHANGELOG_0.9.5.md](CHANGELOG_0.9.5.md), [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md), and [BUILDING_0.9.5.md](BUILDING_0.9.5.md). This revision adds a capability dashboard, opt-in notification reading, safe clipboard preview, network diagnostics, SAF folder browsing, routine-definition storage, local OCR helper, skill registry, specialist-agent contract, and an app-private project workspace. These are documented as foundations/partial implementations where full scheduling, marketplace, local multimodal vision, cross-app workflows or IDE execution are not yet integrated. No full Android build or device test is claimed.


## 0.9.6 reliability patch

This patch addresses three reported command paths: (1) the wake-word service now preserves and handles a recognized wake phrase when older/OEM SpeechRecognizer implementations return `ERROR_NO_MATCH` or `ERROR_SPEECH_TIMEOUT` after partial results, and accepts the common truncated recognition `ultra`; (2) the deterministic open-and-search parser now includes Instagram and additional common apps, and Android 8.x search submission can activate a clearly labelled key in the soft-keyboard input-method window; (3) alarm requests such as `set an alarm for 7:30 AM` and `wake me up at 6:45 PM` are routed deterministically to Android `ACTION_SET_ALARM`.

Alarm handoff success means Android accepted the Clock intent; the app cannot independently inspect the Clock app's private alarm database, so the user is asked to verify the saved alarm. Wake-word reliability still depends on the installed Android speech-recognition provider, microphone permission, OEM battery policy and device testing. App-agnostic automation remains bounded by Accessibility exposure and secure/custom screens. No Android Gradle/NDK build or physical-device test is claimed for this patch.
