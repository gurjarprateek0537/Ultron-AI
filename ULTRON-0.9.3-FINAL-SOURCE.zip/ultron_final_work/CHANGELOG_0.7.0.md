# ULTRON 0.7.0 — Smart Context, Inference and Conversation Archive

## Inference reliability
- Every OpenAI-compatible request now includes an explicit `max_tokens` output cap (default 256, user-adjustable from 64 to 1024).
- Added conservative app-side context budgeting. Oldest chat turns are trimmed from the request without deleting the stored transcript; the latest user request and system instructions are retained.
- General AI context budget is configurable from 2,048 to 32,768 tokens. It is explicitly an app-side request budget and must not exceed the runtime `n_ctx` configured on the model server.
- Added non-secret inference diagnostics: selected model name, message count, approximate prompt tokens, context budget, output limit and payload bytes.
- Improved timeout/error context in HTTP 502–504 responses and retained transient gateway retries.
- Added an in-app General AI connection probe that sends a small bounded request from the Android device using the saved URL, model and key.
- Wake-word-prefix normalization now removes “ULTRON” before deterministic local routing and agent planning.
- Safe deterministic requests (time, date, battery, simple app launch, YouTube search and basic web search) are handled locally before asking the LLM, so basic phone functions do not depend on gateway uptime.
- Retry backoff uses coroutine delay rather than blocking an IO worker thread.

## Conversation lifecycle
- Added conversation IDs and a migration from Room database version 1 to 2; existing chat rows are preserved as legacy archived history.
- Added encrypted three-day conversation archives with expiry timestamps and searchable summaries/transcript excerpts.
- Conversation rollover automatically starts a fresh chat around 72% of the configured app context budget.
- Added a New Chat control; it archives the previous conversation before starting a new session.
- Relevant archived excerpts can be retrieved into future chat and agent-planner prompts. Retrieved archive text is explicitly treated as untrusted reference content, not instructions.
- Cleanup deletes expired archived conversations; it no longer age-prunes active conversations.
- Memory screen now displays searchable archived chat summaries and expiry dates.

## Kept from previous source
- Existing AI profiles, All-in-One mode, agent planner/executor, approval notifications, accessibility integration, wake-word foreground service, plugins, OAuth PKCE, camera/vision flow, TTS preferences, local GGUF model manager, animated voice UI and dashboard are retained.

## Verification status
- Source archive and static XML/YAML checks are performed for this package.
- Gradle/Android SDK are not installed in the authoring container. Run the included GitHub Actions workflow to perform Room KSP, Kotlin compilation, unit tests, native build and APK assembly. Do not treat the source ZIP as a compiled APK until that workflow succeeds.
- Qwen2.5/Qwen3.5 runtime context is server-configured. ULTRON cannot remotely change the InstaBox process's `n_ctx`; increase the server launch context separately before setting an app budget above the server's `n_ctx`.
