# Building ULTRON 0.9.5

Requirements: JDK 17, Gradle 8.9, Android SDK platform/build-tools 35, NDK 27.2.12479018 and CMake 3.22.1.

From this directory:

```bash
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:assembleDebug
```

The CI workflow `.github/workflows/android.yml` installs these tools, runs JVM tests, assembles the debug APK and uploads the APK plus checksum. The source archive is not an APK and is not signed for Play distribution.

Before release, install on the target device and test wake-word recovery, voice interruption, accessibility automation across several unrelated apps, sensitive-action confirmation, screen lock/wake, actual volume changes, notification permission behavior, SAF access, clipboard filtering, network status, OCR language accuracy and routine behavior. Android/OEM restrictions remain applicable.
