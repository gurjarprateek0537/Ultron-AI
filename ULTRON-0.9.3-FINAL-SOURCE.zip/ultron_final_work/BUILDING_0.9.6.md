# Building ULTRON 0.9.6

Requirements: JDK 17, Gradle 8.9, Android SDK platform/build-tools 35, NDK 27.2.12479018 and CMake 3.22.1.

```bash
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:assembleDebug
```

The CI workflow is `.github/workflows/android.yml`. Before installing, test the wake listener for at least 10 minutes with the screen on/off, test alarm intents at several times, and run compound navigation/search/drafting tasks in Instagram and at least three unrelated apps. The alarm confirmation message is an Android intent handoff, not direct inspection of the Clock database.
