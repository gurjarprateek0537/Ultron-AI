# Build ULTRON 0.9.0

## Requirements

- JDK 17
- Android SDK platform 35 and Build Tools compatible with AGP 8.7.3
- Android NDK and CMake 3.22.1 (native llama.cpp integration)
- Gradle 8.x as required by the project plugin configuration

The archive does not bundle a Gradle wrapper. Use an installed compatible Gradle executable or create a wrapper from the Android build host.

## Build and tests

From this directory:

```bash
gradle testDebugUnitTest
gradle assembleDebug
```

Then install the debug APK on a test device:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Grant only the permissions needed for the features you test. Enable Accessibility and Notification Access manually in Android Settings. To test persistent wake word, open Voice → ARM WAKE-WORD LISTENER, verify the ongoing Stop notification, then reboot. Android 14+ should show the resume notification; older Android can attempt direct boot restore. On OPPO/ColorOS, also enable the app's Auto launch and allow background activity in the device battery settings.

## Important test matrix

- Android 8.1/API 27: boot receiver, Foreground Service, Media key fallback, app search and accessibility-tree search; visual screen OCR and Accessibility global lock/screenshot are unavailable. Check the legacy force-lock Device Admin flow separately.
- Android 11/API 30: local screen OCR, screenshot capability, gesture and accessibility flows.
- Android 14/API 34 and Android 15/API 35+: verify boot notification resume, microphone FGS type permission and notification permission behavior.
- Test YouTube/Spotify UI changes and all target apps manually; accessibility nodes vary by app version and OEM.

Do not mark the build as verified until Gradle tests, `assembleDebug`, installation and runtime tests pass.
