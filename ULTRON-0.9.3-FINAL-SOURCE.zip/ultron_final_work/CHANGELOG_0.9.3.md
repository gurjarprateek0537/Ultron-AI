# ULTRON 0.9.3 — Voice animation replacement

## What changed
- Replaced the 0.9.2 microphone/waveform voice GIF with the original high-quality red-eyed ULTRON villain-avatar animation from the supplied 0.8.0 source archive.
- The replacement is 560×560 pixels, 48 frames, with its original smooth loop timing. It visually matches the red/black villain dashboard artwork rather than displaying a standalone microphone icon.
- Kept the resource filename `ultron_voice_core.gif` unchanged, preserving all existing startup and voice-screen references.
- Preserved the 0.9.2 dashboard artwork and all Kotlin/application logic. Only the voice GIF and app version metadata changed.
- Updated app version to 0.9.3 (versionCode 18).

## Verification boundary
- Confirmed the replacement GIF dimensions, frame count, frame timing, resource path and archive integrity.
- Confirmed Kotlin source files are unchanged from 0.9.2.
- The full Android Gradle build and on-device rendering have not been run in this workspace. Use the included GitHub Actions workflow to compile and test the APK.
