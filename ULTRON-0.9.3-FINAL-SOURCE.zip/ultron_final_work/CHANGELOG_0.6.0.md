# ULTRON 0.6.0 — Agent Core, Vision, Voice and Interface Upgrade

## Implemented in this source revision

- Added a structured Qwen/OpenAI-compatible task planner with a bounded allow-listed Android action schema (up to 24 steps). The model returns JSON actions; model-generated scripts/code are never executed.
- Added sequential background execution through a unique WorkManager command queue. Voice commands are encrypted in app-private storage and WorkManager receives only opaque IDs; they are scheduled without opening `MainActivity`. Results are delivered through notifications and the selected Android TTS voice.
- Extended accessibility helpers for visible text reading, click-by-label, editable text entry, scrolling, swipe, normalized coordinate tap, Back/Home actions, foreground-app checks, and screen-change verification. These actions remain limited by each app's exposed accessibility tree and Android security boundaries.
- Added WhatsApp and SMS contact resolution using the user's Contacts permission. Ambiguous matches fail closed; message send and calls require explicit approval. Other messaging apps can be handled with a bounded generic UI plan when their accessibility controls are exposed.
- Added persistent encrypted pending-action storage, 10-minute expiry, notification YES/NO controls, spoken YES/NO handling after the wake word, and an encrypted local action audit trail shown in Memory. Approved action plans are passed to WorkManager by opaque ID so larger plans do not exceed WorkManager Data’s 10 KB limit; the plan is removed before execution to prevent replay from a second approval tap.
- Sensitive actions are independently checked by ULTRON even when the AI omits its confirmation flag. Messaging, calls, coordinate taps, destructive/action button labels (including Save/Update/Accept/Enable/Disable) and all REST/OAuth plugin calls require approval.
- Added camera capture using the Android camera app, image downsampling/JPEG encoding, multimodal `image_url` payload support for OpenAI-compatible providers, and routing to an enabled Vision-role profile. The chosen endpoint/model must support image inputs.
- Added automatic OAuth access-token refresh when the provider returns an expiry and refresh token. Resource/API endpoint and HTTP method/body can be configured separately from the OAuth token endpoint. Secrets/tokens remain encrypted at rest.
- Redesigned the dashboard and voice page, integrated a 48-frame 560×560 ULTRON voice GIF, expanded the animated HUD, and improved the Memory screen with search, item deletion, and encrypted agent activity history.
- Expanded native build ABI targets to `arm64-v8a`, `armeabi-v7a`, and `x86_64` with Android minSdk 26 / targetSdk 35. NDK compilation on each ABI is not yet verified.
- Added JVM safety-policy tests for confirmation rules.

## Important limits — not represented as completed

- This is not root or unrestricted control. Android system UI, lock screens, secure/password fields, protected apps, inaccessible Compose/Canvas views, and manufacturer-specific apps can block reading or interaction. Accessibility must be explicitly enabled by the device owner.
- Android 8–16 is the intended API range, not a guarantee of identical behavior. The microphone foreground service follows Android's API-level service type rules, but OEM battery management, permissions, speech recognizer behavior and Android 14+ while-in-use restrictions require testing on each device.
- Wake-word recognition is built on Android `SpeechRecognizer` with on-device recognition where Android exposes it, and the installed system recognizer otherwise. It is not a dedicated offline acoustic keyword model; continuous listening, false activations and battery reliability need physical-device testing.
- Background app launches may be denied by Android. The executor attempts an accessibility/launcher fallback for app opening, but a task may stop and request that the user open the destination app.
- WhatsApp automation can open a contact's prefilled conversation and may tap Send only after a recorded YES if the UI exposes that exact control. Delivery/read receipts are not independently verified. Generic messaging workflows are best-effort UI automation, not a universal official messaging API.
- Camera-to-AI is still an explicit foreground camera capture flow. It requires an online Vision profile or default endpoint that accepts OpenAI-style multimodal `image_url` content. The local GGUF text runtime does not provide camera vision. No silent/background camera capture is included.
- OAuth is generic Authorization Code + PKCE. You supply provider credentials, redirect registration, scopes and the resource endpoint. Provider-specific parameters/client-auth requirements may require further adaptation. Refresh is available only when the provider issues a refresh token and compatible token endpoint response.
- Male/female English/Hindi output uses available installed Android TTS engine voices and the settings UI can open the engine's voice-data installer. Voice binaries are not bundled in this APK; exact gender/language availability is controlled by the installed engine.
- Qwen2.5-4B-Amadeus is an instruction model, not a deterministic action runtime. ULTRON validates the plan, limits action types and checks results, but complex intent interpretation can still be mistaken. Review the confirmation preview carefully.
- The source archive and static XML/Kotlin syntax checks are performed here, but no Android SDK/Gradle/NDK build or hardware test is available in this workspace. GitHub Actions must pass before treating the APK as build-verified.

## Build

Use the included `.github/workflows/android.yml` in your repository. It installs JDK 17, Gradle 8.9, Android platform/build-tools 35, NDK 27.2.12479018 and CMake 3.22.1, runs `:app:testDebugUnitTest`, builds `:app:assembleDebug`, and publishes the debug APK artifact. The workflow has not been run from this workspace.
