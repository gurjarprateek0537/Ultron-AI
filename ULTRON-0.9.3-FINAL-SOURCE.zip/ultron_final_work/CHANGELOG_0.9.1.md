# ULTRON 0.9.1 — Consolidated final source candidate

## Source reconstruction

- Used the uploaded `ULTRON-0.8.0-Audited-Advanced-Source.zip` as the actual base project.
- Compared the uploaded `ULTRON-0.9.0-Final-Source-Code.zip` by relative file path and content hash.
- Preserved all 69 files from the 0.8.0 tree; no 0.8.0-only path was lost.
- Applied the 20 changed files and 10 additional files from 0.9.0 as source changes, not as nested/merged ZIP archives.
- Kept prior 0.4.x–0.8.0 changelogs, audit notes, design references, and project structure.

## Consolidation/build changes

- Version set to `0.9.1`, versionCode `16`.
- NDK version pinned to `27.2.12479018` in the Android Gradle configuration.
- GitHub Actions workflow uses Android SDK 35, NDK 27.2.12479018, CMake 3.22.1, JDK 17 and Gradle 8.9.
- CI executes JVM unit tests before producing the installable debug APK, then uploads the APK and SHA-256 checksum as an artifact.
- Added exact delivery/build notes and explicit verification boundaries.

## Feature code carried forward

- Existing online/local/Hybrid AI setup, GGUF/llama.cpp integration, provider profiles and context budgeting.
- Existing Room conversation memory, archives, notes/documents, browser, plugins/OAuth, permissions, voice/TTS and camera-to-online-vision paths.
- Existing bounded agent planner, compound app-search workflow, Accessibility automation, confirmation gates, background WorkManager execution and audit history.
- 0.9.0 additions: local deterministic device-command parsing; volume/media/brightness/flashlight/system-panel actions; expanded gestures; visible-screen search with local OCR on Android 11+; wake-word preference and boot-resume handling; revised execution status; dashboard art, voice GIF and startup overlay.

## Verification warning

This package has not yet passed the GitHub Actions build. The authoring workspace does not have Gradle, Android SDK, Android NDK or an Android emulator. The isolated deterministic parser check ran successfully (23 device-command cases, 2 compound app-search cases, and the powered-off-phone restriction). XML/YAML/package checks are recorded in `FINAL_DELIVERY_AUDIT.md`. Do not call the APK build-verified until GitHub Actions succeeds and the APK has been installed and tested on target devices.
