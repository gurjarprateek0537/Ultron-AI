# ULTRON 0.8.0 source audit and phone-control design

## What was present in 0.7.0

The 0.7.0 project already had an Android Compose application, online OpenAI-compatible inference profiles, local GGUF inference through a JNI llama.cpp library, an AccessibilityService, an AI action planner/executor, voice input/output, memory and archives, notes/documents, plugins, browser UI, camera/online-vision flow and confirmation logic for sensitive actions. The original phone agent was an allow-listed action executor rather than an unrestricted scripting engine.

## Gaps addressed in 0.8.0

1. **Compound app-search intent:** deterministic parsing now handles common open-and-search phrases for YouTube, Chrome, Google, Google Maps/Maps, Play Store, Gmail and Spotify without asking a general model to invent the steps. The parser covers English plus selected Hinglish and Hindi-script forms. It opens the named app, waits for its foreground window, searches the exact query through semantic Accessibility controls and inspects the resulting screen. The app-specific results-link fallback is currently YouTube-only.
2. **Semantic Accessibility controls:** visible nodes are inspected for text, content description, hint text and view IDs. Clicks may target the nearest clickable ancestor. Search fields are selected only when their metadata looks like a search/query/address field.
3. **Safe text entry:** text is entered only into the currently focused editable node. The agent no longer assumes that one visible edit field must be the search box. Search overlay focus gets one additional attempt after a button opens it.
4. **Submission and verification:** the agent invokes the IME search action only for a semantically identified search editor, otherwise looks for localized Search controls. It deliberately does not tap generic Submit/Go buttons. It compares the screen after submission and distinguishes dispatched actions from verified changes.
5. **Foreground guard:** app launch waits for the requested package to become active. Screen-dependent actions stop if the foreground package changes unexpectedly.
6. **Bounded recovery:** after one non-sensitive failure, the planner may inspect current screen state and return at most six restricted navigation/search actions, with the unexecuted tail of the original plan included as context. Recovery excludes text injection, coordinate taps, calls, messages and plugins. It does not replay the failed action.
7. **Deterministic common-app search:** supported app search commands bypass free-form planning and run a fixed open → wait → semantic search → wait → read-screen sequence. If YouTube hides its search field from Accessibility, ULTRON tries an app-scoped results link and reports whether it could verify the query.
8. **Form-entry guardrails:** automatic `search_in_app` text entry requires a focused node with search metadata; generic `type_text`, permission grants and sensitive form buttons require explicit approval. Search submission no longer uses generic Submit/Go labels.
9. **Local-mode agent:** phone task planning no longer requires Online mode; the configured local model can plan when available.
10. **Privacy-aware recovery:** visible screen text is passed to the recovery planner only in LOCAL mode. Online and Hybrid recovery prompts withhold it, and prior `read_screen` output is removed from recovery context.
11. **Hybrid inference:** the selected online endpoint is tried first, then up to four enabled profiles of the same role, then the local GGUF model. Hybrid mode requires a native local model for the final fallback; image requests stay online because the local model path is text-only.
12. **GGUF chat formatting:** local inference passes structured role/content messages through the model's default GGUF chat template. Context fitting prioritizes the current user request and trims large memory/system context.
13. **Reproducible native dependency:** llama.cpp is pinned to v1.0.0 rather than a moving branch.

## Important limitations that remain

- Accessibility automation depends on what the target app exposes in its accessibility tree. YouTube or another app can change resource IDs, labels, dialogs, and search UX without notice.
- A device's keyboard may not expose an IME Search action to the service. On Android versions without the available IME action, ULTRON must find a visible, clearly labelled Search control or use the YouTube-only app-link fallback; otherwise it stops with the query left in the field. The deep-link fallback exists only for YouTube; other supported apps rely on accessible search controls.
- Android 8 through current releases have background activity-launch and OEM power-management restrictions. A task may require ULTRON to be opened in the foreground, battery optimization exceptions or an enabled AccessibilityService.
- Apps can use WebViews, custom canvases, Compose semantics restrictions, protected screens or secure windows that expose little/no text. Those flows cannot be guaranteed.
- There is no unrestricted control of arbitrary apps, system settings, banking/payment apps, lock screen, or protected data. Sensitive actions continue to need approval and OS permission.
- Hybrid mode is a best-effort failover chain, not parallel speculative generation. It tries one provider at a time, and falls back to local only for text requests with an available native GGUF runtime.
- Vision flow is architecture-ready for configured online image-capable endpoints; a local vision model is not included.
- Wake-word activation uses Android `SpeechRecognizer`; Android 12+ uses on-device recognition when the device advertises it, otherwise it falls back to the system recognizer. This is not a dedicated always-on offline wake-word model.
- Archived conversation retrieval uses lexical term overlap against the three-day archive, not embeddings/vector search. It is useful keyword retrieval, not semantic long-term memory.
- Local GGUF chat template support depends on the template features supported by the pinned llama.cpp C API. Some advanced custom Jinja templates may not be supported.
- Local model performance and memory use depend on the GGUF quantization, context, NDK build, device RAM and thermal state.

## Device test plan

1. Install the debug APK on Android 8.1 and a recent Android release; grant the AccessibilityService explicitly.
2. Open ULTRON, select the intended local or online AI mode, verify model/provider connectivity and ask a normal text question.
3. Run `open YouTube and then search BMW`; verify the YouTube app is foreground, the query appears in the search field, the search is submitted and actual results appear.
4. Repeat with `youtube kholo aur BMW search karo`, `YouTube में BMW खोजो`, `search lofi music on YouTube`, `launch YouTube then search for BMW M5`, `open Chrome and then search BMW M5`, `search offline maps on Play Store`, a quoted phrase and a Hindi/Hinglish variant.
5. Test an app without a search field: the agent should refuse to type into a login/comment field and report the reason.
6. Switch apps while a plan is running: the foreground-package guard should stop the sequence.
7. Test a network interruption in Online mode and no selected GGUF in Local mode: errors should be reported without falsely claiming success.
8. Test WhatsApp/SMS/call actions and confirm they are blocked until the explicit approval flow is completed.
9. Test UI labels with TalkBack off/on and different keyboards; record cases where the target app exposes no semantic search controls.

## Build status

The archive does not contain a Gradle wrapper. This authoring environment has no configured Android SDK and no system Gradle executable, so the Android/NDK build is not verified here. The CI workflow is the intended reproducible build path; its run must complete successfully before treating the APK as build-verified.
