# ULTRON 0.9.4 — reliability and interaction upgrade

This release candidate is based on the supplied `ULTRON-0.9.3-FINAL-SOURCE.zip`. Existing application screens, AI modes, memory, browser, plugins, local inference/native bridge, vision foundations, artwork and settings were retained.

## Changes made in this source revision

- Wake-word recognition no longer dispatches an incomplete command from an intermediate partial hypothesis (for example, `ULTRON open`). It stores the richest partial phrase and waits for the final result; it can restore a wake-word prefix if an OEM recognizer shortens the final hypothesis.
- Ordinary no-match/speech-timeout results reconnect quickly instead of entering a long exponential delay. Client/busy errors recreate the recognizer, and other errors use bounded backoff. Notification text reflects reconnecting rather than claiming active listening.
- Voice output now uses a concise first-outcome summary while full responses remain in chat. This applies to normal chat, vision replies and background agent reports.
- Confirmation is restricted to high-impact actions: calls, explicit Send/Pay/Buy/Transfer/Delete/Publish/Share controls, and mutating plugin methods. Ordinary typing, drafts, searches, taps, gestures, scrolling and navigation are not confirmation-gated.
- WhatsApp/SMS compose actions now only open a conversation/composer and fill a draft. They never tap Send. Sending must be represented as a separate explicit `click_text("Send")` action and requires YES approval.
- Chat YES/NO now resolves the current unexpired pending confirmation, just as voice YES/NO does. Approval is still bound to the pending plan ID and the store expiry.
- Media volume percentage uses nearest supported Android stream step and reports the percentage read back from AudioManager, acknowledging discrete device steps.
- Added a short, permission-backed display wake request. It wakes the display only; it does not unlock or bypass the secure keyguard. Screen-off maps to the existing lock action, which on Android 8.1 requires ULTRON's optional Device Admin force-lock permission.
- Added parser coverage for screen on/off command variants.

## Existing architecture retained

The project already contains an allow-listed AI planner/executor, sequential action plans, accessibility-tree inspection, semantic search-field targeting, OCR fallback on Android 11+, bounded recovery, WorkManager task queue, encrypted pending approvals/history, local/online/hybrid inference, local GGUF/JNI foundation, memory/archive, document ingestion, browser, REST/OAuth plugin foundations, and online multimodal camera analysis. Their existing Android and provider limitations remain.

## Platform boundaries

- Android 8.1 has no Accessibility screenshot API; ULTRON can use accessible text but not the Android 11+ screenshot/OCR path.
- A normal app cannot silently power off/reboot Android. ULTRON opens the system power menu.
- Waking the display does not unlock it. Locking on API 26–27 needs Device Admin activation; API 28+ can use the Accessibility global lock action.
- Android/OEM speech services can still stop or throttle foreground recognition. The wake-word service needs a real OPPO CPH1803 / Android 8.1 endurance test; this source change is not proof of device-level reliability.
- Generic app control depends on Accessibility being enabled and on third-party apps exposing accessible controls. Secure screens and custom-rendered controls may not be automatable.

## Verification status

- Source ZIP integrity and static Android XML validation are required at packaging time.
- This workspace does not contain Gradle or an Android SDK installation, and the supplied ZIP contains no APK. Therefore a full Gradle/Kotlin/Compose/KSP/NDK build, Android unit-test task, APK installation, and OPPO physical-device test cannot be claimed here.
- Run the included GitHub Actions workflow before treating this archive as build-verified. Install and test the resulting APK on the OPPO CPH1803 for wake-word, volume, screen, confirmation and cross-app workflows.

## Deliberately not included

The previously discussed three autonomy modes are excluded, as requested.
