> Historical build guide for 0.8.0. For the current source, use [BUILDING_0.9.1.md](BUILDING_0.9.1.md).

# Building ULTRON 0.8.0

## Required toolchain

- JDK 17
- Gradle 8.9
- Android SDK Platform 35 and Build Tools 35.0.0
- Android NDK 27.2.12479018
- CMake 3.22.1
- Internet access during the native configure step so CMake FetchContent can retrieve `ggml-org/llama.cpp` at `v1.0.0`

The source archive intentionally does not include a Gradle wrapper. The checked-in GitHub Actions workflow installs Gradle 8.9 and the Android toolchain, runs unit tests and builds the debug APK.

## Build and test

From the project root, after installing/configuring the toolchain:

```bash
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:assembleDebug
```

Expected debug APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The GitHub Actions workflow is `.github/workflows/android.yml`. Trigger it manually or push the source to the configured `main` branch. Do not treat the APK as build-verified until the workflow completes successfully.

## First-run phone-control setup

1. Install ULTRON and open it once.
2. Open **Permission Center** and explicitly enable the ULTRON Accessibility Service. Android requires the user to enable this special access in system Settings.
3. Keep ULTRON in the foreground for the first automation test. Some Android/OEM builds restrict launching another app from a background worker.
4. Say or type: `open YouTube and then search BMW`.
5. Confirm that YouTube opens, the search query is entered/submitted, and the screen shows results. A status of “unverified” means the app did not expose enough visible UI text for ULTRON to confirm the result; it does not mean the action is guaranteed to have failed.
6. For a denied or blocked action, review ULTRON's requested permission and Android's battery/background restrictions. Do not grant Accessibility to apps you do not trust.

Sensitive text entry, messaging, calls, permission grants and consequential form controls require an explicit YES approval. Automatic search entry is limited to fields identified by search metadata; ULTRON deliberately stops rather than typing into an ambiguous field.

## Compatibility and limits

- `minSdk 26` means Android 8.0 and newer can install the app. The project targets SDK 35 and has not been run on every Android release/OEM build.
- The local model path is text-only. Vision requires a configured online image-capable endpoint until a local vision model is added.
- Hybrid mode tries the selected online endpoint, same-role online profiles and then a local GGUF. The local fallback only works when the native library and a compatible on-device model are available.
- Accessibility automation depends on the target app exposing controls and text to Android. Protected screens, custom canvases, inaccessible WebViews, changed labels and keyboard differences can prevent verification or automation.
