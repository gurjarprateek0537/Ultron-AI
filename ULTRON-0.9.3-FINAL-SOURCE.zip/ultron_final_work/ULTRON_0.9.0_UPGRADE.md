# ULTRON 0.9.0 — Upgrade notes

## Base and preservation

This release is based on the supplied `ULTRON-0.8.0-Audited-Advanced-Source.zip`. Existing Compose UI, chat/provider profiles, Local/Online/Hybrid inference, GGUF/llama.cpp integration, Room memory, notes, documents, voice output, plugins, browser, permissions, accessibility agent and security controls were retained. Version: `0.9.0`, versionCode `15`.

## Persistent wake-word behavior

- User opt-in is persisted in private preferences. Starting the listener is an explicit Voice-screen action; granting microphone permission from the Permission Center alone no longer silently arms listening.
- The microphone foreground service retains `START_STICKY`, exposes an ongoing notification with a Stop action, retries SpeechRecognizer sessions with exponential backoff, prefers on-device recognition where Android exposes it, and uses partial hypotheses to reduce missed compound commands without double-dispatching the same wake phrase.
- A boot/package-replacement receiver restores the service automatically only on Android versions where the microphone foreground-service start is allowed.
- Android 14+ (API 34+) cannot start an ordinary microphone foreground service directly from `BOOT_COMPLETED`; ULTRON therefore posts a resume notification, then starts the listener after the user opens ULTRON. This behavior follows Android's foreground-service and while-in-use microphone rules.
- The listener is still built on Android `SpeechRecognizer`, not a dedicated low-power on-device hotword engine. `EXTRA_PREFER_OFFLINE` is a preference, not a guarantee. Older Android devices may use the recognizer installed by the phone vendor and may require network. OEM autostart/battery controls, force-stop, microphone revocation and the speech service can still interrupt it. It cannot be promised to listen literally forever.

## Phone-control additions

New deterministic actions include:

- Set media volume to a percentage; raise/lower/mute/unmute media volume.
- Play/pause/next/previous through an active MediaSession first and media-key fallback second. Notification access improves active-session control but may not be necessary for every player.
- Set brightness after the user grants Android's Modify system settings special access.
- Turn the camera flashlight on/off when camera permission and a flash are available.
- Open Android's power menu, lock screen (Android 9+ Accessibility global action; Android 8.x optional force-lock Device Admin), Quick Settings, notification shade, recent apps, Internet settings, Bluetooth settings and Android Settings.
- Find visible text by Accessibility labels. On Android 11+ the Accessibility screenshot API plus bundled ML Kit Latin/Devanagari OCR is used locally when the accessibility tree does not expose the requested text. The captured bitmap is not persisted or uploaded by this action. Android 8–10 devices only have the accessibility-tree path.
- Semantic long-press, direction-aware scrolling, coordinate drag and double-tap gestures. High-impact free-form gestures require the existing explicit YES approval.
- App-search compound commands continue to parse deterministically; music play commands search the requested title/app and open a result only when its text is accessible. The agent then checks the resulting screen.
- The agent still executes in small steps, checks the foreground package, verifies screen changes, and allows one bounded navigation/search recovery attempt. Recovery cannot send messages, call, tap arbitrary coordinates, enter text or run plugins.

## System limits (not bypassed)

- A normal third-party app cannot silently power off or reboot a phone. ULTRON opens Android's system power menu; the user taps Power off/Restart. Turning a fully powered-off phone on requires the physical power button or OEM/hardware support.
- Recent Android versions restrict direct Wi-Fi/Bluetooth state changes. ULTRON opens the system panel/settings instead of using hidden APIs.
- Android may not expose every custom-drawn, protected, secure, banking, DRM or WebView control to Accessibility. OCR is local and only enabled for explicit find-on-screen commands, but secure windows can block screenshots.
- Android 8.1 does not have the newer Accessibility screenshot/OCR API or the lock-screen global action. Optional Device Admin force-lock is provided for Android 8.x only; ULTRON does not request wipe or password policies.
- Some apps intentionally block automation. A user-visible confirmation remains required for sending messages, calls, purchases, deleting, publishing, generic free-form typing, arbitrary coordinate gestures and screenshots.

## UI and assets

- Replaced the dashboard hero with a darker original futuristic sentinel artwork and vignette, separate from voice animation.
- Replaced `ultron_voice_core.gif` with a distinct animated microphone/spectral-core animation.
- Reuses the voice animation in a short ULTRON startup overlay so app opening has a coherent voice-link loading effect.

## Verification status

The source includes unit tests for device commands, execution reporting, recovery, inference modes and boot policy. This authoring workspace does not have a Kotlin compiler, Gradle, Android SDK or NDK, so the unit-test task, Android/Compose/JNI compile, APK build and physical-device tests have not been run. Static resource checks are not a substitute for those builds. The source must be built and tested on an Android build host before calling it a release-ready APK.
