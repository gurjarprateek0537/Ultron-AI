# Build ULTRON 0.9.1 with GitHub Actions

## Recommended: GitHub Actions

This repository includes `.github/workflows/android.yml`. It installs the pinned Android toolchain, runs the JVM unit tests, builds the debug APK and publishes the APK plus a SHA-256 checksum as a workflow artifact.

1. Extract this source ZIP.
2. Create or open your GitHub repository.
3. Upload the **contents** of the `ULTRON-0.9.1-FINAL` folder to the repository root. Make sure `.github/workflows/android.yml` is included at that exact path (enable showing hidden files if uploading from a file manager).
4. Commit/push to `main` or `master`, or open the repository's **Actions** tab, select **ULTRON Android CI**, and choose **Run workflow**.
5. Wait for the workflow to finish. It must show green for both `:app:testDebugUnitTest` and `:app:assembleDebug`.
6. Open the successful workflow run and download the **ULTRON-0.9.1-debug-apk** artifact. The artifact contains `app-debug.apk` and its checksum file.
7. Install the APK on a test phone. The APK is debug-signed and suitable for testing; it is not a production/release-signed APK.

The workflow uses:

- JDK 17
- Gradle 8.9 (AGP 8.7.3 requires Gradle 8.9)
- Android SDK platform 35 and Build Tools 35.0.0
- Android NDK 27.2.12479018
- CMake 3.22.1

The native build fetches the pinned llama.cpp `v1.0.0` source during the CMake build, so the GitHub runner needs outbound access to GitHub.

## Local Android build

Open the extracted project root in a current Android Studio installation with JDK 17, SDK 35, NDK 27.2.12479018 and CMake 3.22.1 installed. The project does not bundle a Gradle wrapper. On a build machine with Gradle 8.9 installed, run:

```bash
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Device test targets

- Android 8.1 / API 27: the user's OPPO device; test boot receiver, microphone service, semantic Accessibility tree, search, volume, flashlight, media controls and legacy force-lock only after explicitly enabling Device Admin.
- Android 11 / API 30: test local screenshot/OCR.
- Android 14 / API 34 and Android 15 / API 35: test microphone foreground-service restrictions and the boot-resume notification.

Enable Accessibility and grant only the permissions required for each test. Test wake-word behavior with the display off, after reboot and with ColorOS background/auto-start and battery settings. Do not assume the service is permanently uninterrupted.

## Important limitations

The GitHub workflow can prove source compilation and the included JVM tests. It cannot prove that every app-specific Accessibility selector works, that the microphone service stays alive indefinitely, or that an external message/media action completed. A normal third-party Android app cannot silently power the device off or turn it on after shutdown. ULTRON opens the Android power menu so the user can choose Power off or Restart.
