package com.ultron.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UltronAgentRecoveryPolicyTest {
    @Test fun permitsOnlyNavigationAndSearchActions() {
        listOf("open_app", "click_text", "search_in_app", "wait", "read_screen", "back", "scroll", "swipe", "submit_search", "open_url")
            .forEach { assertTrue("$it should be recoverable", UltronAgentRecoveryPolicy.allows(UltronAgentAction(type = it))) }
        listOf("type_text", "tap", "compose_whatsapp", "compose_sms", "call", "run_plugin", "home", "unknown")
            .forEach { assertFalse("$it must not be recoverable", UltronAgentRecoveryPolicy.allows(UltronAgentAction(type = it))) }
    }
}
