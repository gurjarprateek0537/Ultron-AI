package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UltronAgentSafetyPolicyTest {
    @Test fun ordinaryTextEntryAndGesturesDoNotRequireApproval() {
        listOf("type_text", "tap", "double_tap", "drag", "swipe", "long_press_text", "take_screenshot", "scroll")
            .forEach { type -> assertFalse("$type is an ordinary user-directed action", UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = type))) }
    }

    @Test fun preparingDraftDoesNotRequireApprovalButCallsDo() {
        assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "compose_whatsapp", contact = "Rahul", message = "Hello")))
        assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "compose_sms", contact = "Rahul", message = "Hello")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "call", contact = "Rahul")))
    }

    @Test fun searchesAndNavigationDoNotRequireApproval() {
        listOf(
            UltronAgentAction(type = "search_in_app", query = "BMW"),
            UltronAgentAction(type = "submit_search"),
            UltronAgentAction(type = "click_text", text = "Search"),
            UltronAgentAction(type = "click_text", text = "Open chat")
        ).forEach { assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(it)) }
    }

    @Test fun onlyHighImpactCommitButtonsRequireApproval() {
        listOf("Send", "Send now", "Pay now", "Buy now", "Place order", "Delete account", "Publish now", "Change password")
            .forEach { label -> assertTrue("$label must require confirmation", UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = label))) }
        listOf("Allow", "Save", "Create", "Update", "Download", "Install", "Enable", "Submit search", "Purchase history", "Security settings")
            .forEach { label -> assertFalse("$label should not trigger blanket confirmation", UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = label))) }
    }

    @Test fun onlyMutatingPluginRequestsRequireApproval() {
        assertFalse(UltronAgentSafetyPolicy.pluginRequiresConfirmation("GET", "rest"))
        assertTrue(UltronAgentSafetyPolicy.pluginRequiresConfirmation("POST", "rest"))
        assertTrue(UltronAgentSafetyPolicy.pluginRequiresConfirmation("DELETE", "rest"))
    }

    @Test fun chatAndVoiceApprovalParserSharesEnglishAndHindiYesNo() {
        assertEquals(UltronApprovalDecision.APPROVE, UltronApprovalCommandParser.parse("YES!"))
        assertEquals(UltronApprovalDecision.APPROVE, UltronApprovalCommandParser.parse("हाँ"))
        assertEquals(UltronApprovalDecision.REJECT, UltronApprovalCommandParser.parse("No thanks."))
        assertEquals(UltronApprovalDecision.REJECT, UltronApprovalCommandParser.parse("नहीं"))
        assertEquals(null, UltronApprovalCommandParser.parse("yes, open Instagram"))
    }

    @Test fun wakeWordMergePreservesCommandWhenOemShortensFinalHypothesis() {
        assertEquals("ULTRON open Instagram", UltronWakeWordPhrase.bestPhrase("ULTRON open", "Instagram"))
        assertEquals("ULTRON open Instagram", UltronWakeWordPhrase.bestPhrase("ULTRON open Instagram", "open Instagram"))
        assertEquals("ULTRON", UltronWakeWordPhrase.bestPhrase("ULTRON", ""))
    }
}
