package com.ultron.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UltronAgentSafetyPolicyTest {
    @Test fun genericTextEntryRequiresExplicitApproval() {
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "type_text", text = "hello")))
    }

    @Test fun searchAutomationDoesNotRequireFormApproval() {
        assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "search_in_app", query = "BMW")))
        assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "submit_search")))
    }

    @Test fun permissionAndPurchaseControlsRequireApproval() {
        listOf("Allow", "Grant access", "Authorize", "Buy now", "Delete account", "Send")
            .forEach { label ->
                assertTrue("$label must require confirmation", UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = label)))
            }
    }

    @Test fun ordinarySearchControlDoesNotRequireApproval() {
        assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = "Search")))
    }

    @Test fun coordinateAndContextualGesturesNeedApprovalButVerticalScrollDoesNot() {
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "drag")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "long_press_text")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "swipe", direction = "left")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "scroll", direction = "right")))
        assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "scroll", direction = "down")))
    }
}
