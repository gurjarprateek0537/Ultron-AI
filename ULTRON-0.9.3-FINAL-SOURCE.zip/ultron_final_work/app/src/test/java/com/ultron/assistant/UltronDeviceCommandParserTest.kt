package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNull
import org.junit.Test

class UltronDeviceCommandParserTest {
    @Test fun parsesFixedVolumePercentAndVolumeUpDown() {
        assertEquals(72, UltronDeviceCommandParser.parse("set volume to 72%")?.actions?.first()?.value)
        assertEquals("up", UltronDeviceCommandParser.parse("increase volume")?.actions?.first()?.direction)
        assertEquals("down", UltronDeviceCommandParser.parse("volume kam karo")?.actions?.first()?.direction)
    }

    @Test fun parsesMuteAndMediaTransport() {
        assertEquals("mute", UltronDeviceCommandParser.parse("mute")?.actions?.first()?.direction)
        assertEquals("play", UltronDeviceCommandParser.parse("play music")?.actions?.first()?.direction)
        assertEquals("pause", UltronDeviceCommandParser.parse("pause music")?.actions?.first()?.direction)
        assertEquals("next", UltronDeviceCommandParser.parse("next song")?.actions?.first()?.direction)
    }

    @Test fun parsesBrightnessTorchAndPowerMenu() {
        assertEquals(45, UltronDeviceCommandParser.parse("set brightness to 45 percent")?.actions?.first()?.value)
        assertEquals("up", UltronDeviceCommandParser.parse("brightness up")?.actions?.first()?.direction)
        assertEquals("open_internet_settings", UltronDeviceCommandParser.parse("turn Wi-Fi on")?.actions?.first()?.type)
        assertEquals("open_bluetooth_settings", UltronDeviceCommandParser.parse("turn Bluetooth on")?.actions?.first()?.type)
        assertEquals(true, UltronDeviceCommandParser.parse("flashlight on")?.actions?.first()?.enabled)
        assertEquals("open_power_menu", UltronDeviceCommandParser.parse("power off phone")?.actions?.first()?.type)
    }

    @Test fun parsesScreenFindAndLongPress() {
        assertEquals("BMW", UltronDeviceCommandParser.parse("find BMW on screen")?.actions?.first()?.text)
        assertEquals("long_press_text", UltronDeviceCommandParser.parse("long press Search")?.actions?.first()?.type)
    }

    @Test fun rejectsUnclearOrUnsupportedPowerOperations() {
        assertNull(UltronDeviceCommandParser.parse("do something powerful"))
        assertNull(UltronDeviceCommandParser.parse("turn the phone on from powered off"))
    }

    @Test fun commandDetectorRecognizesDeviceControls() {
        assertTrue(UltronDeviceCommandParser.parse("open quick settings") != null)
        assertEquals("open_quick_settings", UltronDeviceCommandParser.parse("open quick settings")?.actions?.first()?.type)
    }

    @Test fun parsesLocalNavigationAndDirectionalGesturesWithoutAnLlm() {
        assertEquals("back", UltronDeviceCommandParser.parse("go back")?.actions?.first()?.type)
        assertEquals("home", UltronDeviceCommandParser.parse("open home screen")?.actions?.first()?.type)
        assertEquals("open_recent_apps", UltronDeviceCommandParser.parse("show recent apps")?.actions?.first()?.type)
        assertEquals("scroll", UltronDeviceCommandParser.parse("scroll down")?.actions?.first()?.type)
        assertEquals("right", UltronDeviceCommandParser.parse("scroll right")?.actions?.first()?.direction)
        assertEquals(3, UltronDeviceCommandParser.parse("scroll down 3 times")?.actions?.first()?.count)
        assertEquals("swipe", UltronDeviceCommandParser.parse("swipe left")?.actions?.first()?.type)
        assertEquals("right", UltronDeviceCommandParser.parse("scroll to the right twice")?.actions?.first()?.direction)
        assertEquals(2, UltronDeviceCommandParser.parse("scroll to the right twice")?.actions?.first()?.count)
        assertEquals(3, UltronDeviceCommandParser.parse("swipe down thrice")?.actions?.first()?.count)
        assertEquals("set_volume_percent", UltronDeviceCommandParser.parse("set volume to 80 percent.")?.actions?.first()?.type)
    }

    @Test fun parsesAllFourScrollDirectionsAndBoundsRepeatCount() {
        assertEquals("up", UltronDeviceCommandParser.parse("scroll up")?.actions?.first()?.direction)
        assertEquals("down", UltronDeviceCommandParser.parse("scroll down")?.actions?.first()?.direction)
        assertEquals("left", UltronDeviceCommandParser.parse("scroll left")?.actions?.first()?.direction)
        assertEquals("right", UltronDeviceCommandParser.parse("scroll right")?.actions?.first()?.direction)
        assertEquals(4, UltronDeviceCommandParser.parse("swipe right 9 times")?.actions?.first()?.count)
    }

    @Test fun parsesNamedTapAndKeepsLongPressDistinct() {
        assertEquals("click_text", UltronDeviceCommandParser.parse("tap Search")?.actions?.first()?.type)
        assertEquals("Search", UltronDeviceCommandParser.parse("click on Search")?.actions?.first()?.text)
        assertEquals("long_press_text", UltronDeviceCommandParser.parse("press and hold Camera")?.actions?.first()?.type)
    }

    @Test fun deviceCommandGateDoesNotSendBasicNavigationToTheChatLlm() {
        assertTrue(UltronAgentPlanner.looksLikeDeviceCommand("go back"))
        assertTrue(UltronAgentPlanner.looksLikeDeviceCommand("go home"))
        assertTrue(UltronAgentPlanner.looksLikeDeviceCommand("scroll right"))
        assertTrue(UltronAgentPlanner.looksLikeDeviceCommand("tap Search"))
    }

    @Test fun parsesScreenWakeAndScreenOffWithinAndroidBoundaries() {
        assertEquals("wake_screen", UltronDeviceCommandParser.parse("turn screen on")?.actions?.single()?.type)
        assertEquals("lock_screen", UltronDeviceCommandParser.parse("turn screen off")?.actions?.single()?.type)
        assertEquals("wake_screen", UltronDeviceCommandParser.parse("turn on screen")?.actions?.single()?.type)
        assertEquals("lock_screen", UltronDeviceCommandParser.parse("turn off screen")?.actions?.single()?.type)
    }
}
