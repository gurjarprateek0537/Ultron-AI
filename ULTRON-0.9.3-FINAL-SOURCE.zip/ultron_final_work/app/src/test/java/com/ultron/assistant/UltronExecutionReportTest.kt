package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class UltronExecutionReportTest {
    @Test fun distinguishesVerifiedCompletionFromDispatchedActions() {
        val verified = UltronExecutionReport(true, 3, 3, 3, emptyList())
        assertEquals("Task completed and verified", verified.displayStatus)
        assertEquals("completed · verified", verified.historyStatus)

        val dispatched = UltronExecutionReport(true, 3, 1, 3, emptyList())
        assertEquals("Actions dispatched; final state is not fully verified", dispatched.displayStatus)
        assertEquals("dispatched · verification incomplete", dispatched.historyStatus)
    }

    @Test fun reportsStoppedAndPartiallyExecutedTasks() {
        val stopped = UltronExecutionReport(false, 1, 1, 3, emptyList())
        assertEquals("Task stopped before all planned actions were accepted", stopped.displayStatus)
        assertEquals("stopped", stopped.historyStatus)

        val partial = UltronExecutionReport(true, 1, 1, 2, emptyList())
        assertEquals("Task partially executed", partial.displayStatus)
    }
}
