package com.ultron.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UltronWakeWordBootPolicyTest {
    @Test fun microphoneServiceCanOnlyAutostartAtBootBeforeAndroid14() {
        assertFalse(UltronWakeWordPreferences.requiresUserResumeAfterBoot(26))
        assertFalse(UltronWakeWordPreferences.requiresUserResumeAfterBoot(33))
        assertTrue(UltronWakeWordPreferences.requiresUserResumeAfterBoot(34))
        assertTrue(UltronWakeWordPreferences.requiresUserResumeAfterBoot(35))
        assertTrue(UltronWakeWordPreferences.requiresUserResumeAfterBoot(36))
    }
}
