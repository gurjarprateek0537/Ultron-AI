package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class InferenceModeTest {
    @Test fun hasOnlineLocalAndHybridModes() {
        assertEquals(InferenceMode.ONLINE, InferenceMode.valueOf("ONLINE"))
        assertEquals(InferenceMode.LOCAL, InferenceMode.valueOf("LOCAL"))
        assertEquals(InferenceMode.HYBRID, InferenceMode.valueOf("HYBRID"))
    }
}
