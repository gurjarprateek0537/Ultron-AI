package com.ultron.assistant

/** Merges OEM speech-recognizer hypotheses without dispatching incomplete partial results. */
object UltronWakeWordPhrase {
    private val wakeTokens = listOf("ultron", "ultra", "अल्ट्रॉन", "अल्ट्रोन")

    fun containsWakeWord(value: String): Boolean = wakeTokens.any { value.contains(it, ignoreCase = true) }

    fun bestPhrase(partial: String, final: String): String {
        val p = partial.trim()
        val f = final.trim()
        if (f.isBlank()) return p
        if (p.isBlank()) return f
        if (containsWakeWord(p) && !containsWakeWord(f)) return mergeOverlappingWords(p, f)
        return if (p.length > f.length) p else f
    }

    private fun mergeOverlappingWords(first: String, second: String): String {
        val left = first.split(Regex("\\s+")).filter { it.isNotBlank() }
        val right = second.split(Regex("\\s+")).filter { it.isNotBlank() }
        val maxOverlap = minOf(left.size, right.size)
        val overlap = (maxOverlap downTo 1).firstOrNull { count ->
            left.takeLast(count).map { it.lowercase() } == right.take(count).map { it.lowercase() }
        } ?: 0
        return (left + right.drop(overlap)).joinToString(" ")
    }
}
