package com.ultron.assistant

import java.util.Locale

/** Shared strict parser so chat and wake-word confirmations interpret YES/NO identically. */
enum class UltronApprovalDecision { APPROVE, REJECT }

object UltronApprovalCommandParser {
    private val approve = setOf("yes", "yes please", "confirm", "approve", "haan", "हाँ", "जी हाँ", "कर दो", "करें")
    private val reject = setOf("no", "no thanks", "cancel", "reject", "nahi", "नहीं", "मत करो", "रद्द")

    fun parse(raw: String): UltronApprovalDecision? {
        val normalized = raw.trim().lowercase(Locale.ROOT).replace(Regex("[.!?,]+$"), "").replace(Regex("\\s+"), " ")
        return when (normalized) {
            in approve -> UltronApprovalDecision.APPROVE
            in reject -> UltronApprovalDecision.REJECT
            else -> null
        }
    }
}
