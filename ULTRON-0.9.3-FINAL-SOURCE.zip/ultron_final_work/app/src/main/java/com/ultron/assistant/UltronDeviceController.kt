package com.ultron.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.os.Build
import android.provider.Settings
import android.view.KeyEvent
import android.net.Uri

/** Device controls that Android exposes to ordinary, user-consented applications. */
object UltronDeviceController {
    fun setMediaVolumePercent(context: Context, percent: Int): Boolean = runCatching {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.isVolumeFixed) return false
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val value = ((percent.coerceIn(0, 100) / 100f) * max).toInt().coerceIn(0, max)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, value, AudioManager.FLAG_SHOW_UI)
        audio.getStreamVolume(AudioManager.STREAM_MUSIC) == value
    }.getOrDefault(false)

    fun adjustMediaVolume(context: Context, direction: String, count: Int = 1): Boolean = runCatching {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.isVolumeFixed) return false
        val command = when (direction.lowercase()) {
            "up", "increase", "raise" -> AudioManager.ADJUST_RAISE
            "down", "decrease", "lower" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_MUTE
            "unmute" -> if (Build.VERSION.SDK_INT >= 23) AudioManager.ADJUST_UNMUTE else AudioManager.ADJUST_RAISE
            else -> return false
        }
        repeat(count.coerceIn(1, 10)) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, command, AudioManager.FLAG_SHOW_UI)
        }
        true
    }.getOrDefault(false)

    /** MediaSession control first; media-key dispatch is the fallback for players without an accessible session. */
    fun media(context: Context, command: String): Boolean {
        val action = command.lowercase()
        val sessionCommand: (android.media.session.MediaController.TransportControls) -> Unit = when (action) {
            "play", "resume" -> ({ it.play() })
            "pause", "stop" -> ({ it.pause() })
            "next", "skip_next" -> ({ it.skipToNext() })
            "previous", "back", "skip_previous" -> ({ it.skipToPrevious() })
            else -> return false
        }
        val sessionWorked = runCatching {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(context, UltronNotificationListener::class.java)
            val controllers = manager.getActiveSessions(component)
            val selected = controllers.firstOrNull { controller ->
                controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
            } ?: controllers.firstOrNull()
            if (selected == null) false else {
                sessionCommand(selected.transportControls)
                true
            }
        }.getOrDefault(false)
        if (sessionWorked) return true

        val keyCode = when (action) {
            "play", "resume" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause", "stop" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next", "skip_next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "back", "skip_previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return false
        }
        return runCatching {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
            true
        }.getOrDefault(false)
    }

    fun setBrightnessPercent(context: Context, percent: Int): Result<Int> = runCatching {
        if (!Settings.System.canWrite(context)) throw SecurityException("Grant Modify system settings to ULTRON first.")
        val value = ((percent.coerceIn(1, 100) / 100f) * 255).toInt().coerceIn(1, 255)
        check(Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)) {
            "Android rejected manual brightness mode."
        }
        check(Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)) {
            "Android rejected the requested brightness value."
        }
        check(Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, -1) == value) {
            "Brightness was written but could not be verified."
        }
        value
    }

    fun adjustBrightnessPercent(context: Context, direction: String, count: Int = 1): Result<Int> = runCatching {
        if (!Settings.System.canWrite(context)) throw SecurityException("Grant Modify system settings to ULTRON first.")
        val current = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        val step = 26 * count.coerceIn(1, 8)
        val value = when (direction.lowercase()) {
            "up", "increase", "raise" -> (current + step).coerceAtMost(255)
            "down", "decrease", "lower" -> (current - step).coerceAtLeast(1)
            else -> throw IllegalArgumentException("Use up or down for brightness.")
        }
        check(Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)) {
            "Android rejected manual brightness mode."
        }
        check(Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)) {
            "Android rejected the requested brightness value."
        }
        check(Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, -1) == value) {
            "Brightness was written but could not be verified."
        }
        ((value / 255f) * 100).toInt()
    }

    fun openBrightnessPermission(context: Context) {
        val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun setTorch(context: Context, enabled: Boolean): Result<Unit> = runCatching {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = manager.cameraIdList.firstOrNull { cameraId ->
            manager.getCameraCharacteristics(cameraId).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                manager.getCameraCharacteristics(cameraId).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: throw IllegalStateException("No rear camera flash is available.")
        // setTorchMode throws when the request cannot be applied. CameraManager has no synchronous
        // state getter; observing actual state requires a TorchCallback and must not be guessed here.
        manager.setTorchMode(id, enabled)
    }

    fun openInternetSettings(context: Context) {
        val intent = if (Build.VERSION.SDK_INT >= 29) {
            Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        } else {
            Intent(Settings.ACTION_WIFI_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun openBluetoothSettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
