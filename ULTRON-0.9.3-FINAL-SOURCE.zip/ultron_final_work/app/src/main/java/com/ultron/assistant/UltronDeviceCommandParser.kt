package com.ultron.assistant

/** Deterministic, allow-listed mappings for common device controls; runs before LLM planning. */
object UltronDeviceCommandParser {
    private val percent = Regex("(?i)\\b(\\d{1,3})\\s*(?:%|percent|per cent)(?=\\s|$)")
    private fun clean(input: String) = input.trim()
        .replace(Regex("(?i)^\\s*(?:hey\\s+)?ultron[\\s,:;.!-]*"), "")
        .trim()
        .replace(Regex("[\\s.!?,;:]+$"), "")

    fun parse(request: String): UltronAgentPlan? {
        val text = clean(request)
        if (text.isBlank()) return null
        val normalized = text.lowercase()
        fun plan(summary: String, vararg actions: UltronAgentAction) =
            UltronAgentPlan(summary = summary, actions = actions.toList(), originalRequest = text.take(2_000))

        // Explicit percentage wins over generic up/down wording.
        if (Regex("(?i)\\b(volume|music volume)\\b").containsMatchIn(text)) {
            val target = percent.find(text)?.groupValues?.getOrNull(1)?.toIntOrNull()
            if (target != null) return plan(
                "Set media volume to ${target.coerceIn(0, 100)} percent.",
                UltronAgentAction(type = "set_volume_percent", value = target.coerceIn(0, 100))
            )
        }
        if (Regex("(?i)\\b(mute|silence)\\b").containsMatchIn(text) &&
            (Regex("(?i)\\b(volume|music|media|phone)\\b").containsMatchIn(text) || normalized == "mute" || normalized == "silence")
        ) return plan("Mute media volume.", UltronAgentAction(type = "adjust_volume", direction = "mute"))
        if (Regex("(?i)\\b(unmute|sound on)\\b").containsMatchIn(text))
            return plan("Restore media volume from mute.", UltronAgentAction(type = "adjust_volume", direction = "unmute"))
        if (Regex("(?i)\\b(volume up|increase volume|raise volume|turn volume up|volume badhao|volume badha do|आवाज़ बढ़ाओ|वॉल्यूम बढ़ाओ)\\b").containsMatchIn(text))
            return plan("Increase media volume.", UltronAgentAction(type = "adjust_volume", direction = "up", count = 2))
        if (Regex("(?i)\\b(volume down|decrease volume|lower volume|turn volume down|volume kam karo|volume ghatao|आवाज़ कम करो|वॉल्यूम कम करो)\\b").containsMatchIn(text))
            return plan("Decrease media volume.", UltronAgentAction(type = "adjust_volume", direction = "down", count = 2))

        val brightnessTarget = if (Regex("(?i)\\b(brightness|screen brightness)\\b").containsMatchIn(text)) percent.find(text)?.groupValues?.getOrNull(1)?.toIntOrNull() else null
        if (brightnessTarget != null) return plan(
            "Set screen brightness to ${brightnessTarget.coerceIn(1, 100)} percent.",
            UltronAgentAction(type = "set_brightness_percent", value = brightnessTarget.coerceIn(1, 100))
        )
        if (Regex("(?i)\\b(brightness|screen brightness)\\b").containsMatchIn(text)) {
            val direction = when {
                Regex("(?i)\\b(increase|raise|up|brighten|बढ़ाओ)\\b").containsMatchIn(text) -> "up"
                Regex("(?i)\\b(decrease|lower|down|dim|कम करो)\\b").containsMatchIn(text) -> "down"
                else -> ""
            }
            if (direction.isNotBlank()) return plan(
                "Adjust screen brightness ${if (direction == "up") "up" else "down"}.",
                UltronAgentAction(type = "adjust_brightness", direction = direction, count = 2)
            )
        }

        if (Regex("(?i)\\b(flashlight|torch)\\b").containsMatchIn(text)) {
            val enabled = when {
                Regex("(?i)\\b(on|enable|turn on|chalu|jalao|चालू|जलाओ)\\b").containsMatchIn(text) -> true
                Regex("(?i)\\b(off|disable|turn off|band|बंद)\\b").containsMatchIn(text) -> false
                else -> return null
            }
            return plan(if (enabled) "Turn the flashlight on." else "Turn the flashlight off.", UltronAgentAction(type = "set_flashlight", enabled = enabled))
        }

        if (Regex("(?i)\\b(power off|shut ?down|turn off (?:the )?phone|restart (?:the )?phone|reboot (?:the )?phone|power menu|power options|फोन बंद|रीस्टार्ट)\\b").containsMatchIn(text))
            return plan(
                "Open Android's power menu. You must choose Power off or Restart yourself; ordinary apps cannot silently shut down or reboot this phone.",
                UltronAgentAction(type = "open_power_menu")
            )
        if (Regex("(?i)\\b(lock (?:the )?(?:phone|screen)|screen lock|फोन लॉक)\\b").containsMatchIn(text))
            return plan("Lock the screen where this Android version exposes the lock action.", UltronAgentAction(type = "lock_screen"))
        if (Regex("(?i)\\b(open|show) (?:the )?(?:quick settings|control center)\\b|क्विक सेटिंग्स खोलो").containsMatchIn(text))
            return plan("Open Android Quick Settings. Toggle any restricted system switches yourself.", UltronAgentAction(type = "open_quick_settings"))
        if (Regex("(?i)\\b(open|show) (?:the )?(?:notification shade|notifications)\\b").containsMatchIn(text))
            return plan("Open Android notifications.", UltronAgentAction(type = "open_notifications"))
        if (Regex("(?i)\\b(open|show) (?:the )?(?:recent apps|app switcher)\\b").containsMatchIn(text))
            return plan("Open recent apps.", UltronAgentAction(type = "open_recent_apps"))
        if (Regex("(?i)\\b(take|capture) (?:a )?(?:screenshot|screen shot)\\b").containsMatchIn(text))
            return plan("Request an Android system screenshot. Android 9+ is required for the Accessibility screenshot action.", UltronAgentAction(type = "take_screenshot"))
        if (Regex("(?i)\\b(open|show) (?:internet|wi-?fi|network) settings\\b|\\bturn (?:on|off) wi-?fi\\b|\\bturn wi-?fi (?:on|off)\\b").containsMatchIn(text))
            return plan("Open Android Internet settings. Android restricts direct Wi-Fi toggling for ordinary third-party apps on recent versions.", UltronAgentAction(type = "open_internet_settings"))
        if (Regex("(?i)\\b(open|show) bluetooth settings\\b|\\bturn (?:on|off) bluetooth\\b|\\bturn bluetooth (?:on|off)\\b").containsMatchIn(text))
            return plan("Open Android Bluetooth settings. Confirm the requested switch in the system panel.", UltronAgentAction(type = "open_bluetooth_settings"))
        if (Regex("(?i)\\b(open|launch) (?:phone )?settings\\b").containsMatchIn(text))
            return plan("Open Android Settings.", UltronAgentAction(type = "open_system_settings"))

        // Deterministic navigation/gesture commands keep basic phone control usable
        // even when the selected local model is small or unavailable.
        if (normalized in setOf("back", "go back", "press back", "navigate back", "वापस जाओ", "पीछे जाओ"))
            return plan("Go back one screen.", UltronAgentAction(type = "back"))
        if (normalized in setOf("home", "go home", "open home screen", "show home screen", "होम खोलो", "होम स्क्रीन खोलो"))
            return plan("Return to the Android home screen.", UltronAgentAction(type = "home"))
        if (normalized in setOf("recent apps", "open recent apps", "show recent apps", "app switcher", "ओपन recent apps"))
            return plan("Open Android recent apps.", UltronAgentAction(type = "open_recent_apps"))

        val movement = Regex("(?i)^(scroll|swipe)(?: the screen)?\\s+(?:to\\s+the\\s+)?(up|down|left|right)(?:\\s+(\\d{1,2}|twice|thrice)\\s*(?:times|time|x)?)?$|^(up|down|left|right)\\s+(?:scroll|swipe)$").find(text)
        if (movement != null) {
            val actionType = movement.groupValues[1].ifBlank { "scroll" }.lowercase()
            val direction = movement.groupValues[2].ifBlank { movement.groupValues[4] }.lowercase()
            val countToken = movement.groupValues[3].lowercase()
            val count = when (countToken) { "twice" -> 2; "thrice" -> 3; else -> countToken.toIntOrNull() ?: 1 }.coerceIn(1, 4)
            return plan("${actionType.replaceFirstChar { it.uppercase() }} $direction${if (count > 1) " $count times" else ""}.",
                UltronAgentAction(type = actionType, direction = direction, count = count))
        }

        val findVisible = Regex("(?i)^(?:find|locate|search for)\\s+(.+?)\\s+(?:on|in) (?:the )?(?:screen|page)$").find(text)
        if (findVisible != null) return plan(
            "Find the requested text in the current app's visible accessibility content.",
            UltronAgentAction(type = "find_text_on_screen", text = findVisible.groupValues[1].take(180))
        )

        if (Regex("(?i)^(?:play|resume|start)(?:\\s+(?:the|a))?\\s+(?:music|song|audio)$").matches(text) ||
            Regex("(?i)^(?:play|resume)\\s*$").matches(text))
            return plan("Resume the active media session.", UltronAgentAction(type = "media_control", direction = "play"))
        if (Regex("(?i)\\b(pause|stop) (?:the )?(?:music|song|audio|playback)\\b|^pause$|^stop music$").matches(text))
            return plan("Pause the active media session.", UltronAgentAction(type = "media_control", direction = "pause"))
        if (Regex("(?i)^(?:next|skip)(?:\\s+(?:song|track))?$").matches(text))
            return plan("Skip to the next track in the active media session.", UltronAgentAction(type = "media_control", direction = "next"))
        if (Regex("(?i)^(?:previous|last)(?:\\s+(?:song|track))?$").matches(text))
            return plan("Go to the previous track in the active media session.", UltronAgentAction(type = "media_control", direction = "previous"))
        if (Regex("(?i)^play\\s+next\\s+(?:song|track)$").matches(text))
            return plan("Skip to the next track in the active media session.", UltronAgentAction(type = "media_control", direction = "next"))
        if (Regex("(?i)^play\\s+previous\\s+(?:song|track)$").matches(text))
            return plan("Go to the previous track in the active media session.", UltronAgentAction(type = "media_control", direction = "previous"))

        val longPress = Regex("(?i)^(?:long press|long-press|press and hold)\\s+(.+)$").find(text)
        if (longPress != null) return plan(
            "Long-press the named visible control.",
            UltronAgentAction(type = "long_press_text", text = longPress.groupValues[1].take(180))
        )

        val tapNamed = Regex("(?i)^(?:tap|click|press)(?: on)?\\s+(.+)$").find(text)
        if (tapNamed != null && !tapNamed.groupValues[1].isBlank()) return plan(
            "Activate the visible control named '${tapNamed.groupValues[1].take(100)}'.",
            UltronAgentAction(type = "click_text", text = tapNamed.groupValues[1].trim().take(180))
        )
        return null
    }
}
