package com.ultron.assistant

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.JsonParser
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID

/** User-configurable HTTPS integrations. Secrets are encrypted with the app's Android Keystore vault. */
data class WebPlugin(
    val id: String,
    val name: String,
    val urlTemplate: String = "",
    val kind: String = "website", // website | rest | oauth2
    val endpoint: String = "",
    val method: String = "GET",
    val authType: String = "none", // none | bearer | api_key_header | api_key_query | basic
    val credential: String = "",
    val secondaryCredential: String = "",
    val headerName: String = "X-API-Key",
    val bodyTemplate: String = "",
    val oauthAuthorizeUrl: String = "",
    val oauthTokenUrl: String = "",
    val oauthClientId: String = "",
    val oauthClientSecret: String = "",
    val oauthRedirectUri: String = "",
    val oauthScope: String = "",
    val oauthExpiresAt: Long = 0L
)

data class PluginCallResult(val success: Boolean, val statusCode: Int, val body: String)

class PluginStore(context: Context) {
    private val prefs = context.getSharedPreferences("ultron_web_plugins", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun load(): List<WebPlugin> = runCatching {
        val type = object : TypeToken<List<WebPlugin>>() {}.type
        gson.fromJson<List<WebPlugin>>(prefs.getString("plugins", "[]"), type).orEmpty().map(::decryptSecrets)
    }.getOrDefault(emptyList())

    fun save(items: List<WebPlugin>) {
        val protected = items.map(::encryptSecrets)
        prefs.edit().putString("plugins", gson.toJson(protected)).apply()
    }

    fun add(name: String, template: String): WebPlugin {
        val safeName = name.trim().take(60)
        require(safeName.isNotBlank()) { "Enter a plugin name." }
        validateHttps(template)
        val plugin = WebPlugin(UUID.randomUUID().toString(), safeName, template.trim())
        save(load() + plugin)
        return plugin
    }

    fun addIntegration(plugin: WebPlugin): WebPlugin {
        require(plugin.name.isNotBlank()) { "Enter a plugin name." }
        require(plugin.kind in setOf("rest", "oauth2")) { "Choose REST API or OAuth 2.0." }
        validateHttps(plugin.endpoint)
        require(plugin.method in setOf("GET", "POST", "PUT", "PATCH", "DELETE")) { "Unsupported HTTP method." }
        require(plugin.authType in setOf("none", "bearer", "api_key_header", "api_key_query", "basic")) { "Unsupported authentication mode." }
        if (plugin.kind == "oauth2") {
            validateHttps(plugin.oauthAuthorizeUrl)
            validateHttps(plugin.oauthTokenUrl)
            require(plugin.oauthClientId.isNotBlank()) { "OAuth client ID is required." }
            require(plugin.oauthRedirectUri.startsWith("https://") || plugin.oauthRedirectUri.startsWith("ultron://")) { "Use an HTTPS or ultron:// redirect URI." }
        }
        val saved = plugin.copy(id = UUID.randomUUID().toString(), name = plugin.name.trim().take(60))
        save(load() + saved)
        return saved
    }

    fun update(plugin: WebPlugin) { save(load().map { if (it.id == plugin.id) plugin else it }) }
    fun remove(id: String) { save(load().filterNot { it.id == id }) }

    /** Executes a configured REST integration. {query} and {input} are URL-encoded; {rawQuery} is literal JSON/text. */
    suspend fun execute(plugin: WebPlugin, query: String): PluginCallResult = withContext(Dispatchers.IO) {
        require(plugin.kind == "rest" || plugin.kind == "oauth2") { "This is a website shortcut, not an API action." }
        val activePlugin = refreshOAuthTokenIfNeeded(plugin)
        val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name())
        var endpoint = activePlugin.endpoint.replace("{query}", encoded).replace("{input}", encoded)
        if (activePlugin.authType == "api_key_query" && activePlugin.credential.isNotBlank()) {
            val separator = if (endpoint.contains('?')) "&" else "?"
            endpoint += separator + URLEncoder.encode(activePlugin.headerName.ifBlank { "key" }, "UTF-8") + "=" + URLEncoder.encode(activePlugin.credential, "UTF-8")
        }
        validateHttps(endpoint)
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = activePlugin.method
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("Accept", "application/json, text/plain, */*")
            when (activePlugin.authType) {
                "bearer" -> if (activePlugin.credential.isNotBlank()) setRequestProperty("Authorization", "Bearer ${activePlugin.credential}")
                "api_key_header" -> if (activePlugin.credential.isNotBlank()) setRequestProperty(activePlugin.headerName.ifBlank { "X-API-Key" }, activePlugin.credential)
                "basic" -> if (activePlugin.credential.isNotBlank()) {
                    val raw = "${activePlugin.credential}:${activePlugin.secondaryCredential}"
                    val encodedAuth = android.util.Base64.encodeToString(raw.toByteArray(), android.util.Base64.NO_WRAP)
                    setRequestProperty("Authorization", "Basic $encodedAuth")
                }
            }
            if (activePlugin.method in setOf("POST", "PUT", "PATCH")) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                val jsonSafeQuery = Gson().toJson(query).removeSurrounding("\"")
                val body = activePlugin.bodyTemplate.replace("{query}", jsonSafeQuery).replace("{input}", jsonSafeQuery)
                outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }?.take(24_000).orEmpty()
            PluginCallResult(code in 200..299, code, body.ifBlank { "(empty response)" })
        } finally { connection.disconnect() }
    }

    fun beginOAuth(plugin: WebPlugin): String {
        require(plugin.kind == "oauth2")
        val random = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val verifier = android.util.Base64.encodeToString(random, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
        val challenge = android.util.Base64.encodeToString(
            MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)),
            android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING
        )
        val state = android.util.Base64.encodeToString(ByteArray(24).also { SecureRandom().nextBytes(it) }, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
        prefs.edit().putString("oauth_state", PrivateTextVault.encrypt(state)).putString("oauth_verifier", PrivateTextVault.encrypt(verifier)).putString("oauth_plugin_id", plugin.id).apply()
        val base = Uri.parse(plugin.oauthAuthorizeUrl)
        require(base.scheme == "https" && !base.host.isNullOrBlank()) { "OAuth authorization URL must use HTTPS." }
        return base.buildUpon()
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("client_id", plugin.oauthClientId)
            .appendQueryParameter("redirect_uri", plugin.oauthRedirectUri)
            .appendQueryParameter("scope", plugin.oauthScope)
            .appendQueryParameter("state", state)
            .appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("code_challenge_method", "S256")
            .build().toString()
    }

    suspend fun completeOAuthCallback(uri: Uri): String = withContext(Dispatchers.IO) {
        val error = uri.getQueryParameter("error")
        if (!error.isNullOrBlank()) throw IllegalStateException("OAuth provider returned: $error")
        val code = uri.getQueryParameter("code") ?: throw IllegalArgumentException("OAuth callback did not contain an authorization code.")
        val state = uri.getQueryParameter("state") ?: throw IllegalArgumentException("OAuth callback did not contain state.")
        val expectedState = prefs.getString("oauth_state", null)?.let { runCatching { PrivateTextVault.decrypt(it) }.getOrNull() }
        require(expectedState != null && state == expectedState) { "OAuth state validation failed. Start the connection again." }
        val pluginId = prefs.getString("oauth_plugin_id", null) ?: throw IllegalStateException("No pending OAuth integration was found.")
        val verifier = prefs.getString("oauth_verifier", null)?.let { runCatching { PrivateTextVault.decrypt(it) }.getOrNull() }
            ?: throw IllegalStateException("OAuth verifier is missing.")
        val plugin = load().firstOrNull { it.id == pluginId } ?: throw IllegalStateException("The OAuth plugin no longer exists.")
        val params = linkedMapOf(
            "grant_type" to "authorization_code", "code" to code,
            "redirect_uri" to plugin.oauthRedirectUri, "client_id" to plugin.oauthClientId,
            "code_verifier" to verifier
        )
        if (plugin.oauthClientSecret.isNotBlank()) params["client_secret"] = plugin.oauthClientSecret
        val connection = (URL(plugin.oauthTokenUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15_000; readTimeout = 25_000; doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val form = params.entries.joinToString("&") { "${URLEncoder.encode(it.key, "UTF-8")}=${URLEncoder.encode(it.value, "UTF-8")}" }
            connection.outputStream.use { it.write(form.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val response = (if (status in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            require(status in 200..299) { "OAuth token exchange failed (HTTP $status): ${response.take(800)}" }
            val json = JsonParser.parseString(response).asJsonObject
            val accessToken = json.get("access_token")?.asString?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("Token response did not include access_token.")
            val refreshToken = json.get("refresh_token")?.asString.orEmpty()
            val expiresIn = json.get("expires_in")?.asLong ?: 0L
            update(plugin.copy(credential = accessToken, secondaryCredential = refreshToken.ifBlank { plugin.secondaryCredential }, authType = "bearer", oauthExpiresAt = if (expiresIn > 0) System.currentTimeMillis() + expiresIn * 1_000L else 0L))
            prefs.edit().remove("oauth_state").remove("oauth_verifier").remove("oauth_plugin_id").apply()
            "${plugin.name} connected successfully. Access token saved encrypted on this device."
        } finally { connection.disconnect() }
    }

    /** Refreshes an OAuth access token shortly before expiry when the provider issued a refresh token. */
    private fun refreshOAuthTokenIfNeeded(plugin: WebPlugin): WebPlugin {
        if (plugin.kind != "oauth2" || plugin.secondaryCredential.isBlank()) return plugin
        if (plugin.oauthExpiresAt == 0L || plugin.oauthExpiresAt > System.currentTimeMillis() + 60_000L) return plugin
        val params = linkedMapOf(
            "grant_type" to "refresh_token",
            "refresh_token" to plugin.secondaryCredential,
            "client_id" to plugin.oauthClientId
        )
        if (plugin.oauthClientSecret.isNotBlank()) params["client_secret"] = plugin.oauthClientSecret
        val connection = (URL(plugin.oauthTokenUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12_000
            readTimeout = 20_000
            doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val form = params.entries.joinToString("&") { "${URLEncoder.encode(it.key, "UTF-8")}=${URLEncoder.encode(it.value, "UTF-8")}" }
            connection.outputStream.use { it.write(form.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val response = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            require(code in 200..299) { "OAuth refresh failed (HTTP $code): ${response.take(600)}. Reconnect this plugin if the refresh token was revoked." }
            val json = JsonParser.parseString(response).asJsonObject
            val access = json.get("access_token")?.asString?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("OAuth refresh response did not include access_token.")
            val refresh = json.get("refresh_token")?.asString?.takeIf { it.isNotBlank() } ?: plugin.secondaryCredential
            val expires = json.get("expires_in")?.asLong ?: 0L
            val updated = plugin.copy(
                credential = access,
                secondaryCredential = refresh,
                oauthExpiresAt = if (expires > 0) System.currentTimeMillis() + expires * 1_000L else 0L,
                authType = "bearer"
            )
            update(updated)
            return updated
        } finally { connection.disconnect() }
    }

    private fun validateHttps(value: String) {
        val parsed = Uri.parse(value.replace("{query}", "search").replace("{input}", "search"))
        require(parsed.scheme.equals("https", true) && !parsed.host.isNullOrBlank()) { "Only valid HTTPS endpoints are accepted." }
    }

    private fun encryptSecrets(p: WebPlugin) = p.copy(
        credential = PrivateTextVault.encrypt(p.credential),
        secondaryCredential = PrivateTextVault.encrypt(p.secondaryCredential),
        oauthClientSecret = PrivateTextVault.encrypt(p.oauthClientSecret)
    )
    private fun decryptSecrets(p: WebPlugin) = p.copy(
        credential = runCatching { PrivateTextVault.decrypt(p.credential) }.getOrDefault(""),
        secondaryCredential = runCatching { PrivateTextVault.decrypt(p.secondaryCredential) }.getOrDefault(""),
        oauthClientSecret = runCatching { PrivateTextVault.decrypt(p.oauthClientSecret) }.getOrDefault("")
    )

    companion object {
        fun expand(template: String, query: String? = null): String {
            val encoded = URLEncoder.encode(query.orEmpty(), StandardCharsets.UTF_8.name())
            return template.replace("{query}", encoded).replace("{input}", encoded)
        }
    }
}
