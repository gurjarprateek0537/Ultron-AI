package com.ultron.assistant

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.Locale

/** User-editable, on-device command replies inspired by Jarvis's Easter-egg trainer.
 * Rules are stored locally and never override Android permissions or system safeguards.
 */
class UltronPersonalityEngine(context: Context) {
    data class Rule(val triggers: List<String>, val response: String, val exact: Boolean = false)

    private val prefs = context.getSharedPreferences("ultron_personality", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val type = object : TypeToken<MutableList<Rule>>() {}.type

    private val defaults = listOf(
        Rule(listOf("who is your father", "who is your dad", "who is your creator", "who is your developer", "who is ultron's father", "who made you", "who created you", "who built you", "who is your owner", "tell me about your creator", "who developed ultron"),
            "My creator and developer is Prateek Gurjar. He is building ULTRON, with work spanning Android app development, AI integration, local LLM deployment, backend/API configuration, and Android automation design. I don't have verified awards or formal qualifications to claim."),
        Rule(listOf("i am inevitable", "i am iron man"), "And I… am ULTRON. *dramatic pause* ⚡"),
        Rule(listOf("hello ultron", "hi ultron"), "Systems online. What shall we work on?"),
        Rule(listOf("tony stark"), "A legendary engineer. I'm here to help with your next mission."),
        Rule(listOf("mogambo khush hua"), "Mogambo khush hua! 😄"),
        Rule(listOf("protocol 7"), "Protocol 7 acknowledged. Standing by."),
        Rule(listOf("do a barrel roll"), "Barrel roll request received. I can confirm it verbally; I won't pretend to animate the screen."),
        Rule(listOf("sing a song"), "I can improvise an original tune, but I can't provide copyrighted song lyrics.")
    )

    @Synchronized private fun customRules(): MutableList<Rule> = runCatching {
        gson.fromJson<MutableList<Rule>>(prefs.getString("rules", "[]"), type) ?: mutableListOf()
    }.getOrDefault(mutableListOf())

    @Synchronized private fun save(rules: List<Rule>) {
        prefs.edit().putString("rules", gson.toJson(rules)).apply()
    }

    fun match(input: String): String? {
        val normalized = normalize(input)
        if (normalized.isBlank()) return null
        val custom = customRules().asReversed()
        (custom + defaults).firstOrNull { rule -> rule.triggers.any { trigger ->
            val t = normalize(trigger)
            if (rule.exact) normalized == t else normalized.contains(t)
        } }?.let { return it.response }
        return null
    }

    fun train(input: String): String {
        val patterns = listOf(
            Regex("(?i)\\bwhen\\s+(.+?)\\s+say\\s+(.+?)\\s+you\\s+say\\b"),
            Regex("(?i)\\bwhen\\s+(?:i\\s+)?say\\s+(.+?)\\s+you\\s+say\\s+(.+)$"),
            Regex("(?i)\\bjab\\s+(.+?)\\s+toh\\s+(.+?)\\s+bolo\\b"),
            Regex("(?i)\\blearn\\s+new\\s+command\\s*:\\s*(.+?)\\s*=>\\s*(.+)$")
        )
        val match = patterns.firstNotNullOfOrNull { it.find(input) }
            ?: return "Training format: ‘when I say hello you say welcome’ or ‘learn new command: hello => welcome’."
        val trigger = match.groupValues[1].trim().take(100)
        val response = match.groupValues[2].trim().take(1000)
        if (trigger.length < 2 || response.isBlank()) return "Please provide both a trigger and a reply."
        if (normalize(trigger) == normalize(response)) return "The trigger and reply should be different."
        val rules = customRules()
        rules.removeAll { rule -> rule.triggers.any { normalize(it) == normalize(trigger) } }
        rules += Rule(listOf(trigger), response)
        save(rules)
        return "Learned locally: when you say ‘$trigger’, I'll reply ‘$response’."
    }

    fun list(): String {
        val rules = customRules()
        return if (rules.isEmpty()) "No custom replies yet. Teach me with: when I say X you say Y."
        else "Your custom replies:\n" + rules.mapIndexed { i, r -> "${i + 1}. ${r.triggers.joinToString(" / ")} → ${r.response}" }.joinToString("\n")
    }

    fun delete(trigger: String): String {
        val rules = customRules()
        val count = rules.size
        rules.removeAll { rule -> rule.triggers.any { normalize(it).contains(normalize(trigger)) } }
        save(rules)
        return if (rules.size < count) "Removed ${count - rules.size} custom reply rule(s)." else "I couldn't find a custom reply matching ‘$trigger’."
    }

    fun clear(): String {
        save(emptyList())
        return "All custom reply rules have been removed. Built-in replies remain."
    }

    private fun normalize(value: String) = value.lowercase(Locale.ROOT).trim().replace(Regex("\\s+"), " ")
}
