package com.ultron.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import java.util.Locale

/** User-opt-in microphone foreground service. Android's recognizer is restarted after every result/error. */
class UltronWakeWordService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private val restartRunnable = Runnable { if (!destroyed && recognizer != null) startListening() }
    /** A broken OEM recognizer can stop issuing callbacks without reporting an error. */
    private val sessionWatchdog = object : Runnable {
        override fun run() {
            if (destroyed || recognizer == null) return
            val elapsed = SystemClock.elapsedRealtime() - recognizerSessionStartedAt
            if (elapsed >= MAX_RECOGNIZER_SESSION_MS) {
                listening = false
                runCatching { recognizer?.cancel(); recognizer?.destroy() }
                recognizer = null
                updateNotification("Refreshing the speech engine after a long recognition session…", ongoing = true)
                startRecognizer()
            } else {
                main.postDelayed(this, MAX_RECOGNIZER_SESSION_MS - elapsed)
            }
        }
    }
    private var destroyed = false
    private var recognizerSessionStartedAt = 0L
    private var lastDetectedAt = 0L
    private var awaitingCommand = false
    private var awaitingCommandAt = 0L
    private var consecutiveErrors = 0
    private var listening = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                UltronWakeWordPreferences.setEnabled(this, false)
                UltronWakeWordPreferences.setBootResumePending(this, false)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> UltronWakeWordPreferences.setEnabled(this, true)
            ACTION_RESTORE -> if (!UltronWakeWordPreferences.isEnabled(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        if (intent == null && !UltronWakeWordPreferences.isEnabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        val foregroundNotification = buildNotification("Starting wake-word listener…", ongoing = true)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, foregroundNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIFICATION_ID, foregroundNotification)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("No speech recognition service is installed or enabled. Open Android voice input settings.", ongoing = false)
            stopSelf()
            return START_NOT_STICKY
        }
        UltronWakeWordPreferences.setBootResumePending(this, false)
        if (recognizer == null) startRecognizer()
        return START_STICKY
    }

    private fun startRecognizer() {
        main.removeCallbacks(sessionWatchdog)
        val onDeviceAvailable = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        val speech = try {
            if (onDeviceAvailable) {
                runCatching { SpeechRecognizer.createOnDeviceSpeechRecognizer(this) }
                    .getOrElse { SpeechRecognizer.createSpeechRecognizer(this) }
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
        } catch (error: Exception) {
            updateNotification("Speech engine could not start: ${error.message ?: "recognizer unavailable"}", ongoing = false)
            stopSelf()
            return
        }
        recognizer = speech.also {
            val speech = it
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {
                    consecutiveErrors = 0
                    listening = true
                    updateNotification("LISTENING · Say ‘ULTRON’ then your command.", ongoing = true)
                }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) {
                    listening = false
                    main.removeCallbacks(sessionWatchdog)
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        updateNotification("MICROPHONE PERMISSION REQUIRED · Open ULTRON to review permissions.", ongoing = false)
                        stopSelf()
                    } else {
                        consecutiveErrors = (consecutiveErrors + 1).coerceAtMost(8)
                        val delay = (650L * (1L shl (consecutiveErrors - 1))).coerceAtMost(60_000L)
                        updateNotification("Recognizer paused (code $error). Reconnecting in ${delay / 1000}s…", ongoing = true)
                        scheduleRecognizerRecovery(delay)
                    }
                }
                override fun onResults(results: android.os.Bundle?) {
                    listening = false
                    main.removeCallbacks(sessionWatchdog)
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    handleRecognizedPhrase(phrase)
                    scheduleRestart(450)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    // Some OEM services keep returning partial results indefinitely. The
                    // session watchdog bounds that state without interrupting normal short commands.
                    val phrase = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    // Partial hypotheses let a wake word be noticed before the recognizer times out.
                    // The same 8-second cooldown prevents the final result from dispatching twice.
                    val normalized = phrase.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9\\u0900-\\u097f ]"), " ").replace(Regex("\\s+"), " ").trim()
                    val containsWake = listOf("ultron", "अल्ट्रॉन", "अल्ट्रोन").any { normalized.contains(it) }
                    val hasCommandAfterWake = listOf("ultron", "अल्ट्रॉन", "अल्ट्रोन").any { token ->
                        val position = normalized.indexOf(token)
                        position >= 0 && normalized.substring(position + token.length).isNotBlank()
                    }
                    if (phrase.isNotBlank() && !awaitingCommand && containsWake && hasCommandAfterWake) handleRecognizedPhrase(phrase)
                }
                override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
            })
        }
        startListening()
    }

    private fun handleRecognizedPhrase(raw: String) {
        val phrase = raw.trim()
        val normalized = phrase.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9\\u0900-\\u097f ]"), " ").replace(Regex("\\s+"), " ").trim()
        val wakeTokens = listOf("ultron", "अल्ट्रॉन", "अल्ट्रोन")
        val matchedWake = wakeTokens.firstOrNull { normalized.contains(it) }
        val wakeIndex = matchedWake?.let { normalized.indexOf(it) } ?: -1
        if (awaitingCommand && phrase.isNotBlank()) {
            val withinCommandWindow = System.currentTimeMillis() - awaitingCommandAt <= 15_000L
            awaitingCommand = false
            if (withinCommandWindow) enqueueBackgroundCommand(phrase)
            else updateNotification("Wake word command window expired. Say ULTRON again.", ongoing = true)
            return
        }
        if (wakeIndex >= 0 && System.currentTimeMillis() - lastDetectedAt > 8_000L) {
            lastDetectedAt = System.currentTimeMillis()
            val command = normalized.substring(wakeIndex + (matchedWake?.length ?: "ultron".length)).trim()
            if (command.isNotBlank()) enqueueBackgroundCommand(command)
            else {
                awaitingCommand = true
                awaitingCommandAt = System.currentTimeMillis()
                updateNotification("Wake word detected. Listening for your command…", ongoing = true)
                val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                runCatching { manager.notify(DETECTED_NOTIFICATION_ID, buildNotification("I heard ‘Ultron’. Say your command now.", ongoing = false)) }
            }
        }
    }

    private fun enqueueBackgroundCommand(command: String) {
        val decision = command.trim().lowercase(Locale.ROOT).replace(Regex("[.!?,]+$"), "")
        val approveWords = setOf("yes", "yes please", "confirm", "approve", "haan", "हाँ", "जी हाँ", "कर दो", "करें")
        val rejectWords = setOf("no", "no thanks", "cancel", "reject", "nahi", "नहीं", "मत करो", "रद्द")
        if (decision in approveWords || decision in rejectWords) {
            val pendingId = UltronPendingActionStore.latestId(applicationContext)
            if (!pendingId.isNullOrBlank()) {
                UltronAgentApprovalReceiver.applyDecision(applicationContext, pendingId, decision in approveWords)
                updateNotification(if (decision in approveWords) "Voice YES received · executing approved task…" else "Voice NO received · task cancelled.", ongoing = true)
                return
            }
        }
        updateNotification("ULTRON AI agent is planning your command in the background…", ongoing = true)
        try {
            UltronAgentWorker.enqueue(applicationContext, command)
            UltronAgentNotifications.show(applicationContext, "ULTRON · Command received", "Working on: ${command.take(180)}", 7330)
        } catch (e: Exception) {
            updateNotification("Could not queue command: ${e.message ?: "background scheduler error"}", ongoing = true)
        }
    }

    private fun startListening() {
        val speech = recognizer ?: return
        if (listening) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, VoiceOutputStore(this@UltronWakeWordService).load().language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1_200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
        }
        recognizerSessionStartedAt = SystemClock.elapsedRealtime()
        main.removeCallbacks(sessionWatchdog)
        main.postDelayed(sessionWatchdog, MAX_RECOGNIZER_SESSION_MS)
        runCatching { speech.startListening(intent) }.onFailure {
            main.removeCallbacks(sessionWatchdog)
            // Recreate the recognizer after a synchronous start failure; retrying the same
            // broken OEM instance can otherwise leave the listener permanently idle.
            scheduleRecognizerRecovery(1_200)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, delayMs)
    }

    private fun scheduleRecognizerRecovery(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        main.postDelayed({
            if (destroyed) return@postDelayed
            runCatching { recognizer?.cancel(); recognizer?.destroy() }
            recognizer = null
            startRecognizer()
        }, delayMs)
    }

    private fun showWakeNotification() {
        updateNotification("Wake word detected. Say your command; ULTRON will process it in the background.", ongoing = true)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "ULTRON wake word", NotificationManager.IMPORTANCE_LOW))
            }
            if (manager.getNotificationChannel(DETECTED_CHANNEL_ID) == null) {
                manager.createNotificationChannel(NotificationChannel(DETECTED_CHANNEL_ID, "ULTRON wake word detected", NotificationManager.IMPORTANCE_HIGH))
            }
            if (manager.getNotificationChannel(BOOT_CHANNEL_ID) == null) {
                manager.createNotificationChannel(NotificationChannel(BOOT_CHANNEL_ID, "ULTRON wake-word restart", NotificationManager.IMPORTANCE_DEFAULT))
            }
        }
    }

    private fun updateNotification(text: String, ongoing: Boolean) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        runCatching { manager.notify(NOTIFICATION_ID, buildNotification(text, ongoing)) }
    }

    private fun buildNotification(text: String, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 314, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 315, Intent(this, UltronWakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, if (ongoing) CHANNEL_ID else DETECTED_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (ongoing) "ULTRON · Wake word" else "ULTRON")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(ongoing)
            .addAction(android.R.drawable.ic_media_pause, "Stop listening", stop)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        main.removeCallbacks(restartRunnable)
        main.removeCallbacks(sessionWatchdog)
        destroyed = true
        runCatching { recognizer?.cancel(); recognizer?.destroy() }
        recognizer = null
        listening = false
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.ultron.assistant.WAKE_WORD_START"
        const val ACTION_STOP = "com.ultron.assistant.WAKE_WORD_STOP"
        const val ACTION_RESTORE = "com.ultron.assistant.WAKE_WORD_RESTORE"
        const val EXTRA_WAKE_COMMAND = "com.ultron.assistant.EXTRA_WAKE_COMMAND"
        const val CHANNEL_ID = "ultron_wake_word"
        const val DETECTED_CHANNEL_ID = "ultron_wake_detected"
        const val BOOT_CHANNEL_ID = "ultron_wake_boot"
        const val NOTIFICATION_ID = 7310
        const val DETECTED_NOTIFICATION_ID = 7311
        private const val MAX_RECOGNIZER_SESSION_MS = 60_000L
    }
}
