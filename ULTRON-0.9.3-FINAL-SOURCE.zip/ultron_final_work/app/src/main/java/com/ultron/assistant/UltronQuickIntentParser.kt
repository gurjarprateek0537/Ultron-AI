package com.ultron.assistant

/** Deterministic parser for common compound app-search requests. */
data class UltronAppSearchCommand(val appLabel: String, val query: String, val shouldOpenResult: Boolean = false)

object UltronQuickIntentParser {
    private val supportedApps = listOf(
        "YouTube Music", "Google Maps", "Play Store", "YouTube", "Chrome", "Google", "Maps", "Gmail", "Spotify", "Instagram", "WhatsApp", "Telegram", "Facebook", "Reddit", "X"
    )
    private val appPattern = supportedApps.joinToString("|") { Regex.escape(it) }
    private val playOnApp = Regex("(?i)^(?:please\\s+)?(?:play|listen\\s+to)\\s+(.+?)\\s+(?:on|in)\\s+(YouTube\\s+Music|Spotify|YouTube)[.!?]*$")
    private val playDefault = Regex("(?i)^(?:please\\s+)?(?:play|listen\\s+to)\\s+(.+?)[.!?]*$")
    private val openThenSearch = Regex(
        "(?i)^(?:please\\s+)?(?:open|launch|start)\\s+(?:the\\s+)?($appPattern)(?:\\s+app)?\\s*(?:[,;:.!?–-]\\s*|\\s+)(?:(?:and\\s+then|then|and|after\\s+that)\\s+)?(?:please\\s+)?(?:search|find|look\\s+for)(?:\\s+for)?\\s+(.+?)\\s*(?:please)?[.!?]*$"
    )
    private val searchInApp = Regex(
        "(?i)^(?:please\\s+)?(?:search|find|look\\s+for)(?:\\s+for)?\\s+(.+?)\\s+(?:on|in)\\s+($appPattern)(?:\\s+app)?[.!?]*$"
    )
    private val hinglishQueryFirst = Regex(
        "(?i)^($appPattern)(?:\\s+app)?\\s+(?:kholo?|khol\\s+do|open\\s+karo|launch\\s+karo)\\s+(?:aur|phir|fir)\\s+(.+?)\\s+(?:search|find)\\s+karo[.!?]*$"
    )
    private val hinglishSearchFirst = Regex(
        "(?i)^($appPattern)(?:\\s+app)?\\s+(?:kholo?|khol\\s+do|open\\s+karo|launch\\s+karo)\\s+(?:aur|phir|fir)\\s+(?:search|find|khojo|dhundo|dhoondo)(?:\\s+karo)?\\s+(.+?)[.!?]*$"
    )
    private val hinglishSearchInApp = Regex(
        "(?i)^($appPattern)\\s+(?:mein|me)\\s+(.+?)\\s+(?:search\\s+karo|khojo|dhundo|dhoondo)[.!?]*$"
    )
    private val hindiScriptSearchInApp = Regex(
        "^($appPattern)(?:\\s+app)?\\s+(?:में|मे)\\s+(.+?)\\s+(?:सर्च\\s+करो|खोजो|ढूंढो|ढूँढो)[.!?]*$"
    )
    private val hindiScriptOpenThenSearch = Regex(
        "^($appPattern)(?:\\s+app)?\\s+(?:खोलो|खोल|खोल\\s+दो)\\s+(?:और|फिर)\\s*(.+?)\\s*(?:सर्च\\s+करो|खोजो|ढूंढो|ढूँढो)[.!?]*$"
    )

    fun appSearchCommand(request: String): UltronAppSearchCommand? {
        val clean = request.trim()
            .replace(Regex("(?i)^\\s*(?:hey\\s+)?ultron[\\s,:;.!-]*"), "")
            .trim()
        playOnApp.find(clean)?.let { found ->
            val query = found.groupValues[1].trim().replace(Regex("(?i)^(?:the\\s+)?(?:song|track)\\s+"), "").trim().trimEnd('.', '!', '?').take(300)
            val app = supportedApps.firstOrNull { it.equals(found.groupValues[2].trim(), true) }
            if (query.isNotBlank() && app != null) return UltronAppSearchCommand(app, query, shouldOpenResult = true)
        }
        playDefault.find(clean)?.let { found ->
            val raw = found.groupValues[1].trim()
            if (raw.isNotBlank() && !raw.equals("music", true) && !raw.equals("a song", true) && !raw.equals("something", true)) {
                val query = raw.replace(Regex("(?i)^(?:the\\s+)?(?:song|track)\\s+"), "").trim().take(300)
                if (query.isNotBlank()) return UltronAppSearchCommand("YouTube", query, shouldOpenResult = true)
            }
        }
        val matches = listOf(
            openThenSearch.find(clean) to true,
            searchInApp.find(clean) to false,
            hinglishQueryFirst.find(clean) to true,
            hinglishSearchFirst.find(clean) to true,
            hinglishSearchInApp.find(clean) to true,
            hindiScriptSearchInApp.find(clean) to true,
            hindiScriptOpenThenSearch.find(clean) to true
        )
        val match = matches.firstOrNull { it.first != null } ?: return null
        val found = match.first!!
        val appFirst = match.second
        val app = found.groupValues.getOrNull(if (appFirst) 1 else 2).orEmpty()
        val rawQuery = found.groupValues.getOrNull(if (appFirst) 2 else 1).orEmpty()
        val query = rawQuery.trim().trimEnd('.', '!', '?', ',').trim()
            .removeSurrounding("\"", "\"")
            .removeSurrounding("'", "'")
            .trim()
            .take(300)
        if (query.isBlank()) return null
        val normalizedApp = supportedApps.firstOrNull { it.equals(app, ignoreCase = true) } ?: return null
        return UltronAppSearchCommand(normalizedApp, query)
    }

    /** Kept for compatibility with existing tests/callers. */
    fun youtubeSearchQuery(request: String): String? = appSearchCommand(request)
        ?.takeIf { it.appLabel.equals("YouTube", ignoreCase = true) }
        ?.query
}
