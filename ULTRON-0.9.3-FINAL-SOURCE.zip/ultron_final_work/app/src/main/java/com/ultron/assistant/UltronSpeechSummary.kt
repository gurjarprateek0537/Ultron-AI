package com.ultron.assistant

/** Keeps the full response on screen while producing a short, speakable outcome. */
object UltronSpeechSummary {
    fun from(raw: String, maxChars: Int = 180): String {
        val text = raw
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .lineSequence()
            .map { it.trim().replace(Regex("^(?:#{1,6}\\s*|[-*•]\\s+|\\d+[.)]\\s+)"), "") }
            .filter { it.isNotBlank() }
            .filterNot { it.matches(Regex("(?i)(summary|details|sources|references|key takeaways)[:.]?")) }
            .joinToString(" ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (text.isBlank()) return "I couldn't produce a spoken response."
        val firstSentence = Regex("^(.{1,${maxChars.coerceAtLeast(40)}}?[.!?])(?:\\s|$)")
            .find(text)?.groupValues?.getOrNull(1)
        val chosen = firstSentence ?: text.take(maxChars.coerceAtLeast(40)).let {
            if (text.length > it.length) it.substringBeforeLast(' ').ifBlank { it } + "…" else it
        }
        return chosen.replace(Regex("[*_`#]"), "").trim()
    }
}
