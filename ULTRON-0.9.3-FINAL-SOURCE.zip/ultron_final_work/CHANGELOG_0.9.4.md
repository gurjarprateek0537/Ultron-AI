# ULTRON 0.9.4

- Wake-word partial recognition no longer launches truncated commands; partial/final hypotheses are merged and transient speech errors recover quickly.
- Concise spoken outcomes across chat, vision and background agent flows.
- Sensitive-only confirmation policy; ordinary typing, drafts, navigation and gestures no longer prompt for approval.
- WhatsApp/SMS compose opens drafts only; explicit Send is a separate confirmed action.
- Shared chat/voice YES-NO parser and duplicate approval prevention.
- Media volume percentage uses nearest device step and readback.
- Screen wake action added without bypassing the lock screen; screen on/off command parsing added.
- Regression tests and updated build/verification documentation.
