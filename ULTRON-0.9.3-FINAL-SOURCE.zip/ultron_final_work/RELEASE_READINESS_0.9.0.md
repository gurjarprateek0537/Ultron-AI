# ULTRON 0.9.0 release readiness

## Included in the source archive

- Persistent wake-word opt-in and a visible microphone foreground service.
- Boot/package-replacement restoration where Android permits it, plus Android 14+ resume notification flow.
- SpeechRecognizer restart/backoff, a bounded session watchdog, on-device-engine preference/fallback and duplicate wake detection.
- Expanded Accessibility actions and deterministic phone-command parsing.
- Device controls exposed by public Android APIs, with system restrictions surfaced to the user.
- AI online/local/Hybrid foundations, existing memory, plugins, browser, voice and vision paths.
- New dashboard hero artwork and separate voice animation GIF.
- Unit tests for deterministic device parsing, reboot policy, safety/recovery and execution reporting, plus a GitHub Actions workflow for unit tests and debug APK build.

## Build commands on an Android build host

```bash
gradle --version
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:assembleDebug
```

Expected debug artifact after a successful build:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The project does not include a Gradle wrapper. The current authoring workspace has Java but no Gradle executable, Android SDK or NDK, so it cannot produce a verified APK here. Use the included GitHub Actions workflow or a correctly configured Android build machine. Do not distribute an APK until CI and device tests pass.

## Wake-word reality

The wake-word implementation uses Android `SpeechRecognizer` in a microphone foreground service. It is not a dedicated offline hotword engine and cannot be guaranteed to stay alive indefinitely. The app remembers the user's opt-in. On Android 14+, the boot receiver posts a resume notification because an ordinary app cannot freely start a microphone foreground service from `BOOT_COMPLETED`; the user must tap it. OEM battery/autostart settings can still stop the service.

## Device-control reality

ULTRON can request only actions Android exposes to a normal user-installed app and actions available through user-enabled Accessibility. A normal app cannot silently power off/reboot a device or bypass secure screens, app permissions, protected fields or every custom UI. These actions must remain transparent and may require confirmation or user interaction.
