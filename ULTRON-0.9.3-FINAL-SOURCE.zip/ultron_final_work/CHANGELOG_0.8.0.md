# ULTRON 0.8.0 — audited agent and local inference update

## Phone control and task execution
- Compound search commands for YouTube, Chrome, Google, Google Maps/Maps, Play Store, Gmail and Spotify are parsed locally, including “open YouTube and then search BMW”, “launch YouTube then search for BMW M5”, “search lofi music on YouTube”, Chrome/Maps/Play Store/Spotify searches, quoted queries and common Hinglish/Hindi forms. They run a deterministic app-control sequence: open the named app, wait, search the exact query, wait, and inspect the screen. The app-scoped results-link fallback remains YouTube-only.
- If a YouTube release hides its search field from Accessibility, ULTRON tries the encoded results deep link inside the YouTube package and reports whether the query could be verified.
- Accessibility text matching now walks the visible UI tree and checks text, content descriptions, hints and view IDs, then clicks a suitable node or clickable ancestor.
- Search field focus requires a semantic search/address identifier. ULTRON no longer guesses that an arbitrary lone text field is a search field, and generic text entry only fills the currently focused editable node.
- Search execution retries focus once after a Search control opens an overlay, submits through the IME action where Android supports it, or tries visible localized Search controls. It does not use generic Submit/Go controls. It checks whether visible screen content changed after submission and reports unverified results honestly.
- App launch waits for the intended package to become the verified foreground app before the executor continues. An unexpected foreground-package change stops the sequence.
- Agent execution allows one bounded recovery-plan attempt after a non-sensitive navigation/search failure. The recovery planner receives the current foreground package and visible screen text, cannot use free-form text entry, taps, calls, messages or plugins, and is capped at six safe navigation/search steps.
- Local mode is allowed to plan Android tasks as well as online mode. Sensitive operations continue to require explicit approval.
- Added an explicit Hybrid inference mode: it tries the selected online endpoint, then up to four enabled same-role online profiles, then a configured local GGUF model. Provider transitions are reported in the response; cancellation is never mistaken for a provider failure.
- Screen text included in a recovery prompt is supplied only when the selected inference mode is LOCAL. In ONLINE and HYBRID modes, screen text is withheld from recovery prompts; prior `read_screen` details are redacted from recovery context.

## Local model and inference
- Local JNI inference now supplies role/content messages to llama.cpp and uses the GGUF model's declared default chat template instead of hand-written `System:` / `User:` role labels.
- Local context budgeting preserves the latest user request, bounds oversized system context and keeps recent history within the device's conservative RAM-based context size.
- The upstream llama.cpp dependency is pinned to `v1.0.0` rather than the moving `master` branch. This tag provides the C chat-template APIs used by this integration. Template-specific GGUF features outside llama.cpp's supported template subset may still fail clearly rather than silently using a wrong prompt.

## Creator identity and compatibility
- Creator questions have deterministic replies naming Prateek Gurjar and describing project-demonstrated skills only. Awards, degrees and unsupported personal achievements are not fabricated.
- Retains minSdk 26, compile/target SDK 35, versionCode 14 and versionName 0.8.0. Existing voice, memory, browser, plugins, notes, vision endpoint integration and online provider profiles are retained.

## Verification status
- Added parser tests for YouTube and other common-app searches, quoted queries, Hinglish/Hindi, and unsupported-app rejection; added safety/recovery policy, Hybrid-mode and local context-budget tests.
- Added a context-budget test for a small local context and an oversized system prompt.
- A full Android Gradle/NDK build and real-device accessibility test have not been run in this environment. YouTube UI accessibility labels and IME behavior vary by app release, Android version, keyboard and OEM; the agent intentionally stops when it cannot identify a safe search field or verify the target app.


### Advanced phone-control hardening
- YouTube compound requests now receive a deterministic five-step app task: open YouTube, wait, search the exact query, wait, then inspect the visible screen. They no longer depend on an LLM remembering the second half of a compound request.
- When YouTube does not expose its search widget to Accessibility, ULTRON tries an app-scoped YouTube results link and reports whether the query was actually visible.
- Automatic search typing now requires a semantic search-field label or view ID; unrelated focused fields are rejected. Generic `type_text` actions require explicit YES approval.
- `submit_search` no longer uses generic Submit/Go controls and only invokes the keyboard search action on a semantically identified search editor.
- Permission granting, authorization, sign-in, downloads, and other consequential visible controls now require approval.
- Cancellation is propagated correctly through agent execution and recovery; Hybrid local fallback preserves the selected specialist role; execution reports separate completed actions from independently verified actions.
- Local GGUF tokenization now parses the chat-template special tokens without adding another automatic BOS token after template expansion.
