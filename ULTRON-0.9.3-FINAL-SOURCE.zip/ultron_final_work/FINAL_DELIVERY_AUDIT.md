# ULTRON 0.9.1 — Source reconstruction and verification audit

## What was done to the uploaded sources

The uploaded source ZIPs were unpacked and compared by relative path and SHA-256 content hash.

| Measure | Result |
|---|---:|
| Files in supplied 0.8.0 source | 69 |
| Files in supplied 0.9.0 source | 79 |
| 0.8.0 file paths absent from 0.9.0 | 0 |
| 0.9.0 files whose contents differ from 0.8.0 | 20 |
| New 0.9.0 file paths | 10 |
| Files in this 0.9.1 source project (including release notes/audit additions) | 82 |

Method: create the output tree from the 0.8.0 source, then replace only files whose content changed in 0.9.0 and copy paths introduced by 0.9.0. No nested source archives are included and no 0.8-only file path was removed. The supplied design-reference images are retained.

## Feature inventory present in source

| Feature group | Source files/implementation | Verification boundary |
|---|---|---|
| AI providers | `Inference.kt`, `NativeLlamaRuntime.kt`, settings/profile code | Online credentials/endpoints and local GGUF model are user-provided; network/model compatibility needs runtime testing. |
| Local GGUF inference | JNI bridge and `app/src/main/cpp` llama.cpp build | Native CMake/NDK build not run in this environment. |
| Agent planner/executor | `UltronAgentEngine.kt`, bounded JSON allow-list, sequential actions and verification reporting | AI interpretation and third-party app layouts vary. A plan is not guaranteed to succeed. |
| Compound app search | `UltronQuickIntentParser.kt` plus `search_in_app` executor | YouTube/Chrome/other app UI behavior requires device testing. |
| Accessibility | `UltronAccessibilityService.kt` | User must enable the service; secure windows and custom controls can be inaccessible. |
| Screen text search | Accessibility node search plus ML Kit OCR using Android screenshot capture on API 30+ | API 26–29 use accessibility text only; secure-window screenshot is blocked. |
| Gestures | Tap, double tap, long press, swipe, directional scroll and drag | Coordinates and gesture acceptance are app/device dependent; higher-impact gestures require approval. |
| Device controls | Volume, media, brightness with special access, flashlight, lock, power menu, quick settings, notifications, recent apps, settings panels | Direct shutdown/reboot, powering on a shut-down phone, and unrestricted Wi-Fi/Bluetooth toggles are unavailable to an ordinary app. |
| Wake word | `UltronWakeWordService.kt`, persisted user opt-in, restart/backoff/watchdog and Stop notification | Uses Android SpeechRecognizer, not a dedicated low-power hotword engine; no guarantee of uninterrupted listening. |
| Boot restoration | `UltronWakeWordPreferences.kt`, `UltronBootReceiver` | Android 14+ requires a user-resume step after boot; OEM autostart/battery rules can still stop it. |
| Background commands | WorkManager queue and encrypted pending actions/history | WorkManager is OS-scheduled; background launches may be restricted. |
| Approvals/security | Explicit YES/NO gates, encrypted pending plans and audit history | A confirmation does not prove third-party side effects or delivery. |
| Vision | Foreground camera image capture and online multimodal request path | Requires camera permission and an image-capable configured endpoint; not local vision or continuous video. |
| Memory/files/browser/plugins | Room memory, archives, notes/documents, browser, REST/OAuth foundations | Provider credentials, scopes and endpoints need user setup and service-specific tests. |
| UI/visual assets | `ultron_hero.png`, `ultron_voice_core.gif`, splash overlay | Visual scaling and GIF performance still need checking on physical screens. |

## Checks actually run in the authoring container

- Compared both source ZIP contents by file path and SHA-256; confirmed all 69 0.8.0 paths exist in 0.9.0.
- Compiled the deterministic device-command parser and compound app-search parser in isolation with Kotlin/JVM 1.9.0 and temporary model stubs.
- Passed 23 deterministic device parser cases, 2 compound app-search cases (English and Hinglish), and the powered-off-phone rejection boundary.
- Parsed Android XML resources and manifest using Python XML parser.
- Parsed workflow YAML using a YAML 1.2-compatible base loader.
- Checked ZIP contents and archive integrity after packaging.

The isolated parser check is not the Android unit-test task and does not type-check or compile the full Android app.

## Not verified

- No Gradle build, Android resource compile, KSP run, Compose compile, JNI/NDK/CMake build, or complete `:app:testDebugUnitTest` task was run here.
- No APK has been produced, signed, installed or tested in this authoring container.
- No emulator or physical Android device was available for this source verification.
- OPPO/ColorOS wake-word persistence, reboot resume, background process survival, microphone duration, Accessibility gestures and target-app selectors are not device-verified.

## Release gate

1. Push this project to GitHub and run **ULTRON Android CI**.
2. Fix any failing Gradle, Kotlin, KSP, Android resource, CMake or NDK step reported by CI.
3. Download the workflow artifact only after the job succeeds.
4. Install on API 27 (OPPO Android 8.1), API 30, API 34 and API 35 test devices/emulators where available.
5. Test compound YouTube search, other app search, text entry, visible-text search, scrolling in all directions, named click, long press, double tap, drag, volume, media, brightness, flashlight, power menu and approval boundaries.
6. Test wake-word operation for extended periods with display off, after reboot and under OEM battery controls. Record any drops/restarts.

Do not describe this source as build-verified until the GitHub workflow succeeds. Do not describe phone behavior as fully tested until the target-device checks pass.
