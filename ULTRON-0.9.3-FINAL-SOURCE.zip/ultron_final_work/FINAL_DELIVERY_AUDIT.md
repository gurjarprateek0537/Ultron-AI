# ULTRON 0.9.4 — source delivery audit

## Input

- Source archive supplied in the project: `ULTRON-0.9.3-FINAL-SOURCE.zip`.
- The archive contained 87 entries and passed its initial ZIP integrity check.
- It contained source, tests, workflow and design references, but no `.apk` file.

## Source changes

- Fixed wake-word partial-result handling so incomplete intermediate phrases cannot prematurely dispatch truncated commands; merged partial/final recognizer hypotheses and bounded recovery delays.
- Added concise TTS summaries while preserving full visible responses.
- Narrowed confirmations to high-impact side effects; made WhatsApp/SMS actions draft-only and separated explicit sending.
- Unified voice/chat YES-NO parsing and added a duplicate-approval guard for each pending plan.
- Set media volume to the nearest available step and read back the actual level.
- Added a screen wake action and parser support for screen on/off commands while retaining Android lock/power restrictions.
- Added regression tests and 0.9.4 build/implementation notes.

## Preserved

The existing Compose UI, AI modes, inference profiles, local GGUF/JNI foundations, memory/archive, browser, plugins, vision foundations, notification support, permissions, security, artwork and other source paths were retained. No autonomy-mode UI or mode selector was added.

## Verification

13 isolated Kotlin checks, Android XML parsing and workflow YAML parsing passed. The complete Android build and JUnit suite were not run because Gradle and Android SDK are absent in the workspace. The source archive has no APK, and no physical device was available.

## Release gate

1. Run `.github/workflows/android.yml` on GitHub and require a green test/build job.
2. Install the produced APK on OPPO CPH1803 / Android 8.1.
3. Test wake-word recognition for extended periods, partial commands, separate wake-word/command utterances, and after screen-off/reboot.
4. Test compound commands in Instagram/WhatsApp/Telegram/Chrome/Settings and other apps; verify every step and ensure message drafts are not sent without explicit confirmation.
5. Test volume readback, screen wake, screen lock, power menu, and YES/NO through both chat and voice.

Do not call this archive build-verified or device-verified until those release gates pass.
