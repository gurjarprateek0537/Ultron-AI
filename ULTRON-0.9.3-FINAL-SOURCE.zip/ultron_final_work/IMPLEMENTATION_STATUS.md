# ULTRON 0.9.1 — Implementation and verification status

This file distinguishes features present in source from features proven by a successful Android build or phone test. Version is `0.9.1` / versionCode `16`; minSdk 26, targetSdk 35.

## Implemented in source

| Area | Source implementation | Boundary |
|---|---|---|
| Online AI | OpenAI-compatible `/chat/completions`, InstaBox settings, named profiles, active profile, transient retry | Requires user endpoint/model/key; backend availability is external. |
| Local/Hybrid AI | GGUF import, native llama.cpp JNI, chat-template formatting, local mode and Hybrid fallback routing | Native build and device memory/performance require validation. |
| AI task planner | Bounded JSON plan, allow-listed actions, English/Hindi/Hinglish support, max 24 actions, deterministic parsers | Ambiguous instructions can be misunderstood. Model output is validated; no model-generated code is executed. |
| Action execution | App launch, semantic click/search/type, directional scroll/swipe, tap/double tap/long press/drag, Back/Home, URL, contacts, SMS/WhatsApp/call and plugins | Accessibility must be enabled; sensitive actions require explicit approval; apps may hide controls. |
| Compound search | Deterministic app/query parser and multi-step open → semantic search → submit → inspect → optionally open result | App-specific layout and package availability vary. |
| Verification/recovery | Foreground package and visible text snapshots, field readback, accepted/verified distinction, one bounded safe navigation/search recovery | UI change does not prove external delivery or backend side effect. |
| Background agent | Encrypted command queue and serial WorkManager execution with notifications and selected TTS | WorkManager is scheduled work, not an unrestricted real-time daemon. |
| Device controls | Media volume, media transport, brightness with Modify System Settings access, torch, lock, settings panels, quick settings, notifications, recent apps and power menu | Normal apps cannot silently shut down/reboot or power on a fully shut-down phone. |
| Screen find | Accessibility-tree find plus on-device ML Kit OCR using Accessibility screenshot API on Android 11+ | Secure screens block capture; older versions use accessibility text only. |
| Wake word | User-opt-in SpeechRecognizer foreground service, saved preference, partial-result detection, session watchdog, restart/backoff and Stop notification | Not a dedicated acoustic hotword engine and cannot be promised to stay active forever. |
| Boot resume | Boot/package-replacement receiver restores where allowed; Android 14+ posts a notification to resume after user opens ULTRON | OEM background/auto-start and battery settings remain relevant. |
| Confirmations | Encrypted pending action store, expiry, YES/NO notification/voice response, encrypted audit history | Approval is a user authorization, not proof an app completed a transaction. |
| Vision/voice | Foreground camera image analysis via compatible online multimodal profile; Android speech and TTS configuration | No local vision model or background camera; TTS depends on installed engine voices. |
| Memory/modules | Room memory/archive, notes/documents, browser, REST and generic OAuth PKCE plugin foundations | Provider-specific setup and integration testing required. |
| Artwork | New dashboard hero, separate voice GIF and animated startup overlay | Device density/performance visual check remains. |

## Checks run while preparing 0.9.1

- Compared the uploaded 0.8.0 and 0.9.0 trees; preserved all 0.8.0 paths and applied the changed/new 0.9.0 paths.
- Isolated Kotlin/JVM parser validation: 23 device-command cases + 2 compound app-search cases + powered-off-phone boundary passed.
- Android XML/resource parsing and workflow YAML parsing passed.
- Archive integrity check passed after source packaging.

## Still required

No full Gradle/Android/KSP/Compose/NDK build or Android unit-test task has been run in this authoring workspace. No APK was generated, signed, installed or exercised on a device. The GitHub Actions workflow is intended to perform the first full build and unit-test run. A green workflow is required before calling the source build-verified; physical device testing is required before claiming phone features are fully working.

See `FINAL_DELIVERY_AUDIT.md` for the source comparison, feature boundaries and release gate. See `BUILDING_0.9.1.md` for the GitHub Actions procedure.
