# ULTRON 0.9.6 — implementation and verification status

## 0.9.6 fixes in this source tree

- Wake-word partial-result recovery for Android/OEM recognizers that end a useful partial hypothesis with `ERROR_NO_MATCH` or `ERROR_SPEECH_TIMEOUT`; accepts common `ultra` transcription.
- Deterministic alarm-clock intent routing for explicit 12-hour and 24-hour requests. Android intent acceptance is not the same as reading back the Clock app's private alarm database.
- Instagram and additional popular apps added to deterministic open-and-search parsing.
- Android 8.x IME search-key activation is supported by inspecting only the input-method accessibility window and requiring an exact Search/Go/Enter label.

The earlier advanced capability foundations below remain partial where explicitly described; this patch does not turn them into complete production features.

# ULTRON 0.9.5 — implementation and verification status

## Working source paths present

| Capability | Source implementation | Boundary |
|---|---|---|
| Universal multi-app automation | Existing model-planned allow-listed actions, accessibility inspection, semantic targeting, gestures, waits, verification and bounded recovery | App-specific UI exposure, Android background limits and secure/custom screens still constrain coverage; not universally guaranteed |
| Multi-agent collaboration | Existing All-in-One response path plus new bounded specialist-agent coordinator contract | Durable shared state, configured specialist providers and a full verifier/executor loop remain incomplete |
| Notification intelligence | Opt-in active-notification reader, in-memory access, bounded text and sensitive-number filtering; dashboard access control | No complete ranking, AI digest, quick-reply or notification action workflow |
| Clipboard workflows | Read/copy helpers and safe clipboard preview | Cross-app paste/translation/structured extraction workflows are not fully integrated |
| Routines | Persistent routine definitions and dashboard editor | Full calendar/trigger UI and scheduler-to-executor wiring are incomplete |
| File management | SAF folder picker/listing and SHA-256 helper | No broad-storage access, mass cleanup, photo duplicate UI or destructive bulk manager |
| Natural-language app development | App-private project workspace with path validation and bounded file writes | No complete IDE/compiler/preview/test runner/APK builder; generated code is not executed |
| Network diagnostics | Active transport, connectivity validation, metering and roaming inspection | Does not probe arbitrary remote endpoints or alter Wi-Fi/mobile settings |
| Developer SDK / marketplace | Capability-declared skill interface and in-process registry | No signed remote marketplace or third-party code loader/sandbox |
| Local vision | On-device ML Kit OCR helper; existing foreground camera and online vision endpoint | Not a local multimodal VLM; device/API/language support is limited |

## Previous 0.9.4 reliability work retained

Wake-word recognizer recovery, concise spoken summaries, sensitive-action confirmation policy, draft-before-send flow, YES/NO parsing, volume readback, screen wake request, accessibility planner/executor and prior AI/memory/browser/plugin/native foundations remain in the source tree. See `ULTRON_0.9.4_UPGRADE_NOTES.md`.

## Verification boundary

- Source archive integrity is checked after packaging.
- Android Gradle/Kotlin/Compose/KSP/NDK build was not run: no Gradle executable or Android SDK is available in this workspace.
- No emulator or physical phone was available.
- No claim is made that the new or retained features have been fully runtime-tested.
- CI and physical testing on OPPO CPH1803 / Android 8.1 are required.
