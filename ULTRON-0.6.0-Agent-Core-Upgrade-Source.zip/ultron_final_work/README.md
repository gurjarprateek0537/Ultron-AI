# ULTRON 0.6.0 — Android AI Assistant Source

ULTRON is a personal Android assistant combining an OpenAI-compatible AI client, optional local GGUF inference, an accessibility-based action executor, background voice command processing, memory, camera image analysis, a built-in browser, and user-configurable website/API integrations.

## What's in this release

- **AI-driven action plans:** the selected online AI profile can convert English, Hindi, or Hinglish phone requests into a bounded JSON plan of up to 24 allow-listed actions. ULTRON validates the plan and never executes model-generated scripts or code.
- **Phone actions:** launch installed apps, click visible labels, enter text in exposed editable controls, scroll, swipe, tap normalized coordinates, read visible screen text, navigate Back/Home, open HTTPS URLs, compose WhatsApp/SMS messages, place a call after confirmation, and invoke saved plugins.
- **Background command processing:** wake-word commands are encrypted in app-private storage and placed into a serial WorkManager queue using opaque IDs. The worker plans and executes without opening the ULTRON activity, then posts a result notification and uses the chosen installed Android TTS voice. Background app launches can still be blocked by Android/OEM policy.
- **Safety gate:** message sending, calls, coordinate taps, risky button labels and REST/OAuth API operations require a separate YES/NO approval. Pending approvals are encrypted, expire after 10 minutes, and appear in a notification. Actions are recorded in an encrypted local audit history. A report distinguishes accepted operations from those whose effect was independently observed.
- **Contact workflows:** WhatsApp and SMS use Contacts permission when a number is not supplied. Ambiguous contact matches fail closed. WhatsApp may open a prefilled conversation and activate a visible Send control only after approval; delivery/read status is not available to ULTRON.
- **Vision:** the user launches Android's camera capture flow. ULTRON downsamples the captured photo and sends it as an OpenAI-compatible `image_url` payload to an enabled Vision profile (or the default online model if configured). The chosen endpoint must accept multimodal image input.
- **Plugins:** add HTTPS website shortcuts and REST API integrations from Plugin Armory. REST integrations support GET/POST/PUT/PATCH/DELETE, no auth, Bearer, API-key header/query and Basic auth. OAuth 2.0 Authorization Code + PKCE is available with encrypted credentials/tokens and refresh where the provider returns a compatible refresh token.
- **Hindi/English speech:** choose English (India), English (US) or Hindi (India), plus male/female preference. ULTRON selects the closest matching voice from the Android TTS engine and provides the engine's voice-data installer. Voice binaries are not redistributed in this source.
- **Memory and UI:** persistent Room memory, notes and imported documents; searchable memory screen with item deletion and agent action history; cinematic crimson/charcoal dashboard and a 48-frame 560×560 animated ULTRON voice GIF.
- **Optional local AI:** the existing GGUF model vault and native llama.cpp bridge remain separate from online AI. Image input is not supported by the local text runtime.

## Configure online AI

In ULTRON Settings, choose Online mode and enter the InstaBox OpenAI-compatible gateway's base URL (normally ending `/v1`), the exact model ID/path and the gateway API key. ULTRON calls `POST {baseUrl}/chat/completions`. The app retries selected transient 502–504 responses, but a down gateway/upstream still needs to be fixed at the host.

Add named AI profiles for separate roles such as General, Coding and Vision. The dashboard's selected profile is used by the task planner. A Vision profile must accept OpenAI-style multimodal `image_url` message content.

## Configure Android access

1. Grant microphone permission and start the foreground wake-word listener from Voice settings.
2. Enable ULTRON Accessibility in Android Accessibility settings for screen actions.
3. Grant Contacts permission for name-to-number resolution.
4. Allow notifications so execution results and YES/NO requests are visible.
5. Exempt ULTRON from battery optimization only if you understand the battery trade-off and your device otherwise kills the listener.

Say “ULTRON” followed by a command, or say the wake word and wait for the follow-up capture. You can answer a pending confirmation with “ULTRON yes” or “ULTRON no”, or use the notification buttons. The service uses Android `SpeechRecognizer`, not a dedicated offline acoustic wake-word detector.

## Plugin setup

Open Modules → Plugin Armory. Website shortcuts use HTTPS URL templates with `{query}`. API integrations need the API name, HTTPS resource endpoint, method, authentication type, credentials and optional JSON body template. Use `run plugin <name> with <request>` in chat/voice.

For OAuth, enter the provider authorization URL, token URL, client ID/secret (if required), scopes and exact registered redirect URI. The default callback is `ultron://oauth/callback`. The implementation is generic OAuth 2.0 Authorization Code + PKCE; providers that require additional parameters, client authentication methods, app-link verification or server-side confidential clients may need provider-specific support. Register the exact redirect URI with the provider and use only the minimum scopes required.

## Android compatibility and build

- `minSdk`: 26 (Android 8.0)
- `compileSdk` / `targetSdk`: 35
- Java/Kotlin target: 17
- Native ABI filters: `arm64-v8a`, `armeabi-v7a`, `x86_64`
- CMake: 3.22.1; Android NDK: 27.2.12479018
- GitHub Actions workflow: `.github/workflows/android.yml`

The workflow installs JDK 17, Gradle 8.9 and Android SDK/NDK components, runs `:app:testDebugUnitTest`, builds `:app:assembleDebug`, and uploads `app-debug.apk` as `ultron-debug-apk`. Push this project to your repository and run **Actions → Build ULTRON debug APK → Run workflow**.

## Important behavior limits

- This is not root access or unrestricted device control. Android system UI, lock screens, secure/password fields, protected apps, inaccessible custom views and OEM-specific interfaces may block accessibility reading or gestures.
- Android 8–16 is the target range, not proof of uniform compatibility. Android 14+ microphone foreground-service rules, background activity launch restrictions, speech-recognizer availability and OEM battery policies require physical-device tests. Continuous wake-word performance and false-trigger rate are not guaranteed.
- WorkManager survives normal activity closure but is scheduled work, not a real-time daemon. The microphone listener itself remains an explicit foreground service and is subject to OS/OEM restrictions.
- The planner is an instruction model, not deterministic automation. ULTRON bounds and checks its proposed actions, but a complex request can still be misunderstood. Review the full confirmation notification before approving it.
- UI verification is best-effort: ULTRON can observe visible text/package changes, but it cannot prove every server-side action, message delivery, payment, or app-internal state.
- WhatsApp/SMS workflows depend on contact data and exposed app controls. WhatsApp send may be activated only after YES if its UI exposes the Send control. ULTRON cannot verify delivery or read receipts. Other messaging apps use general accessibility actions and are not guaranteed.
- Camera analysis is an explicit foreground capture, not live video, continuous monitoring or silent background capture. It requires a compatible online multimodal model.
- Generic OAuth does not automatically fit every provider. Provider-specific setup or code may be needed. API credentials are encrypted at rest, but they are still sent to the URLs you configure; only connect services you trust.
- Male/female Hindi/English voice options depend on the Android speech engine's installed voices and metadata. ULTRON does not bundle third-party voice binaries.
- The source archive is **not a compiled or signed APK**. No Android SDK, Gradle or NDK toolchain is available in the authoring workspace, so the build and hardware tests have not been run here. Treat the APK as build-verified only after the included GitHub Actions workflow succeeds.

See `CHANGELOG_0.6.0.md`, `IMPLEMENTATION_STATUS.md`, and `FINAL_BUILD_NOTES.md` for implementation details and test boundaries.
