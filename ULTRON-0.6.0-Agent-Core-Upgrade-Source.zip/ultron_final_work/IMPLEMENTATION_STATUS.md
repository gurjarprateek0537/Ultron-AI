# ULTRON 0.6.0 — Implementation Status

This file describes behavior present in the current source tree. A declared permission, UI label or planned feature is not counted as implemented. CI and physical-device tests have not been performed from this workspace.

## Implemented in source

| Feature | Source implementation | Boundary |
|---|---|---|
| Online AI | OpenAI-compatible `/chat/completions`, InstaBox settings, multiple named profiles, active profile selection, retry for transient 502–504 | Requires user endpoint/model/key; gateway availability is external. |
| AI phone planner | Bounded JSON plan, allow-listed action types, max 24 actions, English/Hindi/Hinglish prompt | Qwen can misunderstand ambiguous/complex instructions. No code from model is executed. |
| Action execution | App launch, click by visible label, text entry, scroll, swipe, coordinate tap, screen reading, Back/Home, HTTPS open, plugin call | Accessibility must be enabled; apps can hide or block controls. Background app launches can be denied. |
| Verification | Foreground package/visible text snapshot for navigation/gestures; field value check for type; accepted and verified counts | UI state change is not proof of server-side delivery or transaction completion. |
| Background agent | Encrypted voice command queue and serial WorkManager planning/action execution without opening MainActivity; result notification and selected TTS | WorkManager is scheduled background work; OS may delay/stop work or restrict app launches. |
| Wake word | Foreground service using Android SpeechRecognizer, on-device recognition where system offers it, otherwise default recognizer; recovery/backoff; second-stage command capture | Not a dedicated offline keyword engine. Android 8–16/OEM microphone continuity requires device testing. |
| YES/NO confirmation | Encrypted plan store, 10-minute expiry, notification buttons, wake-word spoken confirmation, encrypted audit history | One approval authorizes the pending plan; review all listed actions. No automatic rollback of external side effects. |
| Sensitive action policy | Messages, calls, coordinate taps, selected risky button labels and all REST/OAuth plugin calls require approval regardless of model flag | More provider/app-specific sensitive semantics may need to be added. |
| Contact workflows | Contacts query with exact/unique matching, WhatsApp link and SMS composer, optional visible Send click after approval | Ambiguous matches fail closed. App UI and Android background restrictions vary. Delivery/read receipts cannot be verified. |
| Camera vision | Android camera capture, image downsample/JPEG/base64, OpenAI multimodal `image_url`, Vision profile routing | Foreground photo only; online endpoint must accept image payload. No live video or background camera. |
| Custom plugins | HTTPS website shortcut, REST methods GET/POST/PUT/PATCH/DELETE, Bearer/API key/Basic auth, JSON request template | User-configured endpoints only. The generic plugin feature is not a sandbox for arbitrary code. |
| OAuth | Authorization Code + PKCE, state check, callback, encrypted tokens/secrets, refresh when supported | Provider-specific params/clients/redirect policy may need custom handling. Some providers require backend exchange. |
| Memory | Room chat/facts/notes/documents, search, individual deletion, encrypted action audit records | Basic local memory retrieval, not vector search or a full agent knowledge graph. |
| TTS | English India/US and Hindi India language preference, male/female best-match selection, test action and Android voice-data installer; background replies use selection | Voice binaries come from installed Android TTS engine; voice gender metadata may be absent. |
| UI | Crimson/obsidian dashboard, animated HUD, 48-frame 560×560 ULTRON voice GIF, searchable Memory screen | Visual design still requires visual testing on different screen sizes/densities. |
| Local AI | Optional GGUF vault and JNI llama.cpp bridge | Text runtime only; architecture/model performance and NDK compilation unverified. |
| Android targets | minSdk 26, targetSdk 35, ABIs arm64-v8a/armeabi-v7a/x86_64 | Manifest/build targets do not guarantee compatibility on every device. |

## Action safety details

The AI output is treated as untrusted structured data. Only the enumerated action types are accepted; action count and field lengths are bounded. The executor stops at the first failed step. Plan approval is checked by ULTRON itself, not merely by the model's `requires_confirmation` field. Pending plans are encrypted locally and passed to WorkManager using a small opaque ID to avoid WorkManager's 10 KB input-data limit. The pending record is removed before execution to prevent repeated notification taps replaying the same plan.

Approval is required for WhatsApp/SMS composition and send paths, calls, coordinate taps, risky UI labels (for example Send, Delete, Save, Update, Accept and similar), and all REST/OAuth plugin calls. A user should inspect the notification preview before pressing YES. This is not a universal transaction safety guarantee; Android and third-party apps remain responsible for final outcomes.

## Not guaranteed / still incomplete

- No root access or universal access to every app, system screen, secure field, payment screen, password manager, protected surface or custom-drawn control.
- No universal automation adapter for every messaging/social/financial app. Generic accessibility actions are application-dependent. WhatsApp auto-send and SMS send are best-effort and not delivery-verified.
- No closed-loop AI re-planning after every single action. The initial AI plan is executed sequentially and stops on a failed step; visible UI changes are verified where possible.
- Background execution cannot bypass Android's background launch restrictions. The foreground wake-word listener requires explicit start, microphone permission and ongoing notification; manufacturers may kill it.
- The wake-word recognizer is not a dedicated offline acoustic model, speaker recognition, or guaranteed always-on solution. Android's on-device recognizer is used only where exposed by system.
- OAuth is generic PKCE, not an implementation of every provider's special OAuth requirements. Provider-specific app registration, client configuration, scopes and callback approval are user supplied.
- Camera flow is user-initiated still image capture and online vision. No background camera, silent capture, live object detection, video, segmentation or local multimodal model.
- TTS packages are not embedded; installed system voices determine quality, gender selection and language availability.
- NDK llama.cpp build can change with upstream `master`. The native CMake project fetches upstream source at build time; ABI builds need CI validation and may require pinning a tested commit.
- No successful Gradle/NDK build, APK signing, emulator test or Android 8/16 physical-device matrix has been performed in the workspace.

## Validation carried out in authoring workspace

- Source-level Kotlin syntax checks (parser diagnostics scan) on modified Kotlin files; this is not a type-check or Android build.
- Android XML/resources parsed as XML.
- Workflow YAML parsed structurally.
- Animated GIF dimensions/frame count inspected.
- Unit tests added for sensitive-action confirmation rules; tests still need Gradle/CI execution.

## Required next verification

1. Run the included GitHub Actions workflow. Fix any Gradle/Kotlin/NDK errors reported by that build.
2. Install on Android 8.1, 10, 12, 13, 14, 15 and 16 devices/emulators where available.
3. Test wake-word continuity for at least an extended session with screen off, OEM battery restrictions and network/offline speech modes.
4. Test accessibility actions against real apps and secure screens; test WhatsApp with explicit confirmation and verify the user-facing status.
5. Test each OAuth provider with its own development app credentials and minimal scopes.
6. Test camera payload against the exact selected Vision model and verify Hindi/English voices available on each target phone.
