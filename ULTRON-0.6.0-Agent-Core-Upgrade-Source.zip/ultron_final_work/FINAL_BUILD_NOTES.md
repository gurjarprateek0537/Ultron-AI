# ULTRON 0.6.0 — Build and Delivery Notes

## Project configuration

- App module: `app`
- Version: `0.6.0` (`versionCode 12`)
- Minimum Android: API 26 (Android 8.0)
- Compile/target SDK: 35
- Java/Kotlin: 17
- Native ABIs: `arm64-v8a`, `armeabi-v7a`, `x86_64`
- CMake: 3.22.1
- Recommended Android NDK for CI: 27.2.12479018

## Build with GitHub Actions

The included `.github/workflows/android.yml` installs JDK 17, Gradle 8.9, Android platform/build tools 35, Android NDK 27.2.12479018 and CMake 3.22.1. It runs `:app:testDebugUnitTest`, builds `:app:assembleDebug`, then uploads `app/build/outputs/apk/debug/app-debug.apk` as the `ultron-debug-apk` artifact. Run it from GitHub Actions after uploading the full project to the repository root.

The workflow has not been executed from this workspace. There is no local Android SDK, Gradle or NDK installation here. Therefore this ZIP is a **source-code deliverable**, not a compiled APK and not a verified build.

## Plugin / OAuth configuration

The user can add website shortcuts, REST definitions and generic OAuth 2.0 Authorization Code + PKCE integrations in Plugin Armory. Credentials and returned tokens are encrypted locally using the app's Android Keystore vault. The user must register a redirect URI (default `ultron://oauth/callback`), supply provider URLs/client credentials/scopes, and set the resource endpoint and method. Provider-specific requirements may need additional integration work. Only use HTTPS provider/resource endpoints except the configured custom redirect URI.

## Voice / device compatibility

Wake-word recognition uses Android SpeechRecognizer in an opt-in microphone foreground service. For Android versions that expose on-device recognition, ULTRON requests it; otherwise it uses the configured Android speech service. It is not a dedicated offline hotword model. TTS language/gender selection chooses the best matching installed Android voice; voice assets are not bundled. Android 8–16 are build targets, not test-certified compatibility claims.

## Agent execution

Commands are planned by the currently selected online AI profile and executed through an allow-listed Accessibility/Intent action layer. WorkManager runs the plan outside MainActivity. Sensitive actions require YES/NO approval. The app verifies observable UI changes where possible and records an encrypted activity report. Android/OEM background restrictions, app-specific UIs, and unexposed controls can still prevent an action or result verification.
