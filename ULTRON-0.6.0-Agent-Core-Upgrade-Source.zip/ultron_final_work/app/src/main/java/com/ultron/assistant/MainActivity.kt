package com.ultron.assistant

import android.content.Intent
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.core.content.FileProvider
import androidx.activity.result.ActivityResultLauncher
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.layout.ContentScale
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.File
import java.util.concurrent.TimeUnit

private val Night = Color(0xFF090A0D)
private val Panel = Color(0xFF11141A)
private val Crimson = Color(0xFFFF343D)
private val Orange = Color(0xFFFF9A52)
private val Purple = Color(0xFF9D83D8)

class MainActivity : FragmentActivity(), TextToSpeech.OnInitListener {
    companion object {
        val voiceCommands = MutableStateFlow<String?>(null)
        val externalReplies = MutableStateFlow<String?>(null)
        private const val REQUEST_CAMERA_VISION = 7812
    }
    private lateinit var cameraLauncher: ActivityResultLauncher<Uri>
    private var pendingVisionUri: Uri? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var settingsStore: SettingsStore
    private lateinit var database: UltronDatabase
    private val appLockEnabled = mutableStateOf(false)
    private val appUnlocked = mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
            val uri = pendingVisionUri
            pendingVisionUri = null
            if (saved && uri != null) processVisionCapture(uri)
            else Toast.makeText(this, "Camera capture cancelled or unavailable.", Toast.LENGTH_SHORT).show()
        }
        voiceCommands.value = intent?.getStringExtra(UltronWakeWordService.EXTRA_WAKE_COMMAND)
        settingsStore = SettingsStore(this)
        database = UltronDatabase.get(this)
        intent?.data?.let { handleOAuthCallback(it) }
        appLockEnabled.value = AppLockStore.isEnabled(this)
        appUnlocked.value = !appLockEnabled.value
        tts = TextToSpeech(this, this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "ultron-chat-cleanup",
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ChatCleanupWorker>(24, TimeUnit.HOURS).build()
        )
        lifecycleScope.launch { runCatching { database.chatDao().deleteOlderThan(System.currentTimeMillis() - 3L * 24 * 60 * 60 * 1000) } }
        setContent {
            if (appLockEnabled.value && !appUnlocked.value) {
                AppLockScreen(onUnlock = { authenticateAppUnlock() })
            } else UltronScreen(
                initialSettings = settingsStore.load(),
                database = database,
                onSaveSettings = { settingsStore.save(it) },
                onSpeak = { if (ttsReady) {
                    runCatching { VoiceOutputStore(this).apply(tts!!, VoiceOutputStore(this).load()) }
                    tts?.speak(it.take(4_000), TextToSpeech.QUEUE_FLUSH, null, "ultron-reply")
                } },
                onVoiceSettingsChanged = { language, gender ->
                    val preference = VoiceOutputPreference(language, gender)
                    VoiceOutputStore(this).save(preference)
                    if (ttsReady) VoiceOutputStore(this).apply(tts!!, preference) else "Voice engine is still starting."
                },
                onAction = { action -> runAction(action) },
                onOpenSpecialSetting = { AndroidAccess.openSpecialSetting(this, it) },
                onSetAppLock = { enabled -> setAppLock(enabled) }
            )
        }
    }


    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        voiceCommands.value = intent.getStringExtra(UltronWakeWordService.EXTRA_WAKE_COMMAND)
        intent.data?.let { handleOAuthCallback(it) }
    }

    private fun handleOAuthCallback(uri: Uri) {
        if (uri.scheme != "ultron" || uri.host != "oauth" || uri.path != "/callback") return
        lifecycleScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { PluginStore(this@MainActivity).completeOAuthCallback(uri) } }
            Toast.makeText(this@MainActivity, result.getOrElse { "OAuth connection failed: ${it.message ?: "unknown error"}" }, Toast.LENGTH_LONG).show()
        }
    }

    private fun setAppLock(enabled: Boolean): Boolean {
        if (!enabled) {
            AppLockStore.setEnabled(this, false)
            appLockEnabled.value = false
            appUnlocked.value = true
            return true
        }
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK
        val availability = BiometricManager.from(this).canAuthenticate(authenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) return false
        AppLockStore.setEnabled(this, true)
        appLockEnabled.value = true
        appUnlocked.value = true
        return true
    }

    private fun authenticateAppUnlock() {
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK
        val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ULTRON")
            .setSubtitle("Authenticate to open your private assistant")
            .setAllowedAuthenticators(authenticators)
        if (Build.VERSION.SDK_INT < 30) promptInfoBuilder.setNegativeButtonText("Cancel")
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                appUnlocked.value = true
            }
        })
        runCatching { prompt.authenticate(promptInfoBuilder.build()) }
    }

    override fun onPause() {
        if (appLockEnabled.value) appUnlocked.value = false
        super.onPause()
    }

    private fun runAction(action: String) {
        val intent = when (action) {
            "Browser" -> Intent(this, UltronBrowserActivity::class.java)
            "Settings" -> Intent(Settings.ACTION_SETTINGS)
            "TTS_INSTALL" -> Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
            "Camera" -> { startVisionCapture(); return }
            "Dialer" -> Intent(Intent.ACTION_DIAL)
            "Maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=nearby places"))
            else -> if (action.startsWith("URL:")) Intent(Intent.ACTION_VIEW, Uri.parse(action.removePrefix("URL:"))) else null
        }
        if (intent != null) runCatching { startActivity(intent) }
    }

    private fun startVisionCapture() {
        runCatching {
            val directory = File(cacheDir, "vision").apply { mkdirs() }
            val image = File(directory, "ultron-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", image)
            pendingVisionUri = uri
            cameraLauncher.launch(uri)
        }.onFailure { Toast.makeText(this, "Camera could not start: ${it.message ?: "file provider error"}", Toast.LENGTH_LONG).show() }
    }

    private fun processVisionCapture(uri: Uri) {
        lifecycleScope.launch {
            Toast.makeText(this@MainActivity, "ULTRON is analyzing the captured image…", Toast.LENGTH_SHORT).show()
            val result = runCatching {
                val dataUrl = withContext(Dispatchers.IO) {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw IllegalStateException("Captured image could not be read.")
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (bounds.outWidth / sample > 1280 || bounds.outHeight / sample > 1280) sample *= 2
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                        ?: throw IllegalStateException("Image decoding failed.")
                    val output = java.io.ByteArrayOutputStream()
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, output)
                    bitmap.recycle()
                    "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                }
                val profiles = AiProfileStore(this@MainActivity).load()
                val vision = profiles.firstOrNull { it.enabled && it.role.contains("vision", true) && it.baseUrl.isNotBlank() && it.model.isNotBlank() }
                val settings = settingsStore.load()
                if (vision == null && settings.mode == InferenceMode.LOCAL) {
                    throw IllegalStateException("Image analysis needs an online vision-capable profile. Add one in Settings → AI profiles, with role ‘vision’ and a model endpoint that accepts image_url content.")
                }
                val prompt = "Analyze this camera image carefully. Describe visible objects, text, scene and useful details. Clearly state uncertainty and do not invent invisible details."
                val messages = listOf(ChatMessage("user", prompt, dataUrl))
                val answer = withContext(Dispatchers.IO) {
                    val repository = InferenceRepository(this@MainActivity)
                    if (vision != null) repository.completeProfile(messages, vision).text
                    else repository.complete(messages, settings).text
                }
                withContext(Dispatchers.IO) {
                    database.chatDao().insert(ChatRecord(role = "user", content = PrivateTextVault.encrypt("[Camera image] $prompt")))
                    database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(answer)))
                }
                answer
            }
            val response = result.getOrElse { "Vision analysis failed: ${it.message ?: "unknown error"}" }
            externalReplies.value = response
            val preference = VoiceOutputStore(this@MainActivity).load()
            if (ttsReady) {
                VoiceOutputStore(this@MainActivity).apply(tts!!, preference)
                tts?.speak(response.take(3_500), TextToSpeech.QUEUE_FLUSH, null, "ultron-vision-reply")
            }
            Toast.makeText(this@MainActivity, if (result.isSuccess) "Vision analysis complete" else "Vision analysis failed", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.setPitch(.96f)
            tts?.setSpeechRate(.94f)
            runCatching { VoiceOutputStore(this).apply(tts!!, VoiceOutputStore(this).load()) }
        }
    }

    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun UltronScreen(
    initialSettings: LlmSettings,
    database: UltronDatabase,
    onSaveSettings: (LlmSettings) -> Unit,
    onSpeak: (String) -> Unit,
    onVoiceSettingsChanged: (String, String) -> String,
    onAction: (String) -> Unit,
    onOpenSpecialSetting: (String) -> Unit,
    onSetAppLock: (Boolean) -> Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(initialSettings) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var voiceReply by remember { mutableStateOf(true) }
    val savedVoicePreference = remember(context) { VoiceOutputStore(context).load() }
    var voiceLanguage by remember { mutableStateOf(savedVoicePreference.language) }
    var voiceGender by remember { mutableStateOf(savedVoicePreference.gender) }
    var voiceStatus by remember { mutableStateOf("Select your preferred spoken reply voice.") }
    var appLockOn by remember { mutableStateOf(AppLockStore.isEnabled(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf("HOME") }
    var showAccess by remember { mutableStateOf(false) }
    var accessRefresh by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Ready · configure your InstaBox gateway in Settings") }
    val aiProfileStore = remember(context) { AiProfileStore(context) }
    var aiProfiles by remember { mutableStateOf(aiProfileStore.load()) }
    var selectedAiId by remember { mutableStateOf(aiProfileStore.activeProfileId()) }
    var allInOne by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf("") }
    var profileRole by remember { mutableStateOf("coding") }
    var profileUrl by remember { mutableStateOf("") }
    var profileModel by remember { mutableStateOf("") }
    var profileKey by remember { mutableStateOf("") }
    val lines = remember { mutableStateListOf(ChatMessage("assistant", "I am ULTRON. Online AI uses the endpoint you configure. Local AI will report clearly until a compatible native model runtime is installed.")) }
    val repository = remember(context) { InferenceRepository(context.applicationContext) }
    val pendingWakeCommand by MainActivity.voiceCommands.collectAsState()
    val externalReply by MainActivity.externalReplies.collectAsState()
    val router = remember(database) { UltronCommandRouter(context.applicationContext, database) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }
    val runtimePermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val granted = result.filterValues { it }.keys
        accessRefresh++
        status = if (granted.isNotEmpty()) "Permission result received · ${granted.size} granted" else "No new permissions granted"
        if (android.Manifest.permission.RECORD_AUDIO in granted) {
            runCatching {
                val wake = Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(wake) else context.startService(wake)
                status = "Microphone permission granted · wake-word service starting"
            }.onFailure { status = "Microphone granted but wake-word service failed: ${it.message}" }
        }
    }
    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Importing and extracting text locally…"
                try {
                    val record = DocumentIngestor.import(context, uri)
                    val id = withContext(Dispatchers.IO) { database.documentDao().insert(record.copy(title = PrivateTextVault.encrypt(record.title), extractedText = PrivateTextVault.encrypt(record.extractedText))) }
                    lines.add(ChatMessage("assistant", "Imported ‘${record.title}’ and extracted ${record.extractedText.length} characters locally (document #$id). Ask me a question about it; relevant excerpts are added to the next AI request."))
                    withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(lines.last().content))) }
                    status = "Document imported · on-device OCR/text extraction"
                } catch (e: Exception) {
                    val error = "Document import failed: ${e.message ?: "unsupported file or extraction error"}"
                    lines.add(ChatMessage("assistant", error))
                    status = "Import failed"
                } finally { busy = false }
            }
        }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Copying GGUF model into private storage…"
                try {
                    val file = withContext(Dispatchers.IO) { NativeLlamaRuntime.importModel(context, uri.toString()) }
                    status = "GGUF model imported · ${file.length() / 1_000_000} MB · ready to load on first local prompt"
                    lines.add(ChatMessage("assistant", "Imported local GGUF model: ${NativeLlamaRuntime.activeModelName(context)}. Choose Local LLM and send a prompt to load it. Model loading may fail if the model format or memory requirements are incompatible; ULTRON will report the failure without switching models."))
                } catch (e: Exception) {
                    status = "Model import failed"
                    lines.add(ChatMessage("assistant", "Model import failed: ${e.message ?: "unknown error"}"))
                } finally { busy = false }
            }
        }
    }

    LaunchedEffect(Unit) {
        runCatching {
            val stored = withContext(Dispatchers.IO) { database.chatDao().latest(150).reversed().map { it.copy(content = PrivateTextVault.decrypt(it.content)) } }
            if (stored.isNotEmpty()) {
                lines.clear()
                stored.forEach { lines.add(ChatMessage(it.role, it.content)) }
                status = "Restored ${stored.size} recent chat messages"
            }
        }
    }

    fun send(promptOverride: String? = null) {
        val prompt = (promptOverride ?: draft).trim()
        if (prompt.isEmpty() || busy) return
        lines.add(ChatMessage("user", prompt))
        draft = ""
        busy = true
        status = "ULTRON is working…"
        scope.launch {
            try {
                withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "user", content = PrivateTextVault.encrypt(prompt))) }
                val agentPlan = if (UltronAgentPlanner.looksLikeDeviceCommand(prompt) && settings.mode == InferenceMode.ONLINE) {
                    runCatching { UltronAgentPlanner(context).plan(prompt) }.getOrNull()?.takeIf { it.actions.isNotEmpty() }
                } else null
                val agentResponse = if (agentPlan != null) {
                    val executor = UltronAgentExecutor(context)
                    if (executor.requiresApproval(agentPlan)) {
                        withContext(Dispatchers.IO) {
                            val pendingId = java.util.UUID.randomUUID().toString()
                            UltronPendingActionStore.save(context, pendingId, agentPlan)
                            UltronAgentHistoryStore.record(context, UltronAgentHistoryItem(command = agentPlan.summary, status = "awaiting confirmation", total = agentPlan.actions.size, details = agentPlan.actions.map { "${it.type}: ${it.text.ifBlank { it.app.ifBlank { it.message.ifBlank { it.plugin } } }}" }))
                            UltronAgentNotifications.confirm(context, pendingId, agentPlan)
                        }
                        InferenceResult("I prepared ${agentPlan.actions.size} action(s). Review the ULTRON confirmation notification and choose YES to execute or NO to cancel. Nothing sensitive has been done yet.", "ULTRON Agent · awaiting confirmation")
                    } else {
                        val report = executor.execute(agentPlan, approved = false)
                        withContext(Dispatchers.IO) { UltronAgentHistoryStore.record(context, UltronAgentHistoryItem(command = agentPlan.summary, status = if (report.success) "completed" else "stopped", completed = report.completed, verified = report.verified, total = report.total, details = report.details)) }
                        InferenceResult(buildString {
                            append(if (report.success) "Task completed" else "Task stopped")
                            append(" · ${report.completed}/${report.total} verified action(s).\n")
                            report.details.forEach { append(it).append('\n') }
                        }, "ULTRON Agent · action execution")
                    }
                } else null
                val localAction = if (agentResponse == null) router.handle(prompt) else null
                val response = agentResponse ?: if (localAction != null) {
                    status = "On-device command"
                    InferenceResult(localAction, "On-device · ULTRON actions")
                } else {
                    val prepared = router.buildMessages(lines.toList())
                    if (settings.mode == InferenceMode.LOCAL) repository.complete(prepared, settings)
                    else {
                        val defaultProfile = AiEndpointProfile("default", "General AI", "general", settings.baseUrl, settings.model, settings.apiKey)
                        val configuredProfiles = listOf(defaultProfile) + aiProfiles
                        if (allInOne) repository.completeAllInOne(prepared, configuredProfiles)
                        else if (selectedAiId == "default") repository.complete(prepared, settings)
                        else aiProfiles.firstOrNull { it.id == selectedAiId }?.let { repository.completeProfile(prepared, it) } ?: repository.complete(prepared, settings)
                    }
                }
                lines.add(ChatMessage("assistant", response.text))
                withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(response.text))) }
                status = response.provider
                if (voiceReply) onSpeak(response.text)
            } catch (e: Exception) {
                val message = e.message ?: "Unknown inference error"
                val friendly = "ULTRON couldn't complete that request: $message"
                lines.add(ChatMessage("assistant", friendly))
                withContext(Dispatchers.IO) { runCatching { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(friendly))) } }
                status = "Action / inference failed"
            } finally { busy = false }
        }
    }

    LaunchedEffect(externalReply) {
        val reply = externalReply?.trim().orEmpty()
        if (reply.isNotBlank()) {
            lines.add(ChatMessage("assistant", reply))
            MainActivity.externalReplies.value = null
        }
    }

    LaunchedEffect(pendingWakeCommand) {
        val command = pendingWakeCommand?.trim().orEmpty()
        if (command.isNotBlank()) {
            MainActivity.voiceCommands.value = null
            activeTab = "CHAT"
            send(command)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Orange, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16090D), Night, Color(0xFF08090D))))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ULTRON", color = Crimson, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("YOUR AI. YOUR COMMANDS.", color = Orange, fontSize = 9.sp, letterSpacing = 1.8.sp)
                }
                Surface(color = Color(0xFF102116), shape = RoundedCornerShape(30.dp), border = BorderStroke(1.dp, Color(0xFF35C76B).copy(alpha=.65f))) {
                    Row(Modifier.padding(horizontal=10.dp, vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).background(Color(0xFF39E878), RoundedCornerShape(50)))
                        Spacer(Modifier.width(6.dp)); Text(if (busy) "WORKING" else if (settings.mode == InferenceMode.LOCAL) "OFFLINE" else if (settings.baseUrl.isBlank()) "SETUP" else "ONLINE", color=if (settings.mode == InferenceMode.LOCAL) Purple else Color(0xFF72E99A), fontSize=9.sp, fontWeight=FontWeight.Bold)
                    }
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Orange) }
            }
            when (activeTab) {
                "HOME" -> DashboardScreen(
                    modifier = Modifier.weight(1f), mode = if (settings.mode == InferenceMode.LOCAL) "OFFLINE" else if (allInOne) "ALL-IN-ONE" else (aiProfiles.firstOrNull { it.id == selectedAiId }?.name ?: "GENERAL AI"), status = status,
                    selectedAiName = if (settings.mode == InferenceMode.LOCAL) "OFFLINE MODEL" else if (allInOne) "ALL-IN-ONE" else (aiProfiles.firstOrNull { it.id == selectedAiId }?.name ?: "GENERAL AI"),
                    aiNames = listOf("General AI") + aiProfiles.map { it.name } + listOf("All-in-One"),
                    onSelectAi = { name ->
                        settings = settings.copy(mode = InferenceMode.ONLINE); onSaveSettings(settings)
                        allInOne = name == "All-in-One"
                        if (!allInOne) {
                            selectedAiId = if (name == "General AI") "default" else aiProfiles.firstOrNull { it.name == name }?.id ?: "default"
                            aiProfileStore.setActiveProfileId(selectedAiId)
                        }
                    },
                    onChat = { activeTab = "CHAT" },
                    onVoice = { activeTab = "VOICE"; runCatching { speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")) }.onFailure { status = "Speech recognizer unavailable" } },
                    onVision = { onAction("Camera") }, onBrowser = { onAction("Browser") },
                    onMemory = { activeTab = "MEMORY" }, onModels = { activeTab = "MODELS" },
                    onSecurity = { accessRefresh++; showAccess = true }, onPlugins = { activeTab = "PLUGINS" }
                )
                "CHAT" -> Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text("AI CHAT", color=Crimson, fontSize=16.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                        Text(if (settings.mode == InferenceMode.LOCAL) "OFFLINE · ${NativeLlamaRuntime.activeModelName(context)}" else if (allInOne) "ALL-IN-ONE DEBATE" else (aiProfiles.firstOrNull { it.id == selectedAiId }?.name ?: "GENERAL AI"), color=Orange, fontSize=10.sp)
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(lines) { line ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.role == "user") Arrangement.End else Arrangement.Start) {
                                Surface(color = if (line.role == "user") Color(0xFF48141B) else Color(0xFF15151B), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, if (line.role == "user") Crimson.copy(alpha=.85f) else Color(0xFF513039)), modifier = Modifier.widthIn(max = 380.dp)) {
                                    Text(line.content, Modifier.padding(14.dp), color=Color(0xFFF5F0F2), fontSize=14.sp, lineHeight=20.sp)
                                }
                            }
                        }
                        if (busy) item { Text("ULTRON IS THINKING…", color=Orange, fontSize=11.sp) }
                    }
                    Row(Modifier.fillMaxWidth().background(Color(0xFF171219), RoundedCornerShape(28.dp)).padding(horizontal=5.dp, vertical=5.dp), verticalAlignment=Alignment.CenterVertically) {
                        IconButton(onClick = { runCatching { speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")) }.onFailure { status="Speech recognizer unavailable" } }) { Icon(Icons.Default.Mic, "Voice input", tint=Crimson) }
                        Box(Modifier.weight(1f).padding(horizontal=8.dp)) { if (draft.isEmpty()) Text("Message ULTRON…", color=Color.Gray, fontSize=13.sp); BasicTextField(draft, { draft=it }, Modifier.fillMaxWidth(), textStyle=androidx.compose.ui.text.TextStyle(color=Color.White,fontSize=14.sp), maxLines=5) }
                        IconButton(onClick={send()}, enabled=!busy) { Icon(Icons.Default.Send, "Send", tint=Orange) }
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("Voice replies", color=Color.LightGray, fontSize=10.sp); Switch(checked=voiceReply,onCheckedChange={voiceReply=it}); Spacer(Modifier.weight(1f)); Text("3-day chat history", color=Purple,fontSize=9.sp) }
                }
                "VOICE" -> VoiceFeatureScreen(modifier=Modifier.weight(1f), onStart={
                    if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) runtimePermissions.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                    else runCatching { val wake=Intent(context,UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START); if(Build.VERSION.SDK_INT>=26) context.startForegroundService(wake) else context.startService(wake); status="Wake-word service requested" }.onFailure { status="Wake-word start failed: ${it.message}" }
                }, onStop={ context.stopService(Intent(context,UltronWakeWordService::class.java)); status="Wake-word service stopped" }, onSpeak={ activeTab="CHAT" })
                "PLUGINS" -> PluginHubScreen(Modifier.weight(1f), onOpen = { onAction("URL:$it") })
                "MODELS" -> OfflineModelScreen(
                    Modifier.weight(1f), enabled = settings.mode == InferenceMode.LOCAL,
                    onEnabled = { enabled ->
                        if (enabled && NativeLlamaRuntime.activeModelPath(context) == null) status = "Import or download a GGUF model before enabling Offline AI"
                        else { settings = settings.copy(mode = if (enabled) InferenceMode.LOCAL else InferenceMode.ONLINE); onSaveSettings(settings); status = if (enabled) "Offline AI enabled" else "Online AI selected" }
                    },
                    modelStatus = LocalModelStore(context).status(),
                    onFindQwen = { onAction("URL:https://huggingface.co/models?search=Qwen3.5-4B-Amadeus-GGUF") },
                    onImport = { modelPicker.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*")) },
                    onDownload = { url -> scope.launch {
                        busy = true; status = "Downloading GGUF into private storage…"
                        try {
                            val file = withContext(Dispatchers.IO) { NativeLlamaRuntime.downloadModel(context, url) }
                            status = "Offline model downloaded and installed · ${file.length() / 1_000_000} MB"
                        } catch (e: Exception) { status = "Model download failed: ${e.message}" }
                        finally { busy = false }
                    } },
                    onDelete = { NativeLlamaRuntime.deleteModel(context); status = "Offline model deleted" }
                )
                "MEMORY" -> MemoryVaultScreen(Modifier.weight(1f), database)
                else -> SimpleFeatureScreen(Modifier.weight(1f), activeTab, "ULTRON SYSTEM MODULE", listOf("InstaBox online AI configuration", "Optional offline GGUF model", "Permissions and device access", "Biometric app lock"), status)
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF100D12)).padding(horizontal=5.dp, vertical=7.dp), horizontalArrangement=Arrangement.SpaceEvenly, verticalAlignment=Alignment.CenterVertically) {
                BottomNavItem(Icons.Default.Home, "HOME", activeTab=="HOME") { activeTab="HOME" }
                BottomNavItem(Icons.Default.Chat, "CHAT", activeTab=="CHAT") { activeTab="CHAT" }
                BottomNavItem(Icons.Default.Mic, "VOICE", activeTab=="VOICE") { activeTab="VOICE" }
                BottomNavItem(Icons.Default.GridView, "MODULES", activeTab=="PLUGINS") { activeTab="PLUGINS" }
                BottomNavItem(Icons.Default.Settings, "SETTINGS", false) { showSettings=true }
            }
        }

        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("ULTRON · Inference settings", color = Crimson) },
            text = {
                Column(Modifier.heightIn(max = 640.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ONLINE AI · INSTA BOX GATEWAY", color = Orange, fontWeight = FontWeight.Bold)
                    Text("Offline AI is managed separately in Dashboard → Model Manager. Online profiles remain independent.", color = Color.LightGray, fontSize = 10.sp)
                    OutlinedTextField(value = settings.baseUrl, onValueChange = { settings = settings.copy(baseUrl = it) }, label = { Text("InstaBox gateway URL (e.g. https://host/v1)") }, singleLine = true)
                    OutlinedTextField(value = settings.model, onValueChange = { settings = settings.copy(model = it) }, label = { Text("Model ID") }, singleLine = true)
                    OutlinedTextField(value = settings.apiKey, onValueChange = { settings = settings.copy(apiKey = it) }, label = { Text("API token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Text("MULTI-AI NETWORK", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("General AI uses the main InstaBox settings above. Add Coding, Vision, or any custom AI with its own OpenAI-compatible URL, model path and key.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("All-in-One debate mode", color = Color.White, fontWeight = FontWeight.SemiBold); Text("Parallel answers → peer review → final synthesis. Requires at least two working profiles.", color = Color.LightGray, fontSize = 9.sp) }
                        Switch(checked = allInOne, onCheckedChange = { allInOne = it })
                    }
                    aiProfiles.forEach { profile ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selectedAiId == profile.id, onClick = { selectedAiId = profile.id; aiProfileStore.setActiveProfileId(profile.id); allInOne = false })
                            Column(Modifier.weight(1f)) { Text(profile.name, color = Color.White, fontSize = 12.sp); Text("${profile.role} · ${profile.model}", color = Color.LightGray, fontSize = 9.sp) }
                            TextButton(onClick = { aiProfiles = aiProfiles.filterNot { it.id == profile.id }; aiProfileStore.save(aiProfiles); if (selectedAiId == profile.id) { selectedAiId = "default"; aiProfileStore.setActiveProfileId("default") } }) { Text("REMOVE", color = Crimson, fontSize = 9.sp) }
                        }
                    }
                    OutlinedTextField(value = profileName, onValueChange = { profileName = it }, label = { Text("New AI name (e.g. Coding)") }, singleLine = true)
                    OutlinedTextField(value = profileRole, onValueChange = { profileRole = it }, label = { Text("AI role (general / coding / vision / custom)") }, singleLine = true)
                    OutlinedTextField(value = profileUrl, onValueChange = { profileUrl = it }, label = { Text("AI gateway base URL ending in /v1") }, singleLine = true)
                    OutlinedTextField(value = profileModel, onValueChange = { profileModel = it }, label = { Text("Exact model path / ID") }, singleLine = true)
                    OutlinedTextField(value = profileKey, onValueChange = { profileKey = it }, label = { Text("AI API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                    Button(onClick = {
                        if (profileName.isBlank() || profileUrl.isBlank() || profileModel.isBlank()) status = "Enter AI name, gateway URL and model ID first"
                        else runCatching {
                            val profile = AiEndpointProfile(java.util.UUID.randomUUID().toString(), profileName.trim(), profileRole.trim().ifBlank { "custom" }, profileUrl.trim(), profileModel.trim(), profileKey.trim())
                            aiProfiles = aiProfiles + profile
                            aiProfileStore.save(aiProfiles)
                            selectedAiId = profile.id; aiProfileStore.setActiveProfileId(profile.id); allInOne = false
                            profileName = ""; profileUrl = ""; profileModel = ""; profileKey = ""
                            status = "Added ${profile.name} AI profile"
                        }.onFailure { status = "Could not save AI profile: ${it.message}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("ADD ONLINE AI PROFILE") }
                    Text("Expected route: POST {base URL}/chat/completions. Enter your InstaBox /v1 URL, exact model path/name and gateway API key. Temporary 502/503/504 responses are retried up to 3 times. API tokens are encrypted with Android Keystore.", color = Color.LightGray, fontSize = 11.sp)

                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Biometric / device-credential app lock", color = Color.White)
                            Text("Locks ULTRON when it leaves the foreground. Android 11+ can use strong biometrics or your device credential; older Android versions require enrolled biometrics.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                        }
                        Switch(checked = appLockOn, onCheckedChange = { requested ->
                            if (onSetAppLock(requested)) appLockOn = requested
                            else status = "App lock not changed: set up a supported biometric/device credential in Android settings first."
                        })
                    }
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Text("ULTRON SPOKEN VOICE", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Choose the language and preferred voice presentation for ULTRON's spoken replies. Available voices depend on the Text-to-Speech engine installed on this phone.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("LANGUAGE", color = Color.LightGray, fontSize = 9.sp)
                            var languageMenu by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(onClick = { languageMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(if (voiceLanguage == "hi-IN") "Hindi" else "English", fontSize = 11.sp) }
                                DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                                    DropdownMenuItem(text = { Text("English (India)") }, onClick = { voiceLanguage = "en-IN"; languageMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                    DropdownMenuItem(text = { Text("English (US)") }, onClick = { voiceLanguage = "en-US"; languageMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                    DropdownMenuItem(text = { Text("Hindi (India)") }, onClick = { voiceLanguage = "hi-IN"; languageMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                }
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            Text("VOICE STYLE", color = Color.LightGray, fontSize = 9.sp)
                            var genderMenu by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(onClick = { genderMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(if (voiceGender == "male") "Male" else "Female", fontSize = 11.sp) }
                                DropdownMenu(expanded = genderMenu, onDismissRequest = { genderMenu = false }) {
                                    DropdownMenuItem(text = { Text("Male") }, onClick = { voiceGender = "male"; genderMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                    DropdownMenuItem(text = { Text("Female") }, onClick = { voiceGender = "female"; genderMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                }
                            }
                        }
                    }
                    Text(voiceStatus, color = Purple, fontSize = 10.sp, lineHeight = 13.sp)
                    OutlinedButton(onClick = { onSpeak(if (voiceLanguage.startsWith("hi")) "नमस्ते। मैं अल्ट्रॉन हूँ। मैं आपकी कैसे सहायता कर सकता हूँ?" else "Hello. I am ULTRON. How can I assist you?") }, modifier = Modifier.fillMaxWidth()) { Text("TEST SELECTED VOICE") }
                    OutlinedButton(onClick = { onAction("TTS_INSTALL") }, modifier = Modifier.fillMaxWidth()) { Text("INSTALL / DOWNLOAD VOICE DATA") }
                    Text("Voice packages are supplied by your installed Android speech engine. Use this installer to download supported Hindi and English voices; ULTRON selects the closest available male/female voice and reports when the engine does not expose that choice.", color = Color.LightGray, fontSize = 9.sp, lineHeight = 13.sp)
                    Text("VOICE WAKE WORD", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Optional foreground listener. Uses on-device recognition when available, and Android's configured speech recognizer on older phones such as Android 8/9. Say ‘ULTRON’ followed by a command, or say the wake word and then your command.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                runtimePermissions.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                                status = "Grant microphone permission, then tap Start wake word again"
                            } else {
                                runCatching {
                                    val wake = Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START)
                                    if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(wake) else context.startService(wake)
                                    status = "Wake-word listener requested · check its ongoing notification"
                                }.onFailure { status = "Could not start wake-word listener: ${it.message}" }
                            }
                        }, modifier = Modifier.weight(1f)) { Text("Start listening", fontSize = 11.sp) }
                        OutlinedButton(onClick = {
                            context.stopService(Intent(context, UltronWakeWordService::class.java))
                            context.startService(Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_STOP))
                            status = "Wake-word stop requested"
                        }, modifier = Modifier.weight(1f)) { Text("Stop", fontSize = 11.sp) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Speak replies", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = voiceReply, onCheckedChange = { voiceReply = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    settings = settings.copy(baseUrl = settings.baseUrl.trim().trimEnd('/'), model = settings.model.trim())
                    runCatching { onSaveSettings(settings) }
                        .onSuccess { status = "Saved ${settings.mode} settings"; showSettings = false }
                        .onFailure { status = "Could not securely save token: ${it.message}" }
                }) { Text("Save settings") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } },
            containerColor = Panel
        )

        if (showAccess) {
            val itemsNow = remember(accessRefresh, context) { AndroidAccess.items(context) }
            androidx.compose.ui.window.Dialog(onDismissRequest = { showAccess = false }) {
                Surface(modifier = Modifier.fillMaxWidth().heightIn(max = 660.dp), color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .5f))) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ULTRON · Permission center", color = Crimson, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Enable only the access you want to use.", color = Color.LightGray, fontSize = 11.sp)
                            }
                            IconButton(onClick = { accessRefresh++ }) { Icon(Icons.Default.Refresh, "Refresh permission statuses", tint = Orange) }
                        }
                        HorizontalDivider(color = Crimson.copy(alpha = .35f))
                        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(itemsNow) { item ->
                                Surface(color = Color(0xFF171B22), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text(item.description, color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                                            Text(if (item.granted) "ENABLED" else "NOT ENABLED", color = if (item.granted) Color(0xFF9AD6A5) else Orange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                        if (item.action.startsWith("runtime:")) {
                                            TextButton(onClick = {
                                                val permission = item.action.removePrefix("runtime:")
                                                if (item.granted) onOpenSpecialSetting("app_permissions")
                                                else if (permission == android.Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33) {
                                                    status = "Notification runtime permission is not required on this Android version"
                                                } else runtimePermissions.launch(arrayOf(permission))
                                            }) { Text(if (item.granted) "Review" else "Grant", color = Orange) }
                                        } else TextButton(onClick = { onOpenSpecialSetting(item.action.removePrefix("settings:")); accessRefresh++ }) { Text(if (item.granted) "Open" else "Enable", color = Orange) }
                                    }
                                }
                            }
                        }
                        Text("Accessibility and notification access are powerful. ULTRON reads screen text only when you command it and does not save notification message contents. Device admin does not provide root access.", color = Purple, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 8.dp))
                        TextButton(onClick = { accessRefresh++; showAccess = false }) { Text("Done", color = Crimson) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MemoryVaultScreen(modifier: Modifier = Modifier, database: UltronDatabase) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var memories by remember { mutableStateOf<List<MemoryRecord>>(emptyList()) }
    var notes by remember { mutableStateOf<List<NoteRecord>>(emptyList()) }
    var documents by remember { mutableStateOf<List<DocumentRecord>>(emptyList()) }
    var agentHistory by remember { mutableStateOf<List<UltronAgentHistoryItem>>(emptyList()) }
    var chats by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Loading private memory…") }
    var refresh by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    val q = search.trim().lowercase(Locale.ROOT)
    val visibleMemories = memories.filter { it.value.lowercase(Locale.ROOT).contains(q) }
    val visibleNotes = notes.filter { it.title.lowercase(Locale.ROOT).contains(q) || it.body.lowercase(Locale.ROOT).contains(q) }
    val visibleDocuments = documents.filter { it.title.lowercase(Locale.ROOT).contains(q) || it.extractedText.lowercase(Locale.ROOT).contains(q) }
    fun reload() {
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val m = database.memoryDao().all().map { it.copy(value = runCatching { PrivateTextVault.decrypt(it.value) }.getOrDefault("[Unable to decrypt item]")) }
                    val n = database.noteDao().latest(40).map { it.copy(title = runCatching { PrivateTextVault.decrypt(it.title) }.getOrDefault("Private note"), body = runCatching { PrivateTextVault.decrypt(it.body) }.getOrDefault("[Unable to decrypt note]")) }
                    val d = database.documentDao().latest(40).map { it.copy(title = runCatching { PrivateTextVault.decrypt(it.title) }.getOrDefault("Imported document"), extractedText = runCatching { PrivateTextVault.decrypt(it.extractedText) }.getOrDefault("")) }
                    val c = database.chatDao().latest(500).size
                    listOf(m, n, d, c)
                }
                @Suppress("UNCHECKED_CAST")
                memories = result[0] as List<MemoryRecord>
                @Suppress("UNCHECKED_CAST")
                notes = result[1] as List<NoteRecord>
                @Suppress("UNCHECKED_CAST")
                documents = result[2] as List<DocumentRecord>
                chats = result[3] as Int
                agentHistory = withContext(Dispatchers.IO) { UltronAgentHistoryStore.load(context) }
                status = "Private data loaded from this device"
            } catch (e: Exception) { status = "Memory could not be loaded: ${e.message ?: "storage error"}" }
        }
    }
    LaunchedEffect(refresh) { reload() }
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("MEMORY CORE", color = Crimson, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
        Text("PRIVATE KNOWLEDGE VAULT · ON DEVICE", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(status, color = Purple, fontSize = 10.sp)
        OutlinedTextField(
            value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Search memories, notes and documents") }, singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Orange) }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MemoryMetric("FACTS", memories.size.toString(), Modifier.weight(1f))
            MemoryMetric("NOTES", notes.size.toString(), Modifier.weight(1f))
            MemoryMetric("DOCUMENTS", documents.size.toString(), Modifier.weight(1f))
            MemoryMetric("CHATS", chats.toString(), Modifier.weight(1f))
        }
        MemorySection("SAVED KNOWLEDGE", visibleMemories.isEmpty()) {
            if (visibleMemories.isEmpty()) Text(if (q.isBlank()) "No facts saved yet. Say ‘remember that …’ in chat to add a memory." else "No matching saved facts.", color=Color.LightGray, fontSize=11.sp)
            visibleMemories.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("• ${item.value}", color=Color.White, fontSize=12.sp, lineHeight=17.sp, modifier=Modifier.weight(1f))
                    IconButton(onClick = { scope.launch { withContext(Dispatchers.IO) { database.memoryDao().deleteByKey(item.key) }; refresh++ } }) { Icon(Icons.Default.Delete, contentDescription = "Delete memory", tint = Crimson) }
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        MemorySection("PRIVATE NOTES", visibleNotes.isEmpty()) {
            if (visibleNotes.isEmpty()) Text(if (q.isBlank()) "No notes saved. Use ‘note: …’ in chat to create one." else "No matching private notes.", color=Color.LightGray, fontSize=11.sp)
            visibleNotes.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(item.title, color=Orange, fontWeight=FontWeight.Bold, fontSize=12.sp); Text(item.body, color=Color.White, fontSize=11.sp, lineHeight=16.sp) }
                    IconButton(onClick = { scope.launch { withContext(Dispatchers.IO) { database.noteDao().delete(item.id) }; refresh++ } }) { Icon(Icons.Default.Delete, contentDescription = "Delete note", tint = Crimson) }
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        MemorySection("IMPORTED DOCUMENTS", visibleDocuments.isEmpty()) {
            if (visibleDocuments.isEmpty()) Text(if (q.isBlank()) "No imported documents yet. Import documents from the document tools to build persistent knowledge." else "No matching imported documents.", color=Color.LightGray, fontSize=11.sp)
            visibleDocuments.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(item.title, color=Color.White, fontWeight=FontWeight.Bold, fontSize=12.sp); Text("${item.mimeType} · ${item.extractedText.length} extracted characters", color=Purple, fontSize=10.sp) }
                    IconButton(onClick = { scope.launch { withContext(Dispatchers.IO) { database.documentDao().delete(item.id) }; refresh++ } }) { Icon(Icons.Default.Delete, contentDescription = "Delete document", tint = Crimson) }
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        MemorySection("AGENT ACTIVITY · LOCAL AUDIT", agentHistory.isEmpty()) {
            if (agentHistory.isEmpty()) Text("No agent actions recorded yet. Device commands and confirmation decisions will appear here.", color=Color.LightGray, fontSize=11.sp)
            agentHistory.take(12).forEach { item ->
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(item.status.uppercase(), color = if (item.status.contains("completed")) Orange else Purple, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(item.createdAt)), color=Color.LightGray, fontSize=8.sp)
                    }
                    Text(item.command.ifBlank { "ULTRON action plan" }, color=Color.White, fontSize=11.sp)
                    if (item.total > 0) Text("${item.completed}/${item.total} actions accepted · ${item.verified} verified", color=Purple, fontSize=9.sp)
                    item.details.take(4).forEach { Text("· $it", color=Color.LightGray, fontSize=9.sp, lineHeight=12.sp) }
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        NeonAction("REFRESH MEMORY", Icons.Default.Refresh, { refresh++ }, Modifier.fillMaxWidth())
        NeonAction("DELETE SAVED FACTS", Icons.Default.Delete, {
            scope.launch { withContext(Dispatchers.IO) { database.memoryDao().clear() }; refresh++ }
        }, Modifier.fillMaxWidth())
        Text("Chat history is separate and follows the configured retention period. Deleting saved facts does not delete notes or documents.", color=Color.LightGray, fontSize=10.sp, lineHeight=14.sp)
    }
}

@Composable
private fun MemoryMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color=Color(0xFF171019), shape=RoundedCornerShape(14.dp), border=BorderStroke(1.dp, Purple.copy(alpha=.6f))) {
        Column(Modifier.padding(11.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text(value, color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Black)
            Text(label, color=Orange, fontSize=9.sp, fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
private fun MemorySection(title: String, empty: Boolean, content: @Composable ColumnScope.() -> Unit) {
    Surface(color=Color(0xFF151117), shape=RoundedCornerShape(16.dp), border=BorderStroke(1.dp, Crimson.copy(alpha=.55f)), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) { Text(title, color=if(empty) Purple else Orange, fontSize=11.sp, fontWeight=FontWeight.ExtraBold); Spacer(Modifier.weight(1f)); Text(if(empty) "EMPTY" else "LOCAL", color=Purple, fontSize=8.sp) }
            content()
        }
    }
}

@Composable
private fun DashboardScreen(modifier: Modifier = Modifier, mode: String, status: String, selectedAiName: String, aiNames: List<String>, onSelectAi: (String)->Unit, onChat:()->Unit, onVoice:()->Unit, onVision:()->Unit, onBrowser:()->Unit, onMemory:()->Unit, onModels:()->Unit, onSecurity:()->Unit, onPlugins:()->Unit) {
    val transition = rememberInfiniteTransition(label = "ultron-dashboard-hud")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(18_000, easing = LinearEasing), RepeatMode.Restart), label = "hud-rotation")
    val pulse by transition.animateFloat(.72f, 1f, infiniteRepeatable(tween(1_800), RepeatMode.Reverse), label = "hud-pulse")
    LazyColumn(modifier.fillMaxWidth(), contentPadding=PaddingValues(start=13.dp,end=13.dp,top=5.dp,bottom=18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ULTRON // COMMAND DECK", color=Color.White, fontSize=17.sp, fontWeight=FontWeight.Black, letterSpacing=1.3.sp)
                    Text("AUTONOMOUS INTELLIGENCE SYSTEM", color=Orange, fontSize=8.sp, letterSpacing=1.7.sp, fontWeight=FontWeight.Bold)
                }
                Surface(color=Color(0xFF211018), shape=RoundedCornerShape(30.dp), border=BorderStroke(1.dp,Crimson.copy(alpha=.8f))) {
                    Row(Modifier.padding(horizontal=10.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(6.dp).background(if(status.contains("fail",true)) Color(0xFFFF5555) else Color(0xFF72E6A4),RoundedCornerShape(8.dp)))
                        Text(if(status.contains("fail",true)) "ATTENTION" else "SYSTEM READY",color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Surface(color=Color(0xFF0D0B10), shape=RoundedCornerShape(25.dp), border=BorderStroke(1.dp,Brush.horizontalGradient(listOf(Crimson,Orange,Purple))), modifier=Modifier.fillMaxWidth()) {
                Box(Modifier.height(348.dp)) {
                    Image(painterResource(R.drawable.ultron_hero), contentDescription="ULTRON metallic crimson-eyed AI avatar", modifier=Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000),Color(0x22000000),Color(0xF308090D)))))
                    Canvas(Modifier.fillMaxSize()) {
                        val cx=size.width*.5f; val cy=size.height*.43f
                        val radius=minOf(size.width,size.height)*.36f
                        drawCircle(Color(0x77FF414B),radius,center=androidx.compose.ui.geometry.Offset(cx,cy),style=Stroke(1.2.dp.toPx()))
                        drawCircle(Color(0x669E83D8),radius*.91f,center=androidx.compose.ui.geometry.Offset(cx,cy),style=Stroke(.8.dp.toPx()))
                        rotate(rotation,androidx.compose.ui.geometry.Offset(cx,cy)) {
                            drawArc(Color(0xDDFF9A52),-24f,72f,false,topLeft=androidx.compose.ui.geometry.Offset(cx-radius,cy-radius),size=androidx.compose.ui.geometry.Size(radius*2,radius*2),style=Stroke(2.dp.toPx()))
                            drawArc(Color(0xCCFF343D),154f,96f,false,topLeft=androidx.compose.ui.geometry.Offset(cx-radius*.91f,cy-radius*.91f),size=androidx.compose.ui.geometry.Size(radius*1.82f,radius*1.82f),style=Stroke(2.5.dp.toPx()))
                            for (i in 0 until 36) {
                                val angle=i*10f
                                rotate(angle,androidx.compose.ui.geometry.Offset(cx,cy)) {
                                    drawLine(Color(0x99FF5961),androidx.compose.ui.geometry.Offset(cx,cy-radius*1.05f),androidx.compose.ui.geometry.Offset(cx,cy-radius*(if(i%3==0) .94f else .99f)),strokeWidth=if(i%3==0) 2.dp.toPx() else 1.dp.toPx())
                                }
                            }
                        }
                        drawCircle(Color(0x55FF343D),radius*1.12f*pulse,center=androidx.compose.ui.geometry.Offset(cx,cy),style=Stroke(1.dp.toPx()))
                    }
                    Column(Modifier.align(Alignment.TopStart).padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        Surface(color=Color(0xBB110D14),shape=RoundedCornerShape(20.dp),border=BorderStroke(1.dp,Crimson.copy(alpha=.7f))) {
                            Text("◉  NEURAL CORE ${mode.uppercase()} MODE",Modifier.padding(horizontal=10.dp,vertical=6.dp),color=Orange,fontSize=8.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                        }
                    }
                    Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("THE MACHINE IS AWAKE",color=Orange,fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
                        Text("I AM ULTRON",color=Color.White,fontSize=29.sp,fontWeight=FontWeight.Black,letterSpacing=1.6.sp)
                        Text(status.take(100),color=Color(0xFFE0D8DF),fontSize=9.sp,maxLines=2)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            Surface(Modifier.weight(1f).height(45.dp).clickable(onClick=onChat),color=Color(0xFF8D1724),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Crimson)) {
                                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center) { Icon(Icons.Default.Bolt,null,tint=Orange); Spacer(Modifier.width(7.dp)); Text("COMMAND",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp) }
                            }
                            Surface(Modifier.weight(1f).height(45.dp).clickable(onClick=onVoice),color=Color(0xDD17111B),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Purple)) {
                                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center) { Icon(Icons.Default.Mic,null,tint=Orange); Spacer(Modifier.width(7.dp)); Text("VOICE LINK",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp) }
                            }
                        }
                    }
                }
            }
        }
        item {
            var expanded by remember { mutableStateOf(false) }
            Surface(color=Color(0xFF14111A),shape=RoundedCornerShape(19.dp),border=BorderStroke(1.dp,Purple.copy(alpha=.78f)),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ACTIVE INTELLIGENCE",color=Purple,fontSize=8.sp,fontWeight=FontWeight.Black,letterSpacing=1.7.sp)
                            Text(selectedAiName,color=Color.White,fontSize=18.sp,fontWeight=FontWeight.ExtraBold)
                        }
                        TextButton(onClick={ expanded=true }) { Text("SWITCH AI  ▾",color=Orange,fontSize=10.sp,fontWeight=FontWeight.Bold) }
                        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { aiNames.forEach { name -> DropdownMenuItem(text={Text(name)},onClick={expanded=false;onSelectAi(name)}) } }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        listOf("REASONING","MEMORY","TOOLS").forEach { tag -> Surface(color=Color(0xFF211925),shape=RoundedCornerShape(7.dp)) { Text(tag,Modifier.padding(horizontal=8.dp,vertical=5.dp),color=if(tag=="TOOLS")Orange else Color.LightGray,fontSize=7.sp,fontWeight=FontWeight.Bold,letterSpacing=.6.sp) } }
                    }
                    Text("All-in-One can run parallel AI responses, peer review and final synthesis when two or more profiles are configured.",color=Color(0xFFBEB1C5),fontSize=9.sp,lineHeight=13.sp)
                }
            }
        }
        item { Row(verticalAlignment=Alignment.CenterVertically) { Text("SYSTEM MODULES",color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Black,letterSpacing=1.8.sp); Spacer(Modifier.weight(1f)); Text("SELECT A MODULE",color=Crimson,fontSize=8.sp,fontWeight=FontWeight.Bold) } }
        item {
            Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("VISION", "Camera intelligence", Icons.Default.Visibility, Modifier.weight(1f), onVision)
                    DashboardTile("BROWSER", "Web operations", Icons.Default.Language, Modifier.weight(1f), onBrowser)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("MEMORY", "Private knowledge vault", Icons.Default.Psychology, Modifier.weight(1f), onMemory)
                    DashboardTile("PLUGINS", "Connected capabilities", Icons.Default.Extension, Modifier.weight(1f), onPlugins)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("MODEL VAULT", "Offline GGUF models", Icons.Default.Memory, Modifier.weight(1f), onModels)
                    DashboardTile("SECURITY", "Permissions & protection", Icons.Default.Security, Modifier.weight(1f), onSecurity)
                }
            }
        }
        item { Text("ULTRON // BUILT TO UNDERSTAND. DESIGNED TO ACT.",color=Purple,fontSize=8.sp,letterSpacing=1.1.sp,modifier=Modifier.fillMaxWidth().padding(vertical=6.dp)) }
    }
}

@Composable
private fun DashboardTile(title:String, subtitle:String, icon:androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier=Modifier, onClick:()->Unit) {
    Surface(modifier=modifier.height(112.dp).clickable(onClick=onClick), color=Color(0xFF14121A), shape=RoundedCornerShape(17.dp), border=BorderStroke(1.dp,Brush.linearGradient(listOf(Crimson.copy(alpha=.72f),Purple.copy(alpha=.45f),Color(0xFF4B2930))))) {
        Row(Modifier.fillMaxSize().padding(13.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(11.dp)) {
            Surface(color=Color(0xFF28151E),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Crimson.copy(alpha=.45f))) { Box(Modifier.size(43.dp),contentAlignment=Alignment.Center) { Icon(icon,contentDescription=null,tint=if(title=="MEMORY") Purple else Orange,modifier=Modifier.size(23.dp)) } }
            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                Text(title,color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=.9.sp,maxLines=1)
                Text(subtitle,color=Color(0xFFBDB5C2),fontSize=8.sp,maxLines=2,lineHeight=11.sp)
            }
            Icon(Icons.Default.ChevronRight,null,tint=Crimson,modifier=Modifier.size(17.dp))
        }
    }
}

@Composable
private fun NeonAction(label:String, icon:androidx.compose.ui.graphics.vector.ImageVector, onClick:()->Unit, modifier:Modifier=Modifier) {
    Surface(modifier=modifier.height(46.dp).clickable(onClick=onClick), color=Color(0xFF351016), shape=RoundedCornerShape(13.dp), border=BorderStroke(1.dp,Crimson)) {
        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.Center) { Icon(icon,contentDescription=null,tint=Orange); Spacer(Modifier.width(9.dp)); Text(label,color=Color.White,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp) }
    }
}

@Composable
private fun VoiceFeatureScreen(modifier:Modifier=Modifier,onStart:()->Unit,onStop:()->Unit,onSpeak:()->Unit) {
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=18.dp, vertical=12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(13.dp)) {
        Surface(color=Color(0xFF100B11), shape=RoundedCornerShape(24.dp), border=BorderStroke(1.dp,Crimson.copy(alpha=.8f)), modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("NEURAL VOICE LINK", color=Orange, fontSize=9.sp, fontWeight=FontWeight.Bold, letterSpacing=1.6.sp); Text("NEURAL CORE · LIVE LINK", color=Color.White, fontSize=17.sp, fontWeight=FontWeight.Black) }
                    Surface(color=Color(0xFF251018), shape=RoundedCornerShape(20.dp), border=BorderStroke(1.dp,Crimson)) { Text("ULTRON", color=Crimson, fontSize=9.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=10.dp, vertical=6.dp)) }
                }
                Spacer(Modifier.height(18.dp))
                val hudTransition = rememberInfiniteTransition(label = "voice-core-hud")
                val hudRotation by hudTransition.animateFloat(0f, 360f, infiniteRepeatable(tween(12_000, easing = LinearEasing), RepeatMode.Restart), label = "voice-hud-rotation")
                val hudPulse by hudTransition.animateFloat(.82f, 1.04f, infiniteRepeatable(tween(1_500), RepeatMode.Reverse), label = "voice-hud-pulse")
                Box(Modifier.fillMaxWidth().widthIn(max = 304.dp).aspectRatio(1f).background(Brush.radialGradient(listOf(Color(0xEE8C1728),Color(0x99400D25),Color(0x44200A20),Color.Transparent)),RoundedCornerShape(170.dp)), contentAlignment=Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        rotate(hudRotation) {
                            drawCircle(Brush.sweepGradient(listOf(Crimson, Orange, Purple, Crimson)), radius = size.minDimension * .48f, style = Stroke(width = 2.2.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(22f, 11f), 0f)))
                        }
                        drawCircle(Crimson.copy(alpha = .45f * hudPulse), radius = size.minDimension * .43f, style = Stroke(width = 1.dp.toPx()))
                        drawCircle(Purple.copy(alpha = .55f), radius = size.minDimension * .38f, style = Stroke(width = 1.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(5f, 8f), 0f)))
                    }
                    AndroidView(factory = { viewContext -> UltronGifView(viewContext) }, modifier = Modifier.fillMaxSize().padding(14.dp))
                }
                Text("WAKE WORD · ULTRON", color=Crimson, fontSize=15.sp, fontWeight=FontWeight.Black, letterSpacing=1.8.sp)
                Text("Say ‘ULTRON’, pause, then speak your command", color=Color.LightGray, fontSize=10.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(5.dp), verticalAlignment=Alignment.CenterVertically) {
                    repeat(17) { i -> Box(Modifier.width(5.dp).height((10 + (i * 13 % 34)).dp).background(if (i % 3 == 0) Orange else Crimson.copy(alpha=.8f), RoundedCornerShape(4.dp))) }
                }
                Spacer(Modifier.height(18.dp))
                NeonAction("ARM WAKE-WORD LISTENER",Icons.Default.Mic,onStart,Modifier.fillMaxWidth())
                NeonAction("DISARM LISTENER",Icons.Default.Stop,onStop,Modifier.fillMaxWidth())
            }
        }
        Surface(color=Color(0xFF151117), shape=RoundedCornerShape(17.dp), border=BorderStroke(1.dp,Purple.copy(alpha=.55f)), modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Text("COMMAND EXAMPLES", color=Orange, fontWeight=FontWeight.Bold, fontSize=10.sp)
                Text("• ‘ULTRON, open YouTube and search BMW’", color=Color.White, fontSize=11.sp)
                Text("• ‘ULTRON, open Settings’", color=Color.White, fontSize=11.sp)
                Text("• ‘ULTRON’ then say ‘search the web for latest Android news’", color=Color.White, fontSize=11.sp)
            }
        }
        Text("Requires microphone permission and an ongoing Android foreground-service notification. Older Android versions use the device's installed speech recognizer; background limits and battery settings can still affect listening.",color=Color.LightGray,fontSize=9.sp,lineHeight=13.sp)
    }
}

@Composable
private fun OfflineModelScreen(
    modifier: Modifier = Modifier,
    enabled: Boolean,
    onEnabled: (Boolean) -> Unit,
    modelStatus: String,
    onFindQwen: () -> Unit,
    onImport: () -> Unit,
    onDownload: (String) -> Unit,
    onDelete: () -> Unit
) {
    var directUrl by remember { mutableStateOf("") }
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text("LOCAL MODEL VAULT", color = Crimson, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
        Text("OFFLINE INTELLIGENCE · ON DEVICE", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Surface(color = Color(0xFF171019), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Purple.copy(alpha = .65f)), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Enable Offline AI", color = Color.White, fontWeight = FontWeight.Bold); Text("When enabled, chat uses the imported local GGUF instead of online endpoints.", color = Color.LightGray, fontSize = 9.sp) }
                Switch(checked = enabled, onCheckedChange = onEnabled)
            }
        }
        Text("RECOMMENDED MODEL", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Surface(color = Color(0xFF151117), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .6f)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("Qwen3.5-4B-Amadeus Q4_K", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                Text("GGUF · local inference · user-controlled installation", color = Orange, fontSize = 9.sp)
                Text("The model repository page lets you choose a compatible GGUF asset. ULTRON does not silently download or replace models.", color = Color.LightGray, fontSize = 10.sp)
                NeonAction("FIND QWEN GGUF DOWNLOAD", Icons.Default.Search, onFindQwen, Modifier.fillMaxWidth())
                OutlinedTextField(value = directUrl, onValueChange = { directUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Direct HTTPS .gguf asset URL") }, placeholder = { Text("https://.../resolve/main/model.gguf") }, minLines = 2)
                NeonAction("DOWNLOAD FROM DIRECT URL", Icons.Default.Download, { if (directUrl.isNotBlank()) onDownload(directUrl.trim()) }, Modifier.fillMaxWidth())
            }
        }
        Text("CURRENT LOCAL MODEL", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(modelStatus, color = Color.LightGray, fontSize = 10.sp, lineHeight = 15.sp)
        NeonAction("IMPORT / REPLACE GGUF MODEL", Icons.Default.FileOpen, onImport, Modifier.fillMaxWidth())
        NeonAction("DELETE LOCAL MODEL", Icons.Default.Delete, onDelete, Modifier.fillMaxWidth())
        Text("This vault is separate from Online AI profiles. Importing a model does not configure or change your InstaBox connections.", color = Purple, fontSize = 10.sp, lineHeight = 14.sp)
    }
}

@Composable
private fun PluginHubScreen(modifier: Modifier = Modifier, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { PluginStore(context) }
    var plugins by remember { mutableStateOf(store.load()) }
    var name by remember { mutableStateOf("") }
    var template by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Add a website shortcut or configure an API integration with your own credentials.") }
    var apiName by remember { mutableStateOf("") }
    var apiEndpoint by remember { mutableStateOf("") }
    var apiMethod by remember { mutableStateOf("GET") }
    var apiAuth by remember { mutableStateOf("bearer") }
    var apiCredential by remember { mutableStateOf("") }
    var apiSecondCredential by remember { mutableStateOf("") }
    var apiHeader by remember { mutableStateOf("X-API-Key") }
    var apiBody by remember { mutableStateOf("{\"query\":\"{query}\"}") }
    var oauthAuthUrl by remember { mutableStateOf("") }
    var oauthTokenUrl by remember { mutableStateOf("") }
    var oauthClientId by remember { mutableStateOf("") }
    var oauthClientSecret by remember { mutableStateOf("") }
    var oauthRedirect by remember { mutableStateOf("ultron://oauth/callback") }
    var oauthScope by remember { mutableStateOf("") }
    val builtIns = listOf(
        WebPlugin("youtube", "YouTube", "https://www.youtube.com/results?search_query={query}"),
        WebPlugin("google", "Google", "https://www.google.com/search?q={query}"),
        WebPlugin("wikipedia", "Wikipedia", "https://en.wikipedia.org/w/index.php?search={query}"),
        WebPlugin("github", "GitHub", "https://github.com/search?q={query}"),
        WebPlugin("stackoverflow", "Stack Overflow", "https://stackoverflow.com/search?q={query}")
    )
    LazyColumn(modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("PLUGIN ARMORY", color = Crimson, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text("CONNECT YOUR OWN WEB TOOLS", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("Built-in websites and your custom HTTPS plugins can be opened or searched from ULTRON commands.", color = Color.LightGray, fontSize = 10.sp)
        }
        item { Text("BUILT-IN", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        items(builtIns) { plugin ->
            Surface(color = Color(0xFF151117), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .55f)), modifier = Modifier.fillMaxWidth().clickable { onOpen(PluginStore.expand(plugin.urlTemplate, "")) }) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(plugin.name, color = Color.White, fontWeight = FontWeight.Bold); Text("Searchable website · HTTPS", color = Color.LightGray, fontSize = 9.sp) }
                    TextButton(onClick = { onOpen(PluginStore.expand(plugin.urlTemplate, "")) }) { Text("OPEN", color = Orange) }
                }
            }
        }
        item { Text("YOUR PLUGINS", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        items(plugins, key = { it.id }) { plugin ->
            Surface(color = Color(0xFF151117), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Purple.copy(alpha = .55f)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(plugin.name, color = Color.White, fontWeight = FontWeight.Bold); Text(if (plugin.kind == "website") plugin.urlTemplate else "${plugin.kind.uppercase()} · ${plugin.method} · ${plugin.authType}", color = Color.LightGray, fontSize = 8.sp, maxLines = 2) }
                    if (plugin.kind == "website") TextButton(onClick = { onOpen(PluginStore.expand(plugin.urlTemplate, "")) }) { Text("OPEN", color = Orange) }
                    TextButton(onClick = { plugins = plugins.filterNot { it.id == plugin.id }; store.save(plugins); message = "Removed ${plugin.name}" }) { Text("×", color = Crimson) }
                }
            }
        }
        item {
            HorizontalDivider(color = Crimson.copy(alpha = .4f))
            Text("ADD WEBSITE PLUGIN", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Plugin name (e.g. BMW Forum)") }, singleLine = true)
            OutlinedTextField(value = template, onValueChange = { template = it }, modifier = Modifier.fillMaxWidth(), label = { Text("HTTPS URL template") }, placeholder = { Text("https://example.com/search?q={query}") }, minLines = 2)
            Text("Use {query} where ULTRON should insert the search terms. Example command: ‘search BMW on BMW Forum’. Only HTTPS URLs are accepted.", color = Color.LightGray, fontSize = 9.sp)
            NeonAction("ADD PLUGIN", Icons.Default.Add, {
                runCatching { store.add(name, template); plugins = store.load(); message = "Added $name. Try ‘search BMW on $name’."; name = ""; template = "" }
                    .onFailure { message = it.message ?: "Could not add plugin" }
            }, Modifier.fillMaxWidth())
            Text(message, color = Purple, fontSize = 10.sp)
        }
        item {
            HorizontalDivider(color = Purple.copy(alpha = .5f))
            Text("API INTEGRATION BUILDER", color = Orange, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("Connect your own HTTPS REST API. Credentials are encrypted locally with Android Keystore. Use {query} in the endpoint and request body.", color = Color.LightGray, fontSize = 10.sp)
            OutlinedTextField(value = apiName, onValueChange = { apiName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Integration name") }, singleLine = true)
            OutlinedTextField(value = apiEndpoint, onValueChange = { apiEndpoint = it }, modifier = Modifier.fillMaxWidth(), label = { Text("HTTPS resource/API endpoint") }, placeholder = { Text("https://api.example.com/v1/action") }, singleLine = true)
            OutlinedTextField(value = apiMethod, onValueChange = { apiMethod = it.uppercase().take(6) }, modifier = Modifier.fillMaxWidth(), label = { Text("HTTP method: GET / POST / PUT / PATCH / DELETE") }, singleLine = true)
            OutlinedTextField(value = apiAuth, onValueChange = { apiAuth = it.lowercase().take(20) }, modifier = Modifier.fillMaxWidth(), label = { Text("Auth: none / bearer / api_key_header / api_key_query / basic") }, singleLine = true)
            OutlinedTextField(value = apiCredential, onValueChange = { apiCredential = it }, modifier = Modifier.fillMaxWidth(), label = { Text("API token / username") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(value = apiSecondCredential, onValueChange = { apiSecondCredential = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Password (Basic auth only)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(value = apiHeader, onValueChange = { apiHeader = it }, modifier = Modifier.fillMaxWidth(), label = { Text("API key header or query parameter name") }, singleLine = true)
            OutlinedTextField(value = apiBody, onValueChange = { apiBody = it }, modifier = Modifier.fillMaxWidth(), label = { Text("JSON body template (POST/PUT/PATCH)") }, minLines = 2)
            NeonAction("SAVE API INTEGRATION", Icons.Default.Add, {
                runCatching {
                    val saved = store.addIntegration(WebPlugin(id = "", name = apiName, kind = "rest", endpoint = apiEndpoint, method = apiMethod, authType = apiAuth, credential = apiCredential, secondaryCredential = apiSecondCredential, headerName = apiHeader, bodyTemplate = apiBody))
                    plugins = store.load(); message = "Saved ${saved.name}. Use ‘run plugin ${saved.name} with your request’ in chat."
                    apiName = ""; apiEndpoint = ""; apiCredential = ""; apiSecondCredential = ""
                }.onFailure { message = it.message ?: "Could not save API integration" }
            }, Modifier.fillMaxWidth())
            Text("OAUTH 2.0 CONNECTION", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("OAuth 2.0 Authorization Code + PKCE. Add the provider's resource/API endpoint above, choose its HTTP method and JSON body, then register the exact redirect URI ultron://oauth/callback. Some providers require provider-specific parameters or prohibit custom URI redirects.", color = Color.LightGray, fontSize = 9.sp)
            OutlinedTextField(value = oauthAuthUrl, onValueChange = { oauthAuthUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Authorization URL") }, singleLine = true)
            OutlinedTextField(value = oauthTokenUrl, onValueChange = { oauthTokenUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Token URL") }, singleLine = true)
            OutlinedTextField(value = oauthClientId, onValueChange = { oauthClientId = it }, modifier = Modifier.fillMaxWidth(), label = { Text("OAuth client ID") }, singleLine = true)
            OutlinedTextField(value = oauthClientSecret, onValueChange = { oauthClientSecret = it }, modifier = Modifier.fillMaxWidth(), label = { Text("OAuth client secret") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(value = oauthRedirect, onValueChange = { oauthRedirect = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Redirect URI") }, singleLine = true)
            OutlinedTextField(value = oauthScope, onValueChange = { oauthScope = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Scopes (space-separated)") }, singleLine = true)
            NeonAction("SAVE OAUTH CONFIGURATION", Icons.Default.Security, {
                runCatching {
                    val saved = store.addIntegration(WebPlugin(id = "", name = apiName, kind = "oauth2", endpoint = apiEndpoint, method = apiMethod, authType = "bearer", bodyTemplate = apiBody, oauthAuthorizeUrl = oauthAuthUrl, oauthTokenUrl = oauthTokenUrl, oauthClientId = oauthClientId, oauthClientSecret = oauthClientSecret, oauthRedirectUri = oauthRedirect, oauthScope = oauthScope))
                    plugins = store.load(); message = "OAuth configuration saved for ${saved.name}. Provider-specific callback and token exchange must be supported by that service."
                }.onFailure { message = it.message ?: "Could not save OAuth configuration" }
            }, Modifier.fillMaxWidth())
            plugins.filter { it.kind == "oauth2" }.forEach { plugin ->
                TextButton(onClick = { runCatching { onOpen(store.beginOAuth(plugin)); message = "Opening ${plugin.name} authorization…" }.onFailure { message = it.message ?: "Could not open OAuth" } }) { Text("AUTHORIZE ${plugin.name.uppercase()}", color = Orange) }
            }
            Text(message, color = Purple, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SimpleFeatureScreen(modifier:Modifier=Modifier,title:String, subtitle:String, items:List<String>, note:String) {
    Column(modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(title,color=Crimson,fontSize=20.sp,fontWeight=FontWeight.Black,letterSpacing=1.5.sp); Text(subtitle,color=Orange,fontSize=10.sp)
        items.forEach { item -> Surface(color=Color(0xFF151117),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Crimson.copy(alpha=.45f)),modifier=Modifier.fillMaxWidth()) { Text(item,color=Color.White,fontSize=12.sp,modifier=Modifier.padding(14.dp)) } }
        Text(note,color=Purple,fontSize=10.sp,lineHeight=15.sp)
    }
}

@Composable
private fun BottomNavItem(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,selected:Boolean,onClick:()->Unit) {
    Column(Modifier.clickable(onClick=onClick).padding(horizontal=7.dp,vertical=3.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(icon,contentDescription=label,tint=if(selected) Crimson else Color(0xFFAAA3AD),modifier=Modifier.size(21.dp))
        Text(label,color=if(selected) Orange else Color(0xFFAAA3AD),fontSize=8.sp,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun AppLockScreen(onUnlock: () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Orange, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF24080D), Night))), contentAlignment = Alignment.Center) {
            Surface(color = Panel, shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .7f)), modifier = Modifier.padding(24.dp)) {
                Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("◉", color = Crimson, fontSize = 54.sp, fontWeight = FontWeight.Black)
                    Text("ULTRON LOCKED", color = Crimson, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Authenticate to access your assistant and locally stored private data.", color = Color.LightGray, fontSize = 13.sp)
                    Button(onClick = onUnlock, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Fingerprint, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Unlock ULTRON") }
                }
            }
        }
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean = false, onClick: (() -> Unit)? = null) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = { onClick?.invoke() }) { Icon(icon, contentDescription = label, tint = if (active) Crimson else Color(0xFFB7B5C0), modifier = Modifier.size(22.dp)) }
        Text(label, color = Color(0xFFB7B5C0), fontSize = 8.sp)
    }
}
