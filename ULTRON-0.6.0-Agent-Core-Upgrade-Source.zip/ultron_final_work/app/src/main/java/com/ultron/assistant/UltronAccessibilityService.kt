package com.ultron.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Bundle
import android.util.DisplayMetrics
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** User-enabled helper. It only reads or acts after a user command; it does not send screen contents to a server. */
class UltronAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); active = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Observe no content by default. */ }
    override fun onInterrupt() = Unit
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }

    fun findVisibleText(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val matches = try { root.findAccessibilityNodeInfosByText(text) } finally { root.recycle() }
        val match = matches.firstOrNull { it.isVisibleToUser }
        matches.filter { it !== match }.forEach { it.recycle() }
        return match
    }

    fun clickText(text: String): Boolean {
        var current: AccessibilityNodeInfo? = findVisibleText(text) ?: return false
        while (current != null) {
            val clicked = current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val parent = current.parent
            current.recycle()
            if (clicked) {
                parent?.recycle()
                return true
            }
            current = parent
        }
        return false
    }

    fun readVisibleText(limit: Int = 5_000): String {
        val root = rootInActiveWindow ?: return "No active app window is available."
        val result = StringBuilder()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || result.length >= limit || depth > 30) return
            if (node.isVisibleToUser) {
                val label = node.text?.toString()?.trim().orEmpty().ifBlank { node.contentDescription?.toString()?.trim().orEmpty() }
                if (label.isNotBlank()) result.append(label).append('\n')
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                try { walk(child, depth + 1) } finally { child?.recycle() }
            }
        }
        try { walk(root, 0) } finally { root.recycle() }
        return result.toString().take(limit).ifBlank { "No readable text was exposed by the active app." }
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (node.isVisibleToUser && node.isScrollable) return AccessibilityNodeInfo.obtain(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                val found = try { findScrollable(child) } finally { child?.recycle() }
                if (found != null) return found
            }
            return null
        }
        return try {
            val target = findScrollable(root) ?: root
            val ok = target.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
            if (target !== root) target.recycle()
            ok
        } finally { root.recycle() }
    }

    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }

    /** Fills the focused editable node; if focus is absent, proceeds only when exactly one editable is visible. */
    fun typeText(value: String): Boolean {
        if (value.isEmpty()) return false
        val root = rootInActiveWindow ?: return false
        fun collectEditable(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
            if (node == null || out.size > 8) return
            if (node.isVisibleToUser && node.isEditable) {
                out += AccessibilityNodeInfo.obtain(node)
                return
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                try { collectEditable(child, out) } finally { child?.recycle() }
                if (out.size > 8) break
            }
        }
        var target = runCatching { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
        if (target?.isEditable != true) {
            target?.recycle()
            target = null
            val candidates = mutableListOf<AccessibilityNodeInfo>()
            collectEditable(root, candidates)
            if (candidates.size == 1) target = candidates.single()
            else candidates.forEach { it.recycle() }
        }
        return try {
            val node = target ?: return false
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value.take(2_000)) }
            val accepted = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            val resulting = node.text?.toString().orEmpty()
            accepted && resulting == value.take(2_000)
        } finally {
            target?.recycle()
            root.recycle()
        }
    }

    /** Dispatches a directional swipe over the central portion of the screen. */
    fun swipe(direction: String): Boolean {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels.toFloat()
        val h = metrics.heightPixels.toFloat()
        val cx = w * .5f
        val cy = h * .52f
        val (sx, sy, ex, ey) = when (direction.lowercase()) {
            "up" -> floatArrayOf(cx, h * .78f, cx, h * .30f)
            "down" -> floatArrayOf(cx, h * .30f, cx, h * .78f)
            "left" -> floatArrayOf(w * .82f, cy, w * .18f, cy)
            "right" -> floatArrayOf(w * .18f, cy, w * .82f, cy)
            else -> return false
        }
        val path = Path().apply { moveTo(sx, sy); lineTo(ex, ey) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 360)).build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }

    fun tapNormalized(x: Float, y: Float): Boolean {
        val metrics = resources.displayMetrics
        val px = x.coerceIn(0f, 1f) * metrics.widthPixels
        val py = y.coerceIn(0f, 1f) * metrics.heightPixels
        return tap(px, py)
    }

    fun activePackageName(): String? {
        val root = rootInActiveWindow ?: return null
        return try { root.packageName?.toString() } finally { root.recycle() }
    }

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun clickTextInPackage(packageName: String, text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val activePackage = root.packageName?.toString()
        root.recycle()
        if (activePackage != packageName) return false
        return clickText(text)
    }

    companion object {
        @Volatile private var active: UltronAccessibilityService? = null
        fun instance(): UltronAccessibilityService? = active
    }
}
