package com.ultron.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UltronAgentSafetyPolicyTest {
    @Test fun messageAndCallActionsAlwaysRequireApproval() {
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "compose_whatsapp")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "compose_sms")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "call")))
    }

    @Test fun destructiveButtonLabelsRequireApproval() {
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = "Send")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = "Delete account")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = "भेजें")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = "Save changes")))
        assertTrue(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = "Accept agreement")))
    }

    @Test fun harmlessNavigationDoesNotRequireApproval() {
        assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "open_app", app = "YouTube")))
        assertFalse(UltronAgentSafetyPolicy.requiresConfirmation(UltronAgentAction(type = "click_text", text = "Search")))
    }

    @Test fun pluginCommandsAreSentThroughTheAgentPlanner() {
        assertTrue(UltronAgentPlanner.looksLikeDeviceCommand("run plugin my site with update profile"))
    }

    @Test fun apiPluginsRequireApproval() {
        assertTrue(UltronAgentSafetyPolicy.pluginRequiresConfirmation("POST", "rest"))
        assertTrue(UltronAgentSafetyPolicy.pluginRequiresConfirmation("GET", "oauth2"))
        assertTrue(UltronAgentSafetyPolicy.pluginRequiresConfirmation("GET", "rest"))
    }
}
