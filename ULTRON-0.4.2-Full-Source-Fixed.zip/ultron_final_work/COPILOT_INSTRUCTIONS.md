# ULTRON implementation plan — preserve working code
The project already has a working online OpenAI-compatible API client and UI. Do not replace real API calls with fake responses. Build/test each change.

## Visual direction
Near-black charcoal surfaces; crimson red dominant; restrained burnt orange; minimal muted purple. Royal futuristic villain aesthetic without sacrificing legibility.

## Next milestones
1. Add Gradle wrapper, run CI and fix all build/test errors.
2. Add Android Keystore-backed encryption for online token; add TLS-only URL validation and a connection test.
3. Integrate pinned llama.cpp Android native runtime, GGUF file manager, model download consent/checksum/progress/cancel and real local inference. Do not fake local responses.
4. Offline AI is optional and disabled by default. Online API mode is the default. Only enable offline inference after explicit user opt-in. Allow users to import, replace, and delete any llama.cpp-compatible GGUF model. Do not implement RAM-tier model selection, forced Qwen, or automatic model fallback.
5. Room migrations, searchable chat history, explicit memory approve/edit/delete, user-controlled 3-day temporary retention with WorkManager.
6. Real offline wake-word “Ultron” via a vetted engine in a visible foreground service with persistent notification, opt-in control and battery tests. Tap-to-talk must not be called wake-word detection.
7. TTS voice picker/preview and language selection; use only installed/available voices.
8. CameraX user-initiated capture, on-device OCR/object detection, optional validated local VLM; never save images by default.
9. User-enabled accessibility tasks with previews, risk confirmation, allow-list, stop button, outcome verification and audit log.
10. Add device actions incrementally using intents/settings panels and runtime permissions. Do not claim direct control when Android disallows it.
11. Add biometric app lock, Keystore encryption, privacy dashboard, guest mode, data export/delete.
12. Add plugin adapters for GitHub, Render, external services etc. only when configured; store credentials securely and never commit secrets.
13. Implement reminder/calendar/notes workflows with confirmation for external side effects; comprehensive tests and feature matrix.

## Online LLM
Keep the `OpenAICompatibleProvider` API adapter and configurable base URL/model. Add provider-specific adapters only after the user provides the actual InstaBox OpenAI-compatible endpoint contract. Do not log prompts, tokens, or secrets. Add timeout, cancellation, response size limits, HTTP error reporting, TLS validation, and streaming later.

## Privacy
Online prompts are sent to the configured host. Do not append private saved memory automatically without explicit user choice. No covert microphone/camera capture, no hidden exfiltration. Keep API tokens out of Git.
