# ULTRON 0.4.5

- Replaced all Oracle-specific inference defaults and error messages with the user's InstaBox OpenAI-compatible gateway configuration.
- Online AI remains the default. Gateway URL, model ID and API key are entered by the user; the API key remains encrypted with Android Keystore.
- Offline AI remains optional and requires explicit opt-in. Users can search for Qwen3.5-4B-Amadeus GGUF, paste a direct HTTPS GGUF asset URL to download/install, or import a local GGUF file. Models can be replaced or deleted.
- No RAM-tier model selection or automatic model substitution.
- Added a dashboard-style ULTRON home panel with quick tiles for Voice, Vision, Browser, Memory, Model Manager and Security.
- Updated GitHub Actions Android SDK setup to locate sdkmanager and install platform/build tools/NDK/CMake explicitly.
- Build and device verification still required; this source archive is not a verified APK.
