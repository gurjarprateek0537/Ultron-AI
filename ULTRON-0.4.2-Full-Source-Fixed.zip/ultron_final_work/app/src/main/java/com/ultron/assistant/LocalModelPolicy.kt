package com.ultron.assistant

/** Describes the optional user-managed offline model runtime. No model is bundled or selected automatically. */
object LocalModelPolicy {
    fun describe(): String = buildString {
        append("Offline AI is optional and is disabled until you enable it.\n")
        append("Import a GGUF model from your device after enabling Offline AI. Recommended starting model: Qwen3.5-4B-Amadeus Q4_K. It is not bundled or downloaded automatically; import it yourself, or choose another compatible GGUF.\n")
        append("Other compatible GGUF models can also be imported, replaced, or deleted.\n")
        append("Model compatibility and memory requirements depend on the model and device; ULTRON will report load errors and will not silently switch models.")
    }
}
