package com.ultron.assistant

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** JNI bridge to upstream llama.cpp. User-imported GGUF files are stored in app-private storage. */
object NativeLlamaRuntime {
    private var libraryLoaded = false
    private var loadedPath: String? = null
    private var handle: Long = 0L
    private val lock = Any()

    init { libraryLoaded = runCatching { System.loadLibrary("ultron_llama"); true }.getOrDefault(false) }

    external fun nativeLoad(path: String, contextSize: Int, threads: Int): Long
    external fun nativeGenerate(handle: Long, prompt: String, maxTokens: Int): String
    external fun nativeFree(handle: Long)

    fun isAvailable(): Boolean = libraryLoaded

    fun importModel(context: Context, uriString: String): File {
        val uri = android.net.Uri.parse(uriString)
        val resolver = context.contentResolver
        val name = resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }?.takeIf { it.endsWith(".gguf", ignoreCase = true) } ?: "selected-model.gguf"
        val dir = File(context.filesDir, "models").apply { mkdirs() }
        val target = File(dir, "active-model.gguf")
        val temp = File(dir, "active-model.part")
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Android could not open the selected model file." }
            FileOutputStream(temp).use { output -> input.copyTo(output) }
        }
        require(temp.length() > 1024 * 1024) { "The selected file is too small to be a GGUF model." }
        // Basic magic validation prevents accidentally loading a renamed PDF or ZIP.
        val magic = ByteArray(4)
        temp.inputStream().use { require(it.read(magic) == 4 && magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46))) { "This file does not have the GGUF file signature." } }
        synchronized(lock) {
            if (handle != 0L) { runCatching { nativeFree(handle) }; handle = 0L; loadedPath = null }
            if (target.exists()) target.delete()
            check(temp.renameTo(target)) { "Could not move model into app-private storage." }
            context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE).edit()
                .putString("model_path", target.absolutePath).putString("model_original_name", name).apply()
        }
        return target
    }

    /** Downloads a user-supplied direct HTTPS GGUF URL and installs it as the active model. */
    fun downloadModel(context: Context, downloadUrl: String): File {
        val parsed = android.net.Uri.parse(downloadUrl.trim())
        require(parsed.scheme == "https" && !parsed.host.isNullOrBlank()) {
            "Enter a direct HTTPS download URL for a GGUF file."
        }
        val dir = File(context.filesDir, "models").apply { mkdirs() }
        val temp = File(dir, "active-model.download")
        val target = File(dir, "active-model.gguf")
        try {
            val connection = (URL(downloadUrl.trim()).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000
                readTimeout = 60000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("Accept", "application/octet-stream")
            }
            try {
                val code = connection.responseCode
                require(code in 200..299) { "Model download failed with HTTP $code. Check that the URL points directly to a downloadable GGUF file." }
                connection.inputStream.use { input -> FileOutputStream(temp).use { output -> input.copyTo(output) } }
            } finally { connection.disconnect() }
            require(temp.length() > 1024 * 1024) { "Downloaded file is too small to be a GGUF model." }
            val magic = ByteArray(4)
            temp.inputStream().use { require(it.read(magic) == 4 && magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46))) { "Downloaded file is not GGUF. Use the direct .gguf asset URL, not a repository page." } }
            synchronized(lock) {
                if (handle != 0L) { runCatching { nativeFree(handle) }; handle = 0L; loadedPath = null }
                if (target.exists()) target.delete()
                check(temp.renameTo(target)) { "Could not install downloaded GGUF in app-private storage." }
                context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE).edit()
                    .putString("model_path", target.absolutePath).putString("model_original_name", parsed.lastPathSegment ?: "downloaded-model.gguf").apply()
            }
            return target
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
    }

    fun activeModelPath(context: Context): String? = context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE)
        .getString("model_path", null)?.takeIf { File(it).isFile }

    fun activeModelName(context: Context): String = context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE)
        .getString("model_original_name", "No model selected") ?: "No model selected"

    fun deleteModel(context: Context): Boolean = synchronized(lock) {
        if (handle != 0L) { runCatching { nativeFree(handle) }; handle = 0L; loadedPath = null }
        val dir = File(context.filesDir, "models")
        val deleted = !dir.exists() || dir.deleteRecursively()
        context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE).edit()
            .remove("model_path").remove("model_original_name").apply()
        deleted
    }

    fun generate(context: Context, prompt: String, maxTokens: Int = 512): String = synchronized(lock) {
        check(libraryLoaded) { "The native llama.cpp library did not load. Check the GitHub Actions native build log and install an arm64-v8a build." }
        val path = activeModelPath(context) ?: throw IllegalStateException("No offline model selected. Open Settings → enable Offline AI → import a compatible GGUF model.")
        if (handle == 0L || loadedPath != path) {
            if (handle != 0L) runCatching { nativeFree(handle) }
            // Fixed conservative context size: no RAM-tier model or context selection.
            val contextSize = 1024
            val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 6)
            handle = nativeLoad(path, contextSize, threads)
            check(handle != 0L) { "llama.cpp could not load this GGUF. It may be incompatible or exceed available memory. ULTRON will not silently switch models." }
            loadedPath = path
        }
        nativeGenerate(handle, prompt, maxTokens).also {
            check(it.isNotBlank()) { "The local model returned an empty response." }
        }
    }
}

class LocalModelStore(private val context: Context) {
    fun status(): String = buildString {
        append("Native llama.cpp: ").append(if (NativeLlamaRuntime.isAvailable()) "library loaded" else "library unavailable / build failed").append('\n')
        append("Selected model: ").append(NativeLlamaRuntime.activeModelName(context)).append('\n')
        append("Path: ").append(NativeLlamaRuntime.activeModelPath(context) ?: "none").append('\n')
        append("Offline AI is optional and user-managed. Import any compatible GGUF model after enabling Offline AI. You can replace or delete the imported model at any time.")
    }
}
