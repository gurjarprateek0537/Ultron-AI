package com.ultron.assistant

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Night = Color(0xFF090A0D)
private val Panel = Color(0xFF11141A)
private val Crimson = Color(0xFFFF343D)
private val Orange = Color(0xFFFF9A52)
private val Purple = Color(0xFF9D83D8)

class MainActivity : FragmentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var settingsStore: SettingsStore
    private lateinit var database: UltronDatabase
    private val appLockEnabled = mutableStateOf(false)
    private val appUnlocked = mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsStore = SettingsStore(this)
        database = UltronDatabase.get(this)
        appLockEnabled.value = AppLockStore.isEnabled(this)
        appUnlocked.value = !appLockEnabled.value
        tts = TextToSpeech(this, this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "ultron-chat-cleanup",
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ChatCleanupWorker>(24, TimeUnit.HOURS).build()
        )
        lifecycleScope.launch { runCatching { database.chatDao().deleteOlderThan(System.currentTimeMillis() - 3L * 24 * 60 * 60 * 1000) } }
        setContent {
            if (appLockEnabled.value && !appUnlocked.value) {
                AppLockScreen(onUnlock = { authenticateAppUnlock() })
            } else UltronScreen(
                initialSettings = settingsStore.load(),
                database = database,
                onSaveSettings = { settingsStore.save(it) },
                onSpeak = { if (ttsReady) tts?.speak(it.take(4_000), TextToSpeech.QUEUE_FLUSH, null, "ultron-reply") },
                onAction = { action -> runAction(action) },
                onOpenSpecialSetting = { AndroidAccess.openSpecialSetting(this, it) },
                onSetAppLock = { enabled -> setAppLock(enabled) }
            )
        }
    }

    private fun setAppLock(enabled: Boolean): Boolean {
        if (!enabled) {
            AppLockStore.setEnabled(this, false)
            appLockEnabled.value = false
            appUnlocked.value = true
            return true
        }
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK
        val availability = BiometricManager.from(this).canAuthenticate(authenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) return false
        AppLockStore.setEnabled(this, true)
        appLockEnabled.value = true
        appUnlocked.value = true
        return true
    }

    private fun authenticateAppUnlock() {
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK
        val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ULTRON")
            .setSubtitle("Authenticate to open your private assistant")
            .setAllowedAuthenticators(authenticators)
        if (Build.VERSION.SDK_INT < 30) promptInfoBuilder.setNegativeButtonText("Cancel")
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                appUnlocked.value = true
            }
        })
        runCatching { prompt.authenticate(promptInfoBuilder.build()) }
    }

    override fun onPause() {
        if (appLockEnabled.value) appUnlocked.value = false
        super.onPause()
    }

    private fun runAction(action: String) {
        val intent = when (action) {
            "Browser" -> Intent(this, UltronBrowserActivity::class.java)
            "Settings" -> Intent(Settings.ACTION_SETTINGS)
            "Camera" -> Intent("android.media.action.IMAGE_CAPTURE")
            "Dialer" -> Intent(Intent.ACTION_DIAL)
            "Maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=nearby places"))
            else -> if (action.startsWith("URL:")) Intent(Intent.ACTION_VIEW, Uri.parse(action.removePrefix("URL:"))) else null
        }
        if (intent != null) runCatching { startActivity(intent) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) { tts?.language = Locale.getDefault(); tts?.setPitch(.88f); tts?.setSpeechRate(.94f) }
    }

    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun UltronScreen(
    initialSettings: LlmSettings,
    database: UltronDatabase,
    onSaveSettings: (LlmSettings) -> Unit,
    onSpeak: (String) -> Unit,
    onAction: (String) -> Unit,
    onOpenSpecialSetting: (String) -> Unit,
    onSetAppLock: (Boolean) -> Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(initialSettings) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var voiceReply by remember { mutableStateOf(true) }
    var appLockOn by remember { mutableStateOf(AppLockStore.isEnabled(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf("HOME") }
    var showAccess by remember { mutableStateOf(false) }
    var accessRefresh by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Ready · configure your InstaBox gateway in Settings") }
    val lines = remember { mutableStateListOf(ChatMessage("assistant", "I am ULTRON. Online AI uses the endpoint you configure. Local AI will report clearly until a compatible native model runtime is installed.")) }
    val repository = remember(context) { InferenceRepository(context.applicationContext) }
    val router = remember(database) { UltronCommandRouter(context.applicationContext, database) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }
    val runtimePermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val granted = result.filterValues { it }.keys
        accessRefresh++
        status = if (granted.isNotEmpty()) "Permission result received · ${granted.size} granted" else "No new permissions granted"
    }
    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Importing and extracting text locally…"
                try {
                    val record = DocumentIngestor.import(context, uri)
                    val id = withContext(Dispatchers.IO) { database.documentDao().insert(record.copy(title = PrivateTextVault.encrypt(record.title), extractedText = PrivateTextVault.encrypt(record.extractedText))) }
                    lines.add(ChatMessage("assistant", "Imported ‘${record.title}’ and extracted ${record.extractedText.length} characters locally (document #$id). Ask me a question about it; relevant excerpts are added to the next AI request."))
                    withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(lines.last().content))) }
                    status = "Document imported · on-device OCR/text extraction"
                } catch (e: Exception) {
                    val error = "Document import failed: ${e.message ?: "unsupported file or extraction error"}"
                    lines.add(ChatMessage("assistant", error))
                    status = "Import failed"
                } finally { busy = false }
            }
        }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Copying GGUF model into private storage…"
                try {
                    val file = withContext(Dispatchers.IO) { NativeLlamaRuntime.importModel(context, uri.toString()) }
                    status = "GGUF model imported · ${file.length() / 1_000_000} MB · ready to load on first local prompt"
                    lines.add(ChatMessage("assistant", "Imported local GGUF model: ${NativeLlamaRuntime.activeModelName(context)}. Choose Local LLM and send a prompt to load it. Model loading may fail if the model format or memory requirements are incompatible; ULTRON will report the failure without switching models."))
                } catch (e: Exception) {
                    status = "Model import failed"
                    lines.add(ChatMessage("assistant", "Model import failed: ${e.message ?: "unknown error"}"))
                } finally { busy = false }
            }
        }
    }

    LaunchedEffect(Unit) {
        runCatching {
            val stored = withContext(Dispatchers.IO) { database.chatDao().latest(150).reversed().map { it.copy(content = PrivateTextVault.decrypt(it.content)) } }
            if (stored.isNotEmpty()) {
                lines.clear()
                stored.forEach { lines.add(ChatMessage(it.role, it.content)) }
                status = "Restored ${stored.size} recent chat messages"
            }
        }
    }

    fun send() {
        val prompt = draft.trim()
        if (prompt.isEmpty() || busy) return
        lines.add(ChatMessage("user", prompt))
        draft = ""
        busy = true
        status = "ULTRON is working…"
        scope.launch {
            try {
                withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "user", content = PrivateTextVault.encrypt(prompt))) }
                val localAction = router.handle(prompt)
                val response = if (localAction != null) {
                    status = "On-device command"
                    InferenceResult(localAction, "On-device · ULTRON actions")
                } else {
                    val prepared = router.buildMessages(lines.toList())
                    repository.complete(prepared, settings)
                }
                lines.add(ChatMessage("assistant", response.text))
                withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(response.text))) }
                status = response.provider
                if (voiceReply) onSpeak(response.text)
            } catch (e: Exception) {
                val message = e.message ?: "Unknown inference error"
                val friendly = "ULTRON couldn't complete that request: $message"
                lines.add(ChatMessage("assistant", friendly))
                withContext(Dispatchers.IO) { runCatching { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(friendly))) } }
                status = "Action / inference failed"
            } finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Orange, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16090D), Night, Color(0xFF08090D))))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ULTRON", color = Crimson, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("YOUR AI. YOUR COMMANDS.", color = Orange, fontSize = 9.sp, letterSpacing = 1.8.sp)
                }
                Surface(color = Color(0xFF102116), shape = RoundedCornerShape(30.dp), border = BorderStroke(1.dp, Color(0xFF35C76B).copy(alpha=.65f))) {
                    Row(Modifier.padding(horizontal=10.dp, vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).background(Color(0xFF39E878), RoundedCornerShape(50)))
                        Spacer(Modifier.width(6.dp)); Text(if (busy) "WORKING" else "ONLINE", color=Color(0xFF72E99A), fontSize=9.sp, fontWeight=FontWeight.Bold)
                    }
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Orange) }
            }
            when (activeTab) {
                "HOME" -> DashboardScreen(
                    modifier = Modifier.weight(1f), mode = settings.mode.name, status = status, onChat = { activeTab = "CHAT" },
                    onVoice = { activeTab = "VOICE"; runCatching { speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")) }.onFailure { status = "Speech recognizer unavailable" } },
                    onVision = { onAction("Camera") }, onBrowser = { onAction("Browser") },
                    onMemory = { activeTab = "MEMORY" }, onModels = { showSettings = true },
                    onSecurity = { accessRefresh++; showAccess = true }, onPlugins = { activeTab = "PLUGINS" }
                )
                "CHAT" -> Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text("AI CHAT", color=Crimson, fontSize=16.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                        Text(settings.mode.name, color=Orange, fontSize=10.sp)
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(lines) { line ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.role == "user") Arrangement.End else Arrangement.Start) {
                                Surface(color = if (line.role == "user") Color(0xFF48141B) else Color(0xFF15151B), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, if (line.role == "user") Crimson.copy(alpha=.85f) else Color(0xFF513039)), modifier = Modifier.widthIn(max = 380.dp)) {
                                    Text(line.content, Modifier.padding(14.dp), color=Color(0xFFF5F0F2), fontSize=14.sp, lineHeight=20.sp)
                                }
                            }
                        }
                        if (busy) item { Text("ULTRON IS THINKING…", color=Orange, fontSize=11.sp) }
                    }
                    Row(Modifier.fillMaxWidth().background(Color(0xFF171219), RoundedCornerShape(28.dp)).padding(horizontal=5.dp, vertical=5.dp), verticalAlignment=Alignment.CenterVertically) {
                        IconButton(onClick = { runCatching { speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")) }.onFailure { status="Speech recognizer unavailable" } }) { Icon(Icons.Default.Mic, "Voice input", tint=Crimson) }
                        Box(Modifier.weight(1f).padding(horizontal=8.dp)) { if (draft.isEmpty()) Text("Message ULTRON…", color=Color.Gray, fontSize=13.sp); BasicTextField(draft, { draft=it }, Modifier.fillMaxWidth(), textStyle=androidx.compose.ui.text.TextStyle(color=Color.White,fontSize=14.sp), maxLines=5) }
                        IconButton(onClick={send()}, enabled=!busy) { Icon(Icons.Default.Send, "Send", tint=Orange) }
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("Voice replies", color=Color.LightGray, fontSize=10.sp); Switch(checked=voiceReply,onCheckedChange={voiceReply=it}); Spacer(Modifier.weight(1f)); Text("3-day chat history", color=Purple,fontSize=9.sp) }
                }
                "VOICE" -> VoiceFeatureScreen(modifier=Modifier.weight(1f), onStart={
                    if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) runtimePermissions.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                    else runCatching { val wake=Intent(context,UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START); if(Build.VERSION.SDK_INT>=26) context.startForegroundService(wake) else context.startService(wake); status="Wake-word service requested" }.onFailure { status="Wake-word start failed: ${it.message}" }
                }, onStop={ context.stopService(Intent(context,UltronWakeWordService::class.java)); status="Wake-word service stopped" }, onSpeak={ activeTab="CHAT" })
                "PLUGINS" -> SimpleFeatureScreen(Modifier.weight(1f), "PLUGINS", "EXTEND ULTRON", listOf("YouTube search · open video search results", "Web browser · browse pages", "Wikipedia · information lookup", "Weather · current conditions", "Calculator · on-device calculations", "Translator · language assistance"), "Plugin availability depends on the corresponding command implementation and network access.")
                "MEMORY" -> SimpleFeatureScreen(Modifier.weight(1f), "MEMORY", "PRIVATE KNOWLEDGE", listOf("Conversation history · automatically clears after 3 days", "Imported documents · encrypted local storage", "Private text vault · encrypted content"), "Persistent document knowledge is separate from the short chat history.")
                else -> SimpleFeatureScreen(Modifier.weight(1f), activeTab, "ULTRON SYSTEM MODULE", listOf("InstaBox online AI configuration", "Optional offline GGUF model", "Permissions and device access", "Biometric app lock"), status)
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF100D12)).padding(horizontal=5.dp, vertical=7.dp), horizontalArrangement=Arrangement.SpaceEvenly, verticalAlignment=Alignment.CenterVertically) {
                BottomNavItem(Icons.Default.Home, "HOME", activeTab=="HOME") { activeTab="HOME" }
                BottomNavItem(Icons.Default.Chat, "CHAT", activeTab=="CHAT") { activeTab="CHAT" }
                BottomNavItem(Icons.Default.Mic, "VOICE", activeTab=="VOICE") { activeTab="VOICE" }
                BottomNavItem(Icons.Default.GridView, "MODULES", activeTab=="PLUGINS") { activeTab="PLUGINS" }
                BottomNavItem(Icons.Default.Settings, "SETTINGS", false) { showSettings=true }
            }
        }

        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("ULTRON · Inference settings", color = Crimson) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose AI provider", color = Orange, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = settings.mode == InferenceMode.LOCAL, onClick = { settings = settings.copy(mode = InferenceMode.LOCAL) })
                        Text("Local LLM", color = Color.White)
                        Spacer(Modifier.width(8.dp))
                        RadioButton(selected = settings.mode == InferenceMode.ONLINE, onClick = { settings = settings.copy(mode = InferenceMode.ONLINE) })
                        Text("Online LLM", color = Color.White)
                    }
                    OutlinedTextField(value = settings.baseUrl, onValueChange = { settings = settings.copy(baseUrl = it) }, label = { Text("InstaBox gateway URL (e.g. https://host/v1)") }, singleLine = true)
                    OutlinedTextField(value = settings.model, onValueChange = { settings = settings.copy(model = it) }, label = { Text("Model ID") }, singleLine = true)
                    OutlinedTextField(value = settings.apiKey, onValueChange = { settings = settings.copy(apiKey = it) }, label = { Text("API token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                    Text("Expected route: POST {base URL}/chat/completions. Enter your InstaBox /v1 URL, exact model path/name and gateway API key. Temporary 502/503/504 responses are retried up to 3 times. API tokens are encrypted with Android Keystore.", color = Color.LightGray, fontSize = 11.sp)
                    if (settings.mode == InferenceMode.LOCAL) {
                        Text("OPTIONAL OFFLINE MODEL", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Qwen3.5-4B-Amadeus Q4_K is the suggested model. You may choose another compatible GGUF. There are no RAM-based tiers or automatic model substitutions.", color = Color.LightGray, fontSize = 11.sp)
                        TextButton(onClick = { onAction("URL:https://huggingface.co/models?search=Qwen3.5-4B-Amadeus-GGUF"); status = "Opened the Qwen GGUF model search. Choose a compatible GGUF file to download, then import it below." }) { Text("Find Qwen GGUF download", color = Orange) }
                        Text(LocalModelStore(context).status(), color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                        Button(onClick = { modelPicker.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Import / replace GGUF model") }
                        TextButton(onClick = {
                            NativeLlamaRuntime.deleteModel(context)
                            status = "Offline model deleted from ULTRON private storage. Online AI remains available."
                        }) { Text("Delete imported offline model", color = Crimson) }
                        Text("The imported model is optional. Online AI remains the default. Select Local LLM only after importing a compatible GGUF. The Qwen link opens the model search page; verify the exact file, license and compatibility before downloading.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                    }
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Biometric / device-credential app lock", color = Color.White)
                            Text("Locks ULTRON when it leaves the foreground. Android 11+ can use strong biometrics or your device credential; older Android versions require enrolled biometrics.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                        }
                        Switch(checked = appLockOn, onCheckedChange = { requested ->
                            if (onSetAppLock(requested)) appLockOn = requested
                            else status = "App lock not changed: set up a supported biometric/device credential in Android settings first."
                        })
                    }
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Text("VOICE WAKE WORD", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Optional, visible foreground listener. Uses Android on-device recognition only when the device supports it; microphone stays active until stopped.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                runtimePermissions.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                                status = "Grant microphone permission, then tap Start wake word again"
                            } else {
                                runCatching {
                                    val wake = Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START)
                                    if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(wake) else context.startService(wake)
                                    status = "Wake-word listener requested · check its ongoing notification"
                                }.onFailure { status = "Could not start wake-word listener: ${it.message}" }
                            }
                        }, modifier = Modifier.weight(1f)) { Text("Start listening", fontSize = 11.sp) }
                        OutlinedButton(onClick = {
                            context.stopService(Intent(context, UltronWakeWordService::class.java))
                            context.startService(Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_STOP))
                            status = "Wake-word stop requested"
                        }, modifier = Modifier.weight(1f)) { Text("Stop", fontSize = 11.sp) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Speak replies", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = voiceReply, onCheckedChange = { voiceReply = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    settings = settings.copy(baseUrl = settings.baseUrl.trim().trimEnd('/'), model = settings.model.trim())
                    runCatching { onSaveSettings(settings) }
                        .onSuccess { status = "Saved ${settings.mode} settings"; showSettings = false }
                        .onFailure { status = "Could not securely save token: ${it.message}" }
                }) { Text("Save settings") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } },
            containerColor = Panel
        )

        if (showAccess) {
            val itemsNow = remember(accessRefresh, context) { AndroidAccess.items(context) }
            androidx.compose.ui.window.Dialog(onDismissRequest = { showAccess = false }) {
                Surface(modifier = Modifier.fillMaxWidth().heightIn(max = 660.dp), color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .5f))) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ULTRON · Permission center", color = Crimson, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Enable only the access you want to use.", color = Color.LightGray, fontSize = 11.sp)
                            }
                            IconButton(onClick = { accessRefresh++ }) { Icon(Icons.Default.Refresh, "Refresh permission statuses", tint = Orange) }
                        }
                        HorizontalDivider(color = Crimson.copy(alpha = .35f))
                        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(itemsNow) { item ->
                                Surface(color = Color(0xFF171B22), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text(item.description, color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                                            Text(if (item.granted) "ENABLED" else "NOT ENABLED", color = if (item.granted) Color(0xFF9AD6A5) else Orange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                        if (item.action.startsWith("runtime:")) {
                                            TextButton(onClick = {
                                                val permission = item.action.removePrefix("runtime:")
                                                if (item.granted) onOpenSpecialSetting("app_permissions")
                                                else if (permission == android.Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33) {
                                                    status = "Notification runtime permission is not required on this Android version"
                                                } else runtimePermissions.launch(arrayOf(permission))
                                            }) { Text(if (item.granted) "Review" else "Grant", color = Orange) }
                                        } else TextButton(onClick = { onOpenSpecialSetting(item.action.removePrefix("settings:")); accessRefresh++ }) { Text(if (item.granted) "Open" else "Enable", color = Orange) }
                                    }
                                }
                            }
                        }
                        Text("Accessibility and notification access are powerful. ULTRON reads screen text only when you command it and does not save notification message contents. Device admin does not provide root access.", color = Purple, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 8.dp))
                        TextButton(onClick = { accessRefresh++; showAccess = false }) { Text("Done", color = Crimson) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardScreen(modifier: Modifier = Modifier, mode: String, status: String, onChat:()->Unit, onVoice:()->Unit, onVision:()->Unit, onBrowser:()->Unit, onMemory:()->Unit, onModels:()->Unit, onSecurity:()->Unit, onPlugins:()->Unit) {
    LazyColumn(modifier.fillMaxWidth(), contentPadding=PaddingValues(start=14.dp,end=14.dp,bottom=12.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Surface(color=Color(0xFF130D12), shape=RoundedCornerShape(22.dp), border=BorderStroke(1.dp,Crimson.copy(alpha=.85f)), modifier=Modifier.fillMaxWidth()) {
                Box(Modifier.height(250.dp)) {
                    Image(painterResource(R.drawable.ultron_hero), contentDescription="ULTRON metallic red-eyed avatar", modifier=Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE08090D)))))
                    Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                        Text("SYSTEM STATUS  ·  $mode AI", color=Orange, fontSize=9.sp, letterSpacing=1.4.sp, fontWeight=FontWeight.Bold)
                        Text("I AM ULTRON", color=Color.White, fontSize=25.sp, fontWeight=FontWeight.Black, letterSpacing=1.5.sp)
                        Text(status.take(90), color=Color(0xFFD9C9CC), fontSize=10.sp, maxLines=2)
                        Spacer(Modifier.height(8.dp))
                        NeonAction("START CONVERSATION", Icons.Default.Chat, onChat, Modifier.fillMaxWidth())
                    }
                }
            }
        }
        item { Text("COMMAND CENTER", color=Crimson, fontSize=12.sp, fontWeight=FontWeight.ExtraBold, letterSpacing=2.sp) }
        item {
            Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("VOICE", "Wake word & commands", Icons.Default.Mic, Modifier.weight(1f), onVoice)
                    DashboardTile("VISION", "Camera & image input", Icons.Default.Visibility, Modifier.weight(1f), onVision)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("BROWSER", "Search & browse", Icons.Default.Language, Modifier.weight(1f), onBrowser)
                    DashboardTile("MEMORY", "Recall & documents", Icons.Default.Psychology, Modifier.weight(1f), onMemory)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("MODEL MANAGER", "Online / optional GGUF", Icons.Default.Memory, Modifier.weight(1f), onModels)
                    DashboardTile("SECURITY", "Permissions & app lock", Icons.Default.Security, Modifier.weight(1f), onSecurity)
                }
            }
        }
        item { NeonAction("EXPLORE PLUGINS", Icons.Default.Extension, onPlugins, Modifier.fillMaxWidth()) }
        item { Text("ULTRON · YOUR AI. YOUR COMMANDS.", color=Purple, fontSize=9.sp, letterSpacing=1.2.sp, modifier=Modifier.fillMaxWidth().padding(vertical=5.dp)) }
    }
}

@Composable
private fun DashboardTile(title:String, subtitle:String, icon:androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier=Modifier, onClick:()->Unit) {
    Surface(modifier=modifier.height(104.dp).clickable(onClick=onClick), color=Color(0xFF151117), shape=RoundedCornerShape(15.dp), border=BorderStroke(1.dp,Crimson.copy(alpha=.58f))) {
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement=Arrangement.SpaceBetween) {
            Icon(icon, contentDescription=null, tint=if(title=="MEMORY") Purple else Crimson, modifier=Modifier.size(25.dp))
            Column { Text(title,color=Color.White,fontSize=11.sp,fontWeight=FontWeight.ExtraBold,letterSpacing=.7.sp); Text(subtitle,color=Color.LightGray,fontSize=9.sp,maxLines=1) }
        }
    }
}

@Composable
private fun NeonAction(label:String, icon:androidx.compose.ui.graphics.vector.ImageVector, onClick:()->Unit, modifier:Modifier=Modifier) {
    Surface(modifier=modifier.height(46.dp).clickable(onClick=onClick), color=Color(0xFF351016), shape=RoundedCornerShape(13.dp), border=BorderStroke(1.dp,Crimson)) {
        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.Center) { Icon(icon,contentDescription=null,tint=Orange); Spacer(Modifier.width(9.dp)); Text(label,color=Color.White,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp) }
    }
}

@Composable
private fun VoiceFeatureScreen(modifier:Modifier=Modifier,onStart:()->Unit,onStop:()->Unit,onSpeak:()->Unit) {
    Column(modifier.fillMaxWidth().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Box(Modifier.size(220.dp).background(Brush.radialGradient(listOf(Color(0x884A1018),Color(0x22310B13),Color.Transparent)),RoundedCornerShape(120.dp)),contentAlignment=Alignment.Center) {
            Text("◉",color=Crimson,fontSize=112.sp,fontWeight=FontWeight.Black)
        }
        Text("VOICE COMMAND",color=Crimson,fontSize=20.sp,fontWeight=FontWeight.ExtraBold,letterSpacing=2.sp)
        Text("Wake word: ULTRON",color=Orange,fontSize=12.sp)
        Spacer(Modifier.height(24.dp)); NeonAction("START WAKE-WORD SERVICE",Icons.Default.Mic,onStart,Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp)); NeonAction("STOP LISTENING",Icons.Default.Stop,onStop,Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp)); Text("Background listening requires microphone permission and an ongoing Android foreground-service notification. Device power policies may still restrict it.",color=Color.LightGray,fontSize=10.sp)
    }
}

@Composable
private fun SimpleFeatureScreen(modifier:Modifier=Modifier,title:String, subtitle:String, items:List<String>, note:String) {
    Column(modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(title,color=Crimson,fontSize=20.sp,fontWeight=FontWeight.Black,letterSpacing=1.5.sp); Text(subtitle,color=Orange,fontSize=10.sp)
        items.forEach { item -> Surface(color=Color(0xFF151117),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Crimson.copy(alpha=.45f)),modifier=Modifier.fillMaxWidth()) { Text(item,color=Color.White,fontSize=12.sp,modifier=Modifier.padding(14.dp)) } }
        Text(note,color=Purple,fontSize=10.sp,lineHeight=15.sp)
    }
}

@Composable
private fun BottomNavItem(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,selected:Boolean,onClick:()->Unit) {
    Column(Modifier.clickable(onClick=onClick).padding(horizontal=7.dp,vertical=3.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(icon,contentDescription=label,tint=if(selected) Crimson else Color(0xFFAAA3AD),modifier=Modifier.size(21.dp))
        Text(label,color=if(selected) Orange else Color(0xFFAAA3AD),fontSize=8.sp,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun AppLockScreen(onUnlock: () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Orange, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF24080D), Night))), contentAlignment = Alignment.Center) {
            Surface(color = Panel, shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .7f)), modifier = Modifier.padding(24.dp)) {
                Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("◉", color = Crimson, fontSize = 54.sp, fontWeight = FontWeight.Black)
                    Text("ULTRON LOCKED", color = Crimson, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Authenticate to access your assistant and locally stored private data.", color = Color.LightGray, fontSize = 13.sp)
                    Button(onClick = onUnlock, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Fingerprint, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Unlock ULTRON") }
                }
            }
        }
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean = false, onClick: (() -> Unit)? = null) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = { onClick?.invoke() }) { Icon(icon, contentDescription = label, tint = if (active) Crimson else Color(0xFFB7B5C0), modifier = Modifier.size(22.dp)) }
        Text(label, color = Color(0xFFB7B5C0), fontSize = 8.sp)
    }
}
