# Building ULTRON 1.4.1

## Toolchain

- JDK 17
- Gradle 8.9 (the source ZIP intentionally does not bundle a Gradle wrapper)
- Android SDK Platform 35 and Build Tools 35.0.0
- Android NDK 27.2.12479018
- CMake 3.22.1

## Build and test

Open the extracted source root in Android Studio, or use a compatible Gradle installation:

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

The expected debug APK is `app/build/outputs/apk/debug/app-debug.apk`. The GitHub Actions workflow at `.github/workflows/android.yml` installs the Android toolchain, runs JVM unit tests, builds the debug APK and uploads it as an artifact.

## Device test checklist

1. Install on the actual OPPO CPH1803 / Android 8.1 device.
2. Grant microphone permission; explicitly start the wake service and verify the Voice screen reports provider readiness and audio-level callbacks over time.
3. Enable ULTRON Accessibility; open several apps and test fresh screen snapshots, click/search/type/submit/scroll, page changes, recovery, pause, resume and stop.
4. Start Screen Awareness and approve MediaProjection; test local OCR, `wait_for_text` and the OCR `click_text` fallback on content not exposed by Accessibility, including a check that ambiguous text never triggers a tap.
5. Test wake activation after screen off/on, app closure, provider errors and reboot; configure ColorOS Auto-launch/battery policy if the OS restricts ULTRON.
6. Verify that send/call/payment/purchase/delete/publish/security commitments require approval for the exact operation.
7. Verify that sensitive fields are never auto-filled and secure screens are not bypassed.

## Compatibility boundaries

- minSdk 26 (Android 8.0+); targetSdk 35.
- Android and ColorOS may restrict Accessibility, background activity starts, screen capture, microphone services, notifications, exact alarms and scheduled work. WorkManager is best-effort and not an exact-time scheduler.
- SpeechRecognizer behavior is provider-specific. This build does not include a dedicated offline acoustic wake-word model; no zero-miss or zero-false-trigger guarantee is made.
- No APK, emulator run or physical-device test is represented as completed by this source archive.
