# ULTRON 0.9.8 — Semantic Screen Intelligence

## Central automation engine upgrades
- Added a compact semantic accessibility snapshot for the active app window. It includes package, screen-generation counter, display dimensions/density, visible text and descriptions, hints, resource IDs, node classes, bounds, clickable/focusable/editable/scrollable/checkable/selected state, and child counts.
- Included unlabeled interactive and image nodes so icon-only navigation (for example, an inbox tab without a text label) can be reasoned about by the planner.
- Updated the LLM planning instructions to use semantic controls and current bounds, navigate icon-only controls, search exact names/usernames, disambiguate candidate people, and avoid guessing identity from avatars.
- Coordinate guidance now requires converting current-snapshot pixel bounds using the reported display size and forbids reusing coordinates after screen-generation changes.
- The executor's screen fingerprint now includes semantic UI structure and generation metadata, improving detection of same-app page changes that plain text comparison can miss.
- `read_screen` now returns a fresh semantic screen snapshot instead of only a plain text dump.
- Reduced the prescribed initial app-search waits while retaining post-navigation inspection and verification.

## Preserved behavior
- Existing UI, visual assets, AI modes, local/online inference, wake-word service, safety approvals, device controls, memory, notifications, plugins, file and routine foundations, and existing tests remain in the source tree.
- Sensitive actions remain approval-gated; ordinary navigation and drafting remain ungated.

## Platform limitations
- Accessibility cannot reveal content deliberately hidden by an app or secure window.
- Android's Accessibility screenshot API is only available on Android 11+; the Android 8.1 target device cannot use that API for screen OCR/vision. On that device ULTRON uses the semantic accessibility tree and may need user input when a screen exposes no useful labels or controls.
- This source update has not been compiled or exercised on a physical device in this environment.
