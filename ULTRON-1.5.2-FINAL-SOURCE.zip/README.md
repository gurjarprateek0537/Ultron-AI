# ULTRON 1.5.2 — Agent Collaboration and Voice/Account Upgrade

Current source release: **1.5.2** (versionCode 32, minSdk 26 / Android 8.0+). This source builds on the supplied 1.5.1 archive. Highlights: actual bounded role-specific inference workers in ordered multi-agent phases; all 28 specialist roles routable across relevant tasks; improved SpeechRecognizer alternative/partial handling; an experimental encrypted voice-familiarity profile (not authentication); Google Drive, Google Calendar and GitHub OAuth/API presets; clearer endpoint connection testing; bundled-only animated core GIF across Voice/Dashboard/full-screen startup; no custom GIF upload control; and retained chat attachments.

Important boundaries: 28 logical roles share the configured General/Vision/Coding model profiles; relevant subsets are executed per request, not all 28 on every task and not 28 separate model deployments. Specialist workers produce findings only; one central planner and one validated Android executor retain action authority. Android secure lock-screen bypass and covert remote camera/microphone recording are not implemented. SpeechRecognizer is still not a dedicated acoustic hotword engine. Provider presets need the owner's OAuth app registration, redirect URI and scopes; one saved integration currently represents one API endpoint/action. See `CHANGELOG_1.5.2.md`, `ULTRON_1.5.2_IMPLEMENTATION_AUDIT.md`, `BUILDING_1.5.2.md` and `IMPLEMENTATION_STATUS.md`.

**Verification boundary:** limited pure-Kotlin smoke tests for wake phrase selection, 28-role selection/phase assignment, and multi-agent runtime orchestration passed; provider preset Kotlin compilation and Android XML parsing passed. A full Android Gradle/JUnit/NDK build, APK assembly, live gateway test, OAuth provider test, and OPPO CPH1803 device test were not run in this environment. This is a source archive, not a built APK.

---



## 1.4.1 build-fix update

Version 1.4.1 addresses two errors found in GitHub Actions: run #31 reported a Kotlin generic type-inference failure in `UltronIntelligenceStore.feedbackSnapshot()`, and run #32 could not resolve the KSP plugin marker. The source now supplies the missing `UltronActionFeedback` type and Room code generation uses Kotlin KAPT 2.0.21. The full Android build still must be rerun on GitHub Actions; this authoring environment has no Android SDK or Gradle installation. See `BUILD_FIX_1.4.1.md`, `CHANGELOG_1.4.1.md`, `BUILDING_1.4.1.md` and `FINAL_DELIVERY_AUDIT_1.4.1.md`. The repository-level wrapper workflow still expects the old archive filename; follow `GITHUB_ACTIONS_1.4.1.md` when uploading this new ZIP.

## 1.4.0 update

Version 1.4.0 builds on the 1.3.0 routine/document-retrieval source and hardens the two highest-priority runtime paths: Accessibility screen-state identity/transition verification and the SpeechRecognizer wake-service lifecycle. It ignores volatile Accessibility event/IME metadata during fingerprint comparison, adds bounded OCR fallbacks for `wait_for_text` and unambiguous `click_text` targets, rejects equally ranked duplicate controls, redacts likely private screen labels and blocks automatic entry into password/OTP/payment fields. Wake recognition now has truthful provider-health diagnostics, recognizer-instance generation guards and bounded watchdog recovery/backoff. See `CHANGELOG_1.4.0.md`, `IMPLEMENTATION_STATUS.md` and `BUILDING_1.4.0.md`. This remains a source archive; the Android build and OPPO device test are not verified in this environment.
# ULTRON 1.4.1 — Build Resolution Fix

Current source release: **1.4.1** (versionCode 29, minSdk 26 / Android 8.0+). This project is based on the supplied `ULTRON-1.1.0-MULTI-AGENT-FINAL-SOURCE.zip`; its existing UI, media assets, native llama.cpp bridge, model profiles, voice, accessibility service, memory, browser, plugins, device controls, and other source modules are retained.

The 1.2.0 upgrade adds a hybrid UI world model, transition prediction and observation scoring, verified-outcome feedback memory, encrypted persistent task checkpoints, safe-boundary pause/resume/stop, resume-by-replanning from a fresh screen, a preflight action simulator, a permission/capability registry, local app/screen knowledge links, battery/network-aware resource budgets, structured function contracts, MCP/A2A protocol data contracts, and privacy-limited diagnostics. It also removes an unused legacy multi-agent class/role enum whose names conflicted with the expanded 1.1 central coordinator.

Important boundaries: the 28 specialists are logical roles sharing the configured General/Vision/Coding profiles, not 28 separate model instances. MCP and A2A are typed integration foundations without attached external transports/agents. Feedback scoring is not live reinforcement learning. The action dry-run never executes actions, and world-state predictions are heuristic priors checked against accessibility-screen observations, not a full simulator of Android or remote app backends. See [CHANGELOG_1.2.0.md](CHANGELOG_1.2.0.md), [BUILDING_1.2.0.md](BUILDING_1.2.0.md), [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md), and [MULTI_AGENT_1.1.0.md](MULTI_AGENT_1.1.0.md). This is a source ZIP, not a prebuilt APK.

---

## ULTRON 0.8.0 update

This source includes improved compound app-search routing, semantic AccessibilityService targeting, focused-only text entry, foreground-app verification and one bounded safe recovery attempt for navigation/search failures. It also includes Online, Local and Hybrid inference modes; Hybrid tries the selected online endpoint, same-role online profile failover, then a configured local text GGUF model. Local GGUF inference uses the model's declared chat template with conservative context budgeting. See `CHANGELOG_0.8.0.md`, `ULTRON_0.8.0_AUDIT.md` and `BUILDING_0.8.0.md`.

Important: Android app UI automation is not universal. Accessibility control must be explicitly enabled, some app controls are not exposed semantically, and background activity launch may be blocked by Android/OEM restrictions. ULTRON will stop instead of typing into an ambiguous field. A complete Gradle/NDK build and physical-device test are still required.

# ULTRON 0.8.0 — Android AI Assistant Source

ULTRON is a personal Android assistant combining an OpenAI-compatible AI client, optional local GGUF inference, an accessibility-based action executor, background voice command processing, memory, camera image analysis, a built-in browser, and user-configurable website/API integrations.

## 0.8.0 upgrade notes

- Compound search commands for YouTube, Chrome, Google, Google Maps/Maps, Play Store, Gmail and Spotify run a deterministic open → wait → semantic search → inspect flow. English, common Hinglish and selected Hindi-script forms are parsed locally. The app-scoped results-link fallback remains YouTube-only.
- The AI agent planner now explicitly plans complete search workflows: open app, verify the foreground window, wait, inspect visible controls, focus a semantic search field, enter the exact query, submit, wait and inspect results. Added a `submit_search` action using the focused Android input's IME action or clearly labelled Search controls; it will not tap generic Submit/Go buttons.
- Added parser unit tests for YouTube and common-app compound searches, quoted queries, Hinglish/Hindi forms, wake-word normalization and unsupported-app rejection.
- Creator identity questions return the supplied creator name, Prateek Gurjar, with only project skills supported by the provided project context; no unverified awards or qualifications are claimed.
- Existing online/local inference modes, endpoint profiles, local GGUF model support, vision endpoint path, memory, plugins, browser, voice, and safety confirmations are retained.
- Version is now 0.8.0 (versionCode 14).

## What's in this release

- **AI-driven action plans:** the selected online AI profile can convert English, Hindi, or Hinglish phone requests into a bounded JSON plan of up to 24 allow-listed actions. ULTRON validates the plan and never executes model-generated scripts or code.
- **Phone actions:** launch installed apps, click visible labels, enter text in exposed editable controls, scroll, swipe, tap normalized coordinates, read visible screen text, navigate Back/Home, open HTTPS URLs, compose WhatsApp/SMS messages, place a call after confirmation, and invoke saved plugins.
- **Background command processing:** wake-word commands are encrypted in app-private storage and placed into a serial WorkManager queue using opaque IDs. The worker plans and executes without opening the ULTRON activity, then posts a result notification and uses the chosen installed Android TTS voice. Background app launches can still be blocked by Android/OEM policy.
- **Safety gate:** message sending, calls, coordinate taps, risky button labels and REST/OAuth API operations require a separate YES/NO approval. Pending approvals are encrypted, expire after 10 minutes, and appear in a notification. Actions are recorded in an encrypted local audit history. A report distinguishes accepted operations from those whose effect was independently observed.
- **Contact workflows:** WhatsApp and SMS use Contacts permission when a number is not supplied. Ambiguous contact matches fail closed. WhatsApp may open a prefilled conversation and activate a visible Send control only after approval; delivery/read status is not available to ULTRON.
- **Vision:** the user launches Android's camera capture flow. ULTRON downsamples the captured photo and sends it as an OpenAI-compatible `image_url` payload to an enabled Vision profile (or the default online model if configured). The chosen endpoint must accept multimodal image input.
- **Plugins:** add HTTPS website shortcuts and REST API integrations from Plugin Armory. REST integrations support GET/POST/PUT/PATCH/DELETE, no auth, Bearer, API-key header/query and Basic auth. OAuth 2.0 Authorization Code + PKCE is available with encrypted credentials/tokens and refresh where the provider returns a compatible refresh token.
- **Hindi/English speech:** choose English (India), English (US) or Hindi (India), plus male/female preference. ULTRON selects the closest matching voice from the Android TTS engine and provides the engine's voice-data installer. Voice binaries are not redistributed in this source.
- **Memory and UI:** persistent Room memory, notes and imported documents; searchable memory screen with item deletion and agent action history; cinematic crimson/charcoal dashboard and a distinct 32-frame 360×360 animated ULTRON voice GIF.
- **Smart context and chat archive:** explicit `max_tokens` output cap, adjustable General AI app-side context budget, oldest-turn trimming, automatic conversation rollover, encrypted three-day archives, New Chat control and relevance-based retrieval of earlier discussions.
- **Connection diagnostics and fast local actions:** Settings includes a General AI connection test from the Android device. Wake-word prefixes are normalized; time/date/battery, simple app launches, YouTube searches and basic web searches are routed locally before the LLM, so these safe actions remain available during a temporary gateway outage.
- **Optional local AI:** the existing GGUF model vault and native llama.cpp bridge remain separate from online AI. Image input is not supported by the local text runtime.

## Configure online AI

For the live screen workflow, create an image-capable profile with role `vision` and a planning profile with role `general`; add a role `coding` profile for coding conversations. The user must start Screen Awareness and approve Android's system capture prompt. The setting **Share live screen frames with Vision AI** is off by default and is an independent privacy choice. When enabled, a recent JPEG frame is sent only to the Vision-role endpoint; the Vision description and current accessibility metadata are then provided to General for that planning pass. Captures are cached briefly in memory and are not inserted into chat history or saved to shared storage. Disable the sharing switch to keep live screen details out of cloud planning requests.

In ULTRON Settings, choose Online mode and enter the InstaBox OpenAI-compatible gateway's base URL (normally ending `/v1`), the exact model ID/path and the gateway API key. ULTRON calls `POST {baseUrl}/chat/completions`. The app retries selected transient 502–504 responses, but a down gateway/upstream still needs to be fixed at the host.

Add named AI profiles for separate roles such as General, Coding and Vision. The dashboard's selected profile is used by the task planner. Use **Settings → Test General AI Connection** to send a small probe from the phone itself; this separates an Android-to-gateway problem from a chat/agent-prompt problem. The General AI context budget defaults to 4096 tokens and reply cap to 256 tokens. These are app-side request controls; if you choose 8192, 16384 or another larger context, configure the InstaBox model server with `n_ctx` at least that large and confirm it is supported by available RAM. A Vision profile must accept OpenAI-style multimodal `image_url` message content.

## Configure Android access

1. Grant microphone permission and start the foreground wake-word listener from Voice settings.
2. Enable ULTRON Accessibility in Android Accessibility settings for screen actions.
3. Grant Contacts permission for name-to-number resolution.
4. Allow notifications so execution results and YES/NO requests are visible.
5. Exempt ULTRON from battery optimization only if you understand the battery trade-off and your device otherwise kills the listener.

Say “ULTRON” followed by a command, or say the wake word and wait for the follow-up capture. You can answer a pending confirmation with “ULTRON yes” or “ULTRON no”, or use the notification buttons. The service uses Android `SpeechRecognizer`, not a dedicated offline acoustic wake-word detector.

## Plugin setup

Open Modules → Plugin Armory. Website shortcuts use HTTPS URL templates with `{query}`. API integrations need the API name, HTTPS resource endpoint, method, authentication type, credentials and optional JSON body template. Use `run plugin <name> with <request>` in chat/voice.

For OAuth, enter the provider authorization URL, token URL, client ID/secret (if required), scopes and exact registered redirect URI. The default callback is `ultron://oauth/callback`. The implementation is generic OAuth 2.0 Authorization Code + PKCE; providers that require additional parameters, client authentication methods, app-link verification or server-side confidential clients may need provider-specific support. Register the exact redirect URI with the provider and use only the minimum scopes required.

## Android compatibility and build

- `minSdk`: 26 (Android 8.0)
- `compileSdk` / `targetSdk`: 35
- Java/Kotlin target: 17
- Native ABI filters: `arm64-v8a`, `armeabi-v7a`, `x86_64`
- CMake: 3.22.1; Android NDK: 27.2.12479018
- GitHub Actions workflow: `.github/workflows/android.yml`

The workflow installs JDK 17, Gradle 8.9, Android SDK 35, NDK 27.2.12479018 and CMake 3.22.1; runs `:app:testDebugUnitTest`; builds `:app:assembleDebug`; and uploads the installable debug APK with its SHA-256 checksum. Push the project root to the `main` or `master` branch, or run **Actions → ULTRON Android CI → Run workflow**.

## Important behavior limits

- This is not root access or unrestricted device control. Android system UI, lock screens, secure/password fields, protected apps, inaccessible custom views and OEM-specific interfaces may block accessibility reading or gestures.
- Android 8–16 is the target range, not proof of uniform compatibility. Android 14+ microphone foreground-service rules, background activity launch restrictions, speech-recognizer availability and OEM battery policies require physical-device tests. Continuous wake-word performance and false-trigger rate are not guaranteed.
- WorkManager survives normal activity closure but is scheduled work, not a real-time daemon. The microphone listener itself remains an explicit foreground service and is subject to OS/OEM restrictions.
- The planner is an instruction model, not deterministic automation. ULTRON bounds and checks its proposed actions, but a complex request can still be misunderstood. Review the full confirmation notification before approving it.
- UI verification is best-effort: ULTRON can observe visible text/package changes, but it cannot prove every server-side action, message delivery, payment, or app-internal state.
- WhatsApp/SMS workflows depend on contact data and exposed app controls. WhatsApp send may be activated only after YES if its UI exposes the Send control. ULTRON cannot verify delivery or read receipts. Other messaging apps use general accessibility actions and are not guaranteed.
- Camera analysis is an explicit foreground capture, not live video, continuous monitoring or silent background capture. It requires a compatible online multimodal model.
- Generic OAuth does not automatically fit every provider. Provider-specific setup or code may be needed. API credentials are encrypted at rest, but they are still sent to the URLs you configure; only connect services you trust.
- Male/female Hindi/English voice options depend on the Android speech engine's installed voices and metadata. ULTRON does not bundle third-party voice binaries.
- The source archive is **not a compiled or signed APK**. No Android SDK, Gradle or NDK toolchain is available in the authoring workspace, so the build and hardware tests have not been run here. Treat the APK as build-verified only after the included GitHub Actions workflow succeeds.

See `CHANGELOG_0.9.1.md`, `FINAL_DELIVERY_AUDIT.md`, `IMPLEMENTATION_STATUS.md`, and the historical 0.4–0.8 changelogs for implementation details and test boundaries.


## Build and device verification

This archive is source code, not a prebuilt APK. The authoring environment used for this upgrade does not have a verified Android SDK/Gradle build result. Run the repository's CI workflow or build on an Android SDK machine before installing. Accessibility-driven app workflows depend on the target app exposing searchable UI nodes and on Android/OEM background-launch rules; no assistant can guarantee identical behavior across every YouTube version/device.

## 0.9.4 reliability update

See [ULTRON 0.9.4 upgrade notes](ULTRON_0.9.4_UPGRADE_NOTES.md) and [build instructions](BUILDING_0.9.4.md) for the wake-word partial-result fix, concise speech summaries, sensitive-only confirmations, draft-before-send messaging, chat/voice YES-NO handling, volume readback and screen wake support. Build and physical-device verification are still required before claiming runtime reliability.


## 0.9.5 advanced capability foundations

See [CHANGELOG_0.9.5.md](CHANGELOG_0.9.5.md), [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md), and [BUILDING_0.9.5.md](BUILDING_0.9.5.md). This revision adds a capability dashboard, opt-in notification reading, safe clipboard preview, network diagnostics, SAF folder browsing, routine-definition storage, local OCR helper, skill registry, specialist-agent contract, and an app-private project workspace. These are documented as foundations/partial implementations where full scheduling, marketplace, local multimodal vision, cross-app workflows or IDE execution are not yet integrated. No full Android build or device test is claimed.


## 0.9.6 reliability patch

This patch addresses three reported command paths: (1) the wake-word service now preserves and handles a recognized wake phrase when older/OEM SpeechRecognizer implementations return `ERROR_NO_MATCH` or `ERROR_SPEECH_TIMEOUT` after partial results, and accepts the common truncated recognition `ultra`; (2) the deterministic open-and-search parser now includes Instagram and additional common apps, and Android 8.x search submission can activate a clearly labelled key in the soft-keyboard input-method window; (3) alarm requests such as `set an alarm for 7:30 AM` and `wake me up at 6:45 PM` are routed deterministically to Android `ACTION_SET_ALARM`.

Alarm handoff success means Android accepted the Clock intent; the app cannot independently inspect the Clock app's private alarm database, so the user is asked to verify the saved alarm. Wake-word reliability still depends on the installed Android speech-recognition provider, microphone permission, OEM battery policy and device testing. App-agnostic automation remains bounded by Accessibility exposure and secure/custom screens. No Android Gradle/NDK build or physical-device test is claimed for this patch.
