# ULTRON 1.5.3 — reliability and integration fixes

- Added a separate, direct InstaBox cloud-computer API connection. API keys are stored encrypted with the app's Android Keystore-backed vault. Verify checks the official `GET https://api.instabox.sh/v1/machines` endpoint with `X-API-Key` and an `Idempotency-Key`; it does not create/start machines or incur compute runtime.
- Renamed the separate OpenAI-compatible inference URL so it is no longer confused with InstaBox account authentication.
- Reworked experimental speaker familiarity descriptors to use multi-frame cepstral statistics, three separately retained enrollment templates, recording quality gates, sample-consistency checks and an inconclusive outcome. It remains unvalidated and is not authentication.
- Removed aggressive 1.2-second speech end-of-silence overrides. Wake-word command fragments can now survive recognizer restarts and are briefly buffered/merged before dispatch to reduce cut-off on long prompts. Android provider behavior still varies.
- Removed the chat microphone shortcut beside the attachment control. Chat now uses a square stop control while an active response/task is running.
- Expanded the chat file picker to all files; added direct image payloads for compatible vision models and text extraction for common source/text formats, PDF, images, DOCX, PPTX, XLSX, ODT, ODS, ODP and text-bearing ZIP archives. Unsupported binary formats are rejected clearly; arbitrary formats cannot be understood by every LLM API.
- Added three independent replaceable animated GIF assets and holder folders for dashboard, voice core and startup. Startup animation minimum display time is 3.2 seconds.
- Bumped Android version to 1.5.3 / versionCode 33.

## Verification boundary

Standalone Kotlin checks were run for wake-word fragment merging, speaker-profile source compilation against Android compatibility stubs, and InstaBox API client source compilation against JSON/Android stubs. These are not an Android Gradle build, live InstaBox authentication, acoustic speaker-accuracy test, or on-device wake-word test. The full Android/NDK CI build and tests remain required.
