# ULTRON 1.4.1 — Build Resolution Fix

## Fixed

- Replaced the `com.google.devtools.ksp` Gradle plugin with Kotlin's `org.jetbrains.kotlin.kapt` plugin at the matching Kotlin 2.0.21 version.
- Fixed the Kotlin compiler type-inference diagnostic from run #31 by explicitly typing the `readList<UltronActionFeedback>` call in `feedbackSnapshot()`.
- Switched the Room 2.6.1 compiler configuration from `ksp(...)` to `kapt(...)` and enabled `correctErrorTypes`.
- This addresses two separate GitHub Actions failures: run #31 reached Kotlin compilation and failed at `UltronIntelligenceStore.kt:102:79` due to generic type inference; run #32 stopped during root Gradle plugin resolution because the KSP plugin marker could not be resolved.
- Bumped Android `versionCode` from 28 to 29 and `versionName` from 1.4.0 to 1.4.1.
- Updated the standalone Android CI artifact names to 1.4.1.

## Preserved

- Existing ULTRON 1.4.0 application code, Compose UI, original project assets, native llama.cpp integration, database entities/DAOs, agent coordinator, Accessibility automation, wake service, world model, routines, memory, browser, plugins and settings.

## Verification boundary

The supplied GitHub Actions logs prove that the previous run failed while resolving the KSP plugin; they do not show Kotlin source compilation failures because compilation never began. This patch removes that KSP marker resolution path. The current authoring environment has Java/Kotlin but no Gradle executable, Android SDK, NDK or outbound package-network access, so a full Gradle test/APK build cannot be rerun here. The new bundle must be pushed/uploaded to the repository and the GitHub Actions workflow must pass before calling 1.4.1 build-verified.
