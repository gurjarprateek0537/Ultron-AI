# ULTRON 1.5.0 — source delivery audit

## Source lineage

This archive is based on the locally retained `ULTRON-1.4.1-FINAL-SOURCE.zip` successor archive and preserves its Android project, native llama.cpp source, assets, database, model profiles, Accessibility executor, task coordinator, wake-word service, routines, memory, browser and plugin foundations.

## Changes

See `CHANGELOG_1.5.0.md`. Highlights include chat file attachments, removal of the chat task-control row and broken inference mode buttons, gateway-root `/v1` URL normalization, bounded retry and improved remote-worker error reporting, a simplified account-connection landing screen, and conservative wake-word recognizer tuning.

## Checks performed

- Pure Kotlin compile: `UltronWakeWordPhrase.kt` and `OpenAiEndpointUrl.kt` compiled with `kotlinc`.
- Pure Kotlin smoke checks: 6 wake-word positive cases, 3 false-positive rejection cases, command extraction, and 5 endpoint URL normalization cases passed.
- Android XML parsing: all XML files under `app/src/main` parsed successfully.
- Kotlin syntax scan: modified Android-dependent Kotlin files produced no parser/brace diagnostics. Full type-checking was unavailable because Android/Compose/Gradle dependencies are not installed.
- ZIP integrity: see final archive validation at delivery time.

## Not performed / limitations

- No Gradle `testDebugUnitTest` or `assembleDebug` run; no Gradle executable, Android SDK or NDK is available in this environment.
- No new APK was produced from this exact source.
- No physical OPPO CPH1803 / ColorOS test was performed. Wake-word detection stability, Accessibility behavior and background survival remain unverified on-device.
- The InstaBox client now retries transient failures and constructs the endpoint correctly for root and `/v1` URLs, but cannot repair a disconnected remote sandbox worker. That must be fixed on the gateway/worker host.
- Plugins only gain the API operations/scopes a specific provider authorizes. The generic OAuth/API layer is not universal website access.
- The 28 specialist roles are logical roles sharing General/Vision/Coding profiles. Multi-model All-in-One performs parallel answers, peer review and synthesis when at least two configured profiles are enabled and that mode is selected; this is not 28 separate models or a production MCP/A2A peer mesh.

**Release status:** source-level changes and limited core checks completed. Full Android build, CI and device verification are pending. Do not describe this archive as a fully device-verified release.
