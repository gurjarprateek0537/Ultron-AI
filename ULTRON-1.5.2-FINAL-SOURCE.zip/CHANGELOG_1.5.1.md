# ULTRON 1.5.1 — Visual Core Upgrade

- Replaced the dashboard hero still image with the animated ULTRON core GIF.
- Removed the rotating circular HUD/ring overlays from the dashboard hero.
- Reworked the boot splash so the animated core GIF fills the entire screen behind the startup text instead of appearing as a small square.
- Reworked the Voice screen core display into a wider, crop-to-fill media panel without the rotating circle rings.
- Added an in-app GIF picker on the Voice screen. A user-selected GIF is persisted through Storage Access Framework URI permission and reused on Voice, Dashboard and the boot splash; the bundled GIF remains the fallback.
- Updated the GIF renderer to support contain/crop-to-fill scaling and live source replacement.

This is a source/UI update. Full Android Gradle build and OPPO device playback/picker tests are still required.
