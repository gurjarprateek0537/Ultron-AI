package com.ultron.assistant

import org.junit.Assert.*
import org.junit.Test

class UltronMultiAgentCoordinatorTest {
    @Test fun registryContainsTwentyEightSpecialistRoles() {
        assertEquals(28, UltronMultiAgentCoordinator.availableRoles.size)
    }

    @Test fun simpleDeviceTaskUsesSmallFocusedTeam() {
        val selected = UltronMultiAgentCoordinator.selectAgents("set volume to 50 percent", false, false)
        assertTrue(selected.contains(UltronAgentRole.DEVICE))
        assertTrue(selected.contains(UltronAgentRole.PLANNER))
        assertFalse(selected.contains(UltronAgentRole.VISION))
        assertFalse(selected.contains(UltronAgentRole.CODER))
    }

    @Test fun screenTaskCanSelectVisionAndTargetFinder() {
        val selected = UltronMultiAgentCoordinator.selectAgents("find Rahul in Instagram chat", true, true)
        assertTrue(selected.contains(UltronAgentRole.SCREEN))
        assertTrue(selected.contains(UltronAgentRole.VISION))
        assertTrue(selected.contains(UltronAgentRole.TARGET))
        assertTrue(selected.contains(UltronAgentRole.COMMUNICATION))
    }

    @Test fun codingTaskSelectsDevelopmentSpecialists() {
        val selected = UltronMultiAgentCoordinator.selectAgents("debug and build my Kotlin APK", false, false)
        assertTrue(selected.contains(UltronAgentRole.CODER))
        assertTrue(selected.contains(UltronAgentRole.DEBUGGER))
        assertTrue(selected.contains(UltronAgentRole.TESTER))
    }

    @Test fun dispatchUsesBatteryAndNetworkStateForItsResourceBudget() {
        val constrained = UltronMultiAgentCoordinator.dispatch(
            "research across multiple pages", "com.example", 4L, true, true,
            batteryConstrained = true, networkAvailable = false
        )
        assertEquals(1, constrained.resourceBudget.maxParallelCalls)
        assertFalse(constrained.resourceBudget.allowVisionCall)
        assertTrue(constrained.resourceBudget.maxOutputTokens <= 256)
    }

    @Test fun naturalLanguageDeviceRequestsAreRouted() {
        assertTrue(UltronMultiAgentCoordinator.shouldRouteToDeviceAgent("Please open Instagram and find Rahul"))
        assertTrue(UltronMultiAgentCoordinator.shouldRouteToDeviceAgent("Could you check my notifications"))
        assertFalse(UltronMultiAgentCoordinator.shouldRouteToDeviceAgent("Explain what an AI agent is"))
    }

    @Test fun dispatchHasOneSharedTaskStateAndPhasedDelegation() {
        val dispatch = UltronMultiAgentCoordinator.dispatch("find Rahul on Instagram", "com.instagram.android", 7L, true, true)
        assertEquals("com.instagram.android", dispatch.state.currentPackage)
        assertEquals(7L, dispatch.state.screenGeneration)
        assertTrue(dispatch.parallelGroups.isNotEmpty())
        assertTrue(dispatch.promptDirective.contains("single authoritative task state"))
    }
    @Test fun selectedSpecialistsAreAssignedToExactlyOneExecutionPhase() {
        val requests = listOf(
            "read the text on screen and tap the login button",
            "compare browser sources and explain the reasoning",
            "manage my files and downloads",
            "diagnose wifi and bluetooth connectivity",
            "send a message and verify it was delivered",
            "create a calendar reminder and schedule a task",
            "debug and test a Kotlin app architecture",
            "recover after a failed action and check permissions",
            "learn this app interface and remember where settings are"
        )
        requests.forEach { request ->
            val dispatch = UltronMultiAgentCoordinator.dispatch(request, "com.example.app", 1L, true, true)
            val phased = dispatch.parallelGroups.flatten()
            assertEquals(dispatch.state.selectedAgents.distinct().sortedBy { it.ordinal }, phased.distinct().sortedBy { it.ordinal })
            assertEquals(phased.size, phased.distinct().size)
        }
    }

    @Test fun allTwentyEightRolesAreSelectableForAtLeastOneRelevantTask() {
        val requests = listOf(
            "understand my intent and the current context",
            "remember my memory from the previous conversation",
            "reason about this and compare options",
            "analyze the current screen and OCR the text on it",
            "find a button, learn this app's UI and navigate there",
            "tap a control, verify the result and recover from errors",
            "review safety and permissions before sending a message",
            "check notifications and browser research sources",
            "read a PDF file and check network connectivity",
            "control device volume and verify the new value",
            "create a calendar reminder and manage productivity tasks",
            "debug, architect, code, test and create a reusable skill"
        )
        val selected = requests.flatMap { UltronMultiAgentCoordinator.selectAgents(it, true, true) }.toSet()
        assertEquals(UltronAgentRole.values().toSet(), selected)
    }

}
