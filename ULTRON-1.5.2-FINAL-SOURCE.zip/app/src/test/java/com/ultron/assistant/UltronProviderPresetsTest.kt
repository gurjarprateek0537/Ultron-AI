package com.ultron.assistant

import org.junit.Assert.*
import org.junit.Test

class UltronProviderPresetsTest {
    @Test fun presetsUseHttpsAndSupplyOAuthEndpointsAndScopes() {
        assertTrue(UltronProviderPresets.all.isNotEmpty())
        UltronProviderPresets.all.forEach { preset ->
            assertTrue(preset.authorizationUrl.startsWith("https://"))
            assertTrue(preset.tokenUrl.startsWith("https://"))
            assertTrue(preset.endpoint.startsWith("https://"))
            assertTrue(preset.scope.isNotBlank())
        }
    }
}
