package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class OpenAiEndpointUrlTest {
    @Test fun gatewayRootAddsV1Path() {
        assertEquals("https://gateway.example/v1/chat/completions", OpenAiEndpointUrl.chatCompletions("https://gateway.example"))
    }
    @Test fun v1BaseAddsChatCompletionsOnly() {
        assertEquals("https://gateway.example/v1/chat/completions", OpenAiEndpointUrl.chatCompletions("https://gateway.example/v1/"))
    }
    @Test fun fullEndpointIsNotDuplicated() {
        assertEquals("https://gateway.example/v1/chat/completions", OpenAiEndpointUrl.chatCompletions("https://gateway.example/v1/chat/completions"))
    }
    @Test fun customApiPrefixIsPreserved() {
        assertEquals("https://gateway.example/openai/chat/completions", OpenAiEndpointUrl.chatCompletions("https://gateway.example/openai"))
    }
}
