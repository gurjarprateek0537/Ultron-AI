package com.ultron.assistant

import org.junit.Assert.*
import org.junit.Test

class UltronActionSimulationTest {
    @Test fun dryRunAcceptsKnownDependencyChainWithoutExecutingIt() {
        val result = UltronActionSimulationEngine.simulate(
            listOf(UltronSimulationAction("open_app"), UltronSimulationAction("search_in_app")),
            "com.example.launcher",
            liveScreenAvailable = true
        )
        assertTrue(result.accepted)
        assertEquals(2, result.steps.size)
        assertEquals(2, result.expectedTransitions)
        assertTrue(result.steps[1].requiresFreshScreen)
    }

    @Test fun unknownActionsAreRejectedBeforeAnyExecution() {
        val result = UltronActionSimulationEngine.simulate(
            listOf(UltronSimulationAction("execute_shell")), null, liveScreenAvailable = false
        )
        assertFalse(result.accepted)
        assertEquals(listOf("execute_shell"), result.unknownActions)
    }

    @Test fun commitmentButtonIsFlaggedAsApprovalBoundary() {
        val result = UltronActionSimulationEngine.simulate(
            listOf(UltronSimulationAction("click_text", "Send now")),
            "com.example.chat",
            liveScreenAvailable = true
        )
        assertEquals(1, result.approvalBoundaries)
        assertTrue(result.steps.single().requiresApproval)
        assertEquals(UltronActionRisk.COMMITMENT, result.steps.single().risk)
    }


    @Test fun sensitiveCommitmentLabelsAreFlaggedButOrdinaryNavigationIsNot() {
        val sensitive = listOf("Send message", "Delete all files", "Publish post", "Share publicly", "Pay now")
            .map { UltronSimulationAction("click_text", it) }
        val sensitiveResult = UltronActionSimulationEngine.simulate(sensitive, "com.example", true)
        assertEquals(sensitive.size, sensitiveResult.approvalBoundaries)
        assertTrue(sensitiveResult.steps.all { it.requiresApproval })

        val ordinary = listOf("Open settings", "Search", "Next page", "Close dialog")
            .map { UltronSimulationAction("click_text", it) }
        val ordinaryResult = UltronActionSimulationEngine.simulate(ordinary, "com.example", true)
        assertEquals(0, ordinaryResult.approvalBoundaries)
        assertTrue(ordinaryResult.steps.none { it.requiresApproval })
    }

    @Test fun screenActionsWarnWhenAccessibilityIsUnavailable() {
        val result = UltronActionSimulationEngine.simulate(
            listOf(UltronSimulationAction("tap")), null, liveScreenAvailable = false
        )
        assertTrue(result.warnings.any { it.contains("Accessibility") })
        assertTrue(result.steps.single().warnings.isNotEmpty())
    }

    @Test fun everySimulatedActionMapsToADeclaredCapability() {
        val result = UltronActionSimulationEngine.simulate(
            listOf(UltronSimulationAction("open_app"), UltronSimulationAction("tap"), UltronSimulationAction("set_flashlight"), UltronSimulationAction("call")),
            "com.example", true
        )
        assertTrue(result.steps.all { UltronCapabilityRegistry.find(it.capability) != null })
        assertEquals("DEVICE_ADMIN_OR_ACCESSIBILITY", UltronActionSimulationEngine.simulate(
            listOf(UltronSimulationAction("lock_screen")), "com.example", true
        ).steps.single().capability)
    }

    @Test fun executorSupportedActionVocabularyHasCapabilityCoverage() {
        val actionTypes = listOf(
            "open_app", "set_alarm", "click_text", "type_text", "search_in_app", "find_text_on_screen",
            "long_press_text", "scroll", "swipe", "drag", "double_tap", "wait", "wait_for_text", "read_screen", "back",
            "home", "open_recent_apps", "open_notifications", "open_quick_settings", "open_power_menu",
            "lock_screen", "wake_screen", "take_screenshot", "set_volume_percent", "adjust_volume",
            "media_control", "set_brightness_percent", "adjust_brightness", "set_flashlight", "open_internet_settings",
            "open_bluetooth_settings", "open_system_settings", "tap", "submit_search", "open_url",
            "compose_whatsapp", "compose_sms", "call", "run_plugin"
        )
        actionTypes.chunked(24).forEach { chunk ->
            val result = UltronActionSimulationEngine.simulate(chunk.map { UltronSimulationAction(it) }, "com.example", true)
            assertTrue(result.accepted)
            assertTrue(result.steps.all { UltronCapabilityRegistry.find(it.capability) != null })
        }
    }

    @Test fun plansOverLimitAreRejected() {
        val actions = List(25) { UltronSimulationAction("wait") }
        assertFalse(UltronActionSimulationEngine.simulate(actions, null, true).accepted)
    }
}
