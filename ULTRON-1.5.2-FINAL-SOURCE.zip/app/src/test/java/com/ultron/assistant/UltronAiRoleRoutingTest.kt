package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UltronAiRoleRoutingTest {
    private fun profile(id: String, role: String, enabled: Boolean = true) = AiEndpointProfile(
        id = id,
        name = id,
        role = role,
        baseUrl = "https://example.invalid/v1",
        model = id,
        apiKey = "",
        enabled = enabled
    )

    @Test fun roleAliasesNormalizeToSpecialistRoles() {
        assertEquals("general", UltronAiRoleRouting.normalize("planner"))
        assertEquals("vision", UltronAiRoleRouting.normalize("visual"))
        assertEquals("coding", UltronAiRoleRouting.normalize("developer"))
    }

    @Test fun roleRoutingDoesNotReturnDisabledOrIncompleteProfiles() {
        val profiles = listOf(
            profile("disabled", "vision", enabled = false),
            profile("incomplete", "vision").copy(baseUrl = ""),
            profile("general", "general"),
            profile("vision", "vision"),
            profile("coding", "coding")
        )
        assertEquals("vision", UltronAiRoleRouting.profileForRole(profiles, "visual")?.id)
        assertEquals("general", UltronAiRoleRouting.profileForRole(profiles, "planner")?.id)
        assertEquals("coding", UltronAiRoleRouting.profileForRole(profiles, "developer")?.id)
    }

    @Test fun liveScreenVisionRequiresEveryConsentAndCapabilityGate() {
        val vision = profile("vision", "vision")
        assertTrue(UltronAiRoleRouting.canAnalyzeLiveScreen(vision, true, true, true))
        assertFalse(UltronAiRoleRouting.canAnalyzeLiveScreen(vision, false, true, true))
        assertFalse(UltronAiRoleRouting.canAnalyzeLiveScreen(vision, true, false, true))
        assertFalse(UltronAiRoleRouting.canAnalyzeLiveScreen(vision, true, true, false))
        assertFalse(UltronAiRoleRouting.canAnalyzeLiveScreen(profile("general", "general"), true, true, true))
        assertNull(UltronAiRoleRouting.profileForRole(listOf(profile("coding", "coding")), "vision"))
    }
}
