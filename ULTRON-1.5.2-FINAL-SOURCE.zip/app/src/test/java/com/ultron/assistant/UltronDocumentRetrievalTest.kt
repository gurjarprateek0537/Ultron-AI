package com.ultron.assistant

import org.junit.Assert.*
import org.junit.Test

class UltronDocumentRetrievalTest {
    @Test fun ranksRelevantDocumentAboveUnrelatedDocument() {
        val docs = listOf(
            UltronDocumentSource(1, "Gardening", "Tomatoes need sunlight and regular watering. Soil should drain well."),
            UltronDocumentSource(2, "Android automation", "Android Accessibility services expose UI nodes. A planner can inspect the screen, click a button, and verify the next screen transition.")
        )
        val result = UltronDocumentRetrieval.search(docs, "How can Android accessibility inspect a screen and click a button?")
        assertEquals(2L, result.first().documentId)
    }

    @Test fun emptyOrStopwordOnlyQueryReturnsNoMatches() {
        val docs = listOf(UltronDocumentSource(1, "Notes", "A few ordinary notes."))
        assertTrue(UltronDocumentRetrieval.search(docs, "the and for").isEmpty())
        assertTrue(UltronDocumentRetrieval.search(docs, "").isEmpty())
    }

    @Test fun excerptsAreBounded() {
        val longText = (1..200).joinToString(". ") { "Android automation uses accessibility screen nodes and verification step $it" }
        val result = UltronDocumentRetrieval.search(listOf(UltronDocumentSource(4, "Automation", longText)), "accessibility verification", excerptChars = 120)
        assertTrue(result.isNotEmpty())
        assertTrue(result.first().excerpt.length <= 120)
    }
}
