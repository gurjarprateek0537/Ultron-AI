package com.ultron.assistant

import org.junit.Assert.*
import org.junit.Test

class UltronWakeWordPhraseTest {
    @Test fun recognizesCanonicalAndCommonRecognizerVariants() {
        assertTrue(UltronWakeWordPhrase.containsWakeWord("ULTRON open YouTube"))
        assertTrue(UltronWakeWordPhrase.containsWakeWord("hey ultra open settings"))
        assertTrue(UltronWakeWordPhrase.containsWakeWord("ultra on open maps"))
        assertTrue(UltronWakeWordPhrase.containsWakeWord("altron open camera"))
    }

    @Test fun doesNotAcceptOrdinaryMidSentenceUltraFallback() {
        assertFalse(UltronWakeWordPhrase.containsWakeWord("please use ultra settings"))
        assertFalse(UltronWakeWordPhrase.containsWakeWord("open ultron settings"))
    }

    @Test fun stripsSplitWakeWordFromCommand() {
        assertEquals("open youtube", UltronWakeWordPhrase.commandAfterWakeWord("ultra on open youtube"))
        assertEquals("set volume to 40", UltronWakeWordPhrase.commandAfterWakeWord("hey ultron set volume to 40"))
    }

    @Test fun selectsWakeWordHypothesisEvenWhenItIsNotFirst() {
        val chosen = UltronWakeWordPhrase.bestHypothesis("", listOf("open YouTube", "ultron open YouTube"))
        assertEquals("ultron open YouTube", chosen)
    }

    @Test fun mergesWakePartialWithFinalCommand() {
        val chosen = UltronWakeWordPhrase.bestHypothesis("ultron open", listOf("YouTube"))
        assertEquals("ultron open YouTube", chosen)
    }
}
