# ULTRON animated GIF assets

Replace each file independently; do not reuse one GIF for all screens. The Android runtime resources are mirrored in `app/src/main/res/raw/` with the same resource names.

- `dashboard/ultron_dashboard.gif` → dashboard hero animation (`R.raw.ultron_dashboard`)
- `voice/ultron_voice_core.gif` → voice core animation (`R.raw.ultron_voice_core`)
- `startup/ultron_startup.gif` → full-screen startup animation (`R.raw.ultron_startup`)

Keep each GIF reasonably small and optimized for Android memory use. After replacing a file, update the matching `res/raw` copy too (or use the build's asset-sync step if one is added later).
