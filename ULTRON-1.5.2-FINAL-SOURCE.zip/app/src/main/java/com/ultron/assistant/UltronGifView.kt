package com.ultron.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Movie
import android.os.SystemClock
import android.view.View

/** Animated renderer for ULTRON's bundled core GIF. */
class UltronGifView(
    context: Context,
    private val cropToFill: Boolean = false
) : View(context) {
    private var movie: Movie? = decodeBundled()
    private var startedAt = SystemClock.uptimeMillis()

    private fun decodeBundled(): Movie? = runCatching {
        context.resources.openRawResource(R.raw.ultron_voice_core).use { Movie.decodeStream(it) }
    }.getOrNull()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val gif = movie ?: return
        if (gif.width() <= 0 || gif.height() <= 0 || width <= 0 || height <= 0) return
        val duration = (gif.duration().takeIf { it > 0 } ?: 1440)
        gif.setTime(((SystemClock.uptimeMillis() - startedAt) % duration).toInt())
        val sx = width.toFloat() / gif.width()
        val sy = height.toFloat() / gif.height()
        val scale = if (cropToFill) maxOf(sx, sy) else minOf(sx, sy)
        val drawWidth = gif.width() * scale
        val drawHeight = gif.height() * scale
        val save = canvas.save()
        canvas.clipRect(0, 0, width, height)
        canvas.translate((width - drawWidth) / 2f, (height - drawHeight) / 2f)
        canvas.scale(scale, scale)
        gif.draw(canvas, 0f, 0f)
        canvas.restoreToCount(save)
        postInvalidateOnAnimation()
    }
}

