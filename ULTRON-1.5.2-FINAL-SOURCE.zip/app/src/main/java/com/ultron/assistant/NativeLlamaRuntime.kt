package com.ultron.assistant

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

/** JNI bridge to upstream llama.cpp. Model files remain in the app-private files directory. */
object NativeLlamaRuntime {
    private const val MIN_MODEL_SIZE_BYTES = 1024L * 1024L
    // Prevent a malformed or hostile URL/document provider from exhausting app-private storage.
    private const val MAX_MODEL_SIZE_BYTES = 16L * 1024L * 1024L * 1024L
    private const val COPY_BUFFER_BYTES = 64 * 1024
    private const val CONNECT_TIMEOUT_MS = 20_000
    private const val READ_TIMEOUT_MS = 120_000
    private const val MAX_REDIRECTS = 5

    private var libraryLoaded = false
    private var loadedPath: String? = null
    private var handle: Long = 0L
    private val lock = Any()

    init { libraryLoaded = runCatching { System.loadLibrary("ultron_llama"); true }.getOrDefault(false) }

    external fun nativeLoad(path: String, contextSize: Int, threads: Int): Long
    external fun nativeGenerate(handle: Long, roles: Array<String>, contents: Array<String>, maxTokens: Int): String
    external fun nativeFree(handle: Long)

    fun isAvailable(): Boolean = libraryLoaded

    fun importModel(context: Context, uriString: String): File {
        val uri = Uri.parse(uriString)
        val resolver = context.contentResolver
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }?.takeIf { it.endsWith(".gguf", ignoreCase = true) } ?: "selected-model.gguf"
        val dir = File(context.filesDir, "models").apply { check(isDirectory || mkdirs()) { "Could not create private model storage." } }
        // Unique staging files prevent overlapping imports from truncating one another.
        val temp = File.createTempFile("ultron-import-", ".gguf.part", dir)
        try {
            val input = requireNotNull(resolver.openInputStream(uri)) { "Android could not open the selected model file." }
            input.use { copyAndValidateModel(it, temp) }
            return installModel(context, dir, temp, name)
        } finally {
            if (temp.exists()) temp.delete()
        }
    }

    /** Downloads a user-supplied direct HTTPS GGUF asset URL into private storage. */
    fun downloadModel(context: Context, directUrl: String): File {
        val trimmedUrl = directUrl.trim()
        val initialUri = Uri.parse(trimmedUrl)
        require(initialUri.scheme.equals("https", ignoreCase = true) && !initialUri.host.isNullOrBlank()) {
            "Use a direct HTTPS download URL for the GGUF asset."
        }
        val dir = File(context.filesDir, "models").apply { check(isDirectory || mkdirs()) { "Could not create private model storage." } }
        // Keep concurrent downloads isolated until one validated file wins the install lock.
        val temp = File.createTempFile("ultron-download-", ".gguf.part", dir)
        val connection = openHttpsDownloadConnection(URI(trimmedUrl).toURL())
        try {
            val responseCode = connection.responseCode
            require(responseCode in 200..299) {
                "Model download failed with HTTP $responseCode. Check that the URL points directly to a downloadable GGUF asset."
            }
            val announcedLength = connection.getHeaderFieldLong("Content-Length", -1L)
            require(announcedLength < 0L || announcedLength <= MAX_MODEL_SIZE_BYTES) {
                "The model asset is larger than ULTRON's 16 GiB import limit."
            }
            connection.inputStream.use { input -> copyAndValidateModel(input, temp) }
            val modelName = initialUri.lastPathSegment?.takeIf { it.isNotBlank() } ?: "downloaded-model.gguf"
            return installModel(context, dir, temp, modelName)
        } finally {
            connection.disconnect()
            if (temp.exists()) temp.delete()
        }
    }

    /** Resolve any interrupted two-step replacement before returning the active model path. */
    fun activeModelPath(context: Context): String? = synchronized(lock) {
        val dir = File(context.filesDir, "models")
        recoverInterruptedSwap(dir)
        context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE)
            .getString("model_path", null)?.takeIf { File(it).isFile }
    }

    fun activeModelName(context: Context): String = context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE)
        .getString("model_original_name", "No model selected") ?: "No model selected"

    fun deleteModel(context: Context) {
        synchronized(lock) {
            if (handle != 0L) { runCatching { nativeFree(handle) }; handle = 0L; loadedPath = null }
            File(context.filesDir, "models/active-model.gguf").delete()
            File(context.filesDir, "models/active-model.backup").delete()
            File(context.filesDir, "models/active-model.part").delete()
            File(context.filesDir, "models/active-model.download").delete()
            context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE).edit()
                .remove("model_path").remove("model_original_name").apply()
        }
    }

    fun recommendedContextTokens(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramGb = info.totalMem / 1_000_000_000.0
        return when { ramGb >= 8.0 -> 2048; ramGb >= 6.0 -> 1536; else -> 1024 }
    }

    fun generate(context: Context, messages: List<ChatMessage>, maxTokens: Int = 256): String = synchronized(lock) {
        check(libraryLoaded) { "The native llama.cpp library did not load. Check the GitHub Actions native build log and install an arm64-v8a build." }
        val path = activeModelPath(context) ?: throw IllegalStateException("No GGUF model selected. Open Settings → Local LLM → Import GGUF model first.")
        if (handle == 0L || loadedPath != path) {
            if (handle != 0L) runCatching { nativeFree(handle) }
            // Conservative context sizes: context/KV cache can be the difference between fitting and OOM.
            val contextSize = recommendedContextTokens(context)
            val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 6)
            handle = nativeLoad(path, contextSize, threads)
            check(handle != 0L) { "llama.cpp could not load this GGUF. It may be incompatible or exceed available memory. ULTRON will not silently switch models." }
            loadedPath = path
        }
        val safeMessages = messages.filter { it.role in setOf("system", "user", "assistant") }
        require(safeMessages.isNotEmpty() && safeMessages.any { it.role == "user" }) { "Local inference needs at least one user message." }
        val roles = safeMessages.map { it.role }.toTypedArray()
        val contents = safeMessages.map { it.content.take(24_000) }.toTypedArray()
        nativeGenerate(handle, roles, contents, maxTokens.coerceIn(1, 1024)).also {
            check(it.isNotBlank()) { "The local model returned an empty response." }
        }
    }

    private fun copyAndValidateModel(input: InputStream, temp: File) {
        var copied = 0L
        val buffer = ByteArray(COPY_BUFFER_BYTES)
        FileOutputStream(temp).use { output ->
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count == 0) {
                    val single = input.read()
                    if (single < 0) break
                    require(copied < MAX_MODEL_SIZE_BYTES) {
                        "The model file is larger than ULTRON's 16 GiB import limit."
                    }
                    output.write(single)
                    copied++
                    continue
                }
                require(copied <= MAX_MODEL_SIZE_BYTES - count) {
                    "The model file is larger than ULTRON's 16 GiB import limit."
                }
                output.write(buffer, 0, count)
                copied += count
            }
            output.fd.sync()
        }
        require(copied > MIN_MODEL_SIZE_BYTES) { "The selected file is too small to be a GGUF model." }
        val magic = ByteArray(4)
        temp.inputStream().use {
            require(it.read(magic) == 4 && magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46))) {
                "This file does not have the GGUF file signature."
            }
        }
    }

    /** Follow only a small number of HTTPS redirects; never allow a secure URL to downgrade to HTTP. */
    private fun openHttpsDownloadConnection(initialUrl: URL): HttpURLConnection {
        var currentUrl = initialUrl
        for (redirectCount in 0..MAX_REDIRECTS) {
            require(currentUrl.protocol.equals("https", ignoreCase = true)) {
                "The model host redirected away from HTTPS; download cancelled."
            }
            val candidate = (currentUrl.openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "ULTRON-Android/1.5.2")
            }
            try {
                candidate.connect()
                val status = candidate.responseCode
                if (status in 300..399) {
                    val location = candidate.getHeaderField("Location")
                    candidate.disconnect()
                    require(redirectCount < MAX_REDIRECTS) { "The model host returned too many redirects." }
                    require(!location.isNullOrBlank()) { "The model host returned a redirect without a destination." }
                    currentUrl = currentUrl.toURI().resolve(location).toURL()
                    require(currentUrl.protocol.equals("https", ignoreCase = true)) {
                        "The model host redirected away from HTTPS; download cancelled."
                    }
                } else {
                    return candidate
                }
            } catch (failure: Exception) {
                candidate.disconnect()
                throw failure
            }
        }
        throw IllegalStateException("Could not resolve the model download URL.")
    }

    private fun installModel(context: Context, dir: File, temp: File, originalName: String): File = synchronized(lock) {
        val target = File(dir, "active-model.gguf")
        val backup = File(dir, "active-model.backup")
        recoverInterruptedSwap(dir)

        if (handle != 0L) { runCatching { nativeFree(handle) }; handle = 0L; loadedPath = null }
        if (backup.exists()) check(backup.delete()) { "Could not clear the previous model backup." }
        val hadPreviousModel = target.exists()
        if (hadPreviousModel) check(target.renameTo(backup)) { "Could not preserve the currently installed model before replacement." }

        if (!temp.renameTo(target)) {
            if (hadPreviousModel && backup.exists()) backup.renameTo(target)
            throw IllegalStateException("Could not move the new model into app-private storage; the previous model was restored when possible.")
        }

        val preferencesSaved = context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE).edit()
            .putString("model_path", target.absolutePath)
            .putString("model_original_name", originalName)
            .commit()
        if (!preferencesSaved) {
            target.delete()
            if (hadPreviousModel && backup.exists()) backup.renameTo(target)
            throw IllegalStateException("Could not save the selected model settings; the previous model was restored when possible.")
        }
        if (backup.exists()) backup.delete()
        target
    }

    private fun recoverInterruptedSwap(dir: File) {
        val target = File(dir, "active-model.gguf")
        val backup = File(dir, "active-model.backup")
        if (!target.exists() && backup.exists()) {
            check(backup.renameTo(target)) { "Could not recover the previously installed local model." }
        } else if (target.exists() && backup.exists()) {
            backup.delete()
        }
    }
}

class LocalModelStore(private val context: Context) {
    fun status(): String = buildString {
        append("Native llama.cpp: ").append(if (NativeLlamaRuntime.isAvailable()) "library loaded" else "library unavailable / build failed").append('\n')
        append("Selected model: ").append(NativeLlamaRuntime.activeModelName(context)).append('\n')
        append("Path: ").append(NativeLlamaRuntime.activeModelPath(context) ?: "none").append('\n')
        append("Model file is stored in app-private storage. Download the exact GGUF asset from the model repository you choose, then import it.")
    }
}
