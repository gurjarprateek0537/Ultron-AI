package com.ultron.assistant

import java.nio.charset.Charset
import java.security.MessageDigest

/**
 * A screen generation counter is an event counter, not proof that the visible page changed.
 * Android emits content-change events for cursor movement, animations and accessibility focus.
 * Remove volatile counters before comparing UI state so verification only succeeds on a
 * meaningful package/hierarchy/bounds change.
 */
object UltronScreenFingerprint {
    fun stableDescription(description: String): String = description
        .replace(Regex("\\[screen_generation=\\d+\\]"), "[screen_generation=*]")
        .replace(Regex("\\bgeneration=\\d+"), "generation=*")
        // The last accessibility event may come from the keyboard/IME rather than the app.
        .replace(Regex("(?m)\\s+lastEventPackage=[^\\s]+"), "")
        .trim()

    fun digest(packageName: String?, description: String): String {
        val stable = stableDescription(description)
        val bytes = "${packageName.orEmpty()}|$stable".toByteArray(Charset.forName("UTF-8"))
        return MessageDigest.getInstance("SHA-256").digest(bytes).take(12)
            .joinToString("") { "%02x".format(it) }
    }

    fun changed(
        beforePackage: String?, beforeDescription: String,
        afterPackage: String?, afterDescription: String
    ): Boolean = beforePackage != afterPackage || digest(beforePackage, beforeDescription) != digest(afterPackage, afterDescription)
}
