package com.ultron.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/** Imports user-selected files only. Image and PDF text is extracted on-device with ML Kit OCR. */
object DocumentIngestor {
    private const val MAX_TEXT_CHARS = 100_000
    private const val MAX_PDF_PAGES = 20

    suspend fun import(context: Context, uri: Uri): DocumentRecord = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: "Imported document"
        val text = when {
            mime.startsWith("text/") || mime in setOf("application/json", "application/xml", "application/javascript", "application/x-yaml", "application/yaml") ||
                name.substringAfterLast('.', "").lowercase() in setOf("txt", "md", "markdown", "json", "xml", "csv", "tsv", "html", "htm", "css", "js", "ts", "kt", "java", "py", "c", "h", "cpp", "hpp", "rs", "go", "sh", "yaml", "yml", "toml", "ini", "log", "sql", "gradle", "properties") -> {
                resolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(MAX_TEXT_CHARS) }
                    ?: error("Android could not open this file.")
            }
            mime == "application/pdf" || name.endsWith(".pdf", true) -> readPdfViaOcr(context, uri)
            mime.startsWith("image/") -> recognizeImage(context, uri)
            name.endsWith(".docx", true) || name.endsWith(".pptx", true) || name.endsWith(".xlsx", true) || name.endsWith(".odt", true) || name.endsWith(".ods", true) || name.endsWith(".odp", true) || name.endsWith(".zip", true) -> readZipOfficeOrArchive(context, uri, name)
            else -> error("This binary format cannot be interpreted by the configured LLM gateway. Supported attachments: text/code/CSV/JSON/XML/HTML, PDF, images, DOCX, PPTX, XLSX, ODT, ODS, ODP and ZIP archives containing readable text files.")
        }.trim()
        require(text.isNotBlank() || mime.startsWith("image/")) { "No text was extracted. The file may be empty, unsupported, or too blurry." }
        DocumentRecord(title = name, mimeType = mime, extractedText = text.take(MAX_TEXT_CHARS))
    }


    private fun readZipOfficeOrArchive(context: Context, uri: Uri, name: String): String {
        val input = context.contentResolver.openInputStream(uri) ?: error("Could not open archive.")
        val archive = input.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8_192)
            var total = 0
            while (true) {
                val n = stream.read(buffer)
                if (n < 0) break
                total += n
                require(total <= 24 * 1024 * 1024) { "Archive exceeds the 24 MB attachment limit." }
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        }
        val pieces = ArrayList<String>()
        var expanded = 0
        ZipInputStream(archive.inputStream()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory) {
                    val entryName = entry.name
                    val officeXml = entryName == "word/document.xml" || entryName == "ppt/slides/slide1.xml" ||
                        entryName.startsWith("ppt/slides/slide") || entryName == "xl/sharedStrings.xml" ||
                        entryName.startsWith("xl/worksheets/sheet") || entryName == "content.xml"
                    val textFile = entryName.substringAfterLast('/').substringAfterLast('.', "").lowercase() in
                        setOf("txt", "md", "csv", "json", "xml", "html", "htm", "yaml", "yml", "kt", "java", "py", "js", "ts", "sql", "log")
                    if (officeXml || textFile) {
                        val bytes = ByteArrayOutputStream()
                        val buffer = ByteArray(4_096)
                        while (true) {
                            val n = zip.read(buffer)
                            if (n < 0) break
                            expanded += n
                            require(expanded <= 64 * 1024 * 1024) { "Archive expands beyond the 64 MB safety limit." }
                            bytes.write(buffer, 0, n)
                        }
                        val raw = bytes.toString(Charsets.UTF_8.name())
                        val readable = if (officeXml || entryName.endsWith(".xml", true)) {
                            raw.replace(Regex("<w:tab[^>]*/>|<a:br[^>]*/>"), " ")
                                .replace(Regex("</w:p>|</a:p>|</row>|</p>"), "\n")
                                .replace(Regex("<[^>]+>"), " ")
                                .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                                .replace("&quot;", "\"").replace("&apos;", "'")
                        } else raw
                        if (readable.isNotBlank()) pieces += "[${entry.name}]\n${readable.take(MAX_TEXT_CHARS)}"
                    }
                }
                zip.closeEntry()
                if (pieces.sumOf { it.length } >= MAX_TEXT_CHARS) break
            }
        }
        val result = pieces.joinToString("\n\n").take(MAX_TEXT_CHARS)
        require(result.isNotBlank()) { "The archive contains no readable text or supported office document content." }
        return "[Extracted from $name]\n$result"
    }

    fun imageDataUrl(context: Context, uri: Uri): String {
        val mime = context.contentResolver.getType(uri)?.takeIf { it.startsWith("image/") }
            ?: error("Selected file is not a supported image.")
        val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8_192)
            var total = 0
            while (true) {
                val n = stream.read(buffer)
                if (n < 0) break
                total += n
                require(total <= 6 * 1024 * 1024) { "Image exceeds the 6 MB chat attachment limit." }
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } ?: error("Android could not read this image.")
        require(bytes.isNotEmpty()) { "Image file is empty." }
        return "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private suspend fun recognizeImage(context: Context, uri: Uri): String {
        val image = InputImage.fromFilePath(context, uri)
        val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val devanagari = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        return try {
            val first = latin.process(image).await().text
            // Run the script-specific recognizer too, useful for Hindi/Devanagari photos.
            val second = devanagari.process(image).await().text
            listOf(first, second).maxByOrNull { it.length }.orEmpty()
        } finally { latin.close(); devanagari.close() }
    }

    private suspend fun readPdfViaOcr(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: error("Could not open PDF.")
        descriptor.use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val devanagari = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                try {
                    val output = StringBuilder()
                    val pages = minOf(renderer.pageCount, MAX_PDF_PAGES)
                    for (index in 0 until pages) {
                        renderer.openPage(index).use { page ->
                            val scale = minOf(2.0, 1600.0 / maxOf(page.width, page.height))
                            val bitmap = Bitmap.createBitmap(
                                (page.width * scale).toInt().coerceAtLeast(1),
                                (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888
                            )
                            bitmap.eraseColor(Color.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            try {
                                output.append("\n\n[Page ${index + 1}]\n")
                                val image = InputImage.fromBitmap(bitmap, 0)
                                val latinText = recognizer.process(image).await().text
                                val devText = devanagari.process(image).await().text
                                output.append(if (devText.length > latinText.length) devText else latinText)
                            } finally { bitmap.recycle() }
                        }
                        if (output.length >= MAX_TEXT_CHARS) break
                    }
                    if (renderer.pageCount > MAX_PDF_PAGES) output.append("\n[Only the first $MAX_PDF_PAGES pages were processed.]\n")
                    output.toString().take(MAX_TEXT_CHARS)
                } finally { recognizer.close(); devanagari.close() }
            }
        }
    }
}
