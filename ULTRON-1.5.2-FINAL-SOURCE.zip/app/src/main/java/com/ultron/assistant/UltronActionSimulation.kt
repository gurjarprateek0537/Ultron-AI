package com.ultron.assistant

import java.util.Locale

/** Minimal, model-independent representation used for a safe plan dry-run. */
data class UltronSimulationAction(val type: String, val label: String = "")

data class UltronSimulationStep(
    val index: Int,
    val actionType: String,
    val expectedTransition: UltronTransitionExpectation,
    val risk: UltronActionRisk,
    val capability: String,
    val requiresFreshScreen: Boolean,
    val requiresApproval: Boolean,
    val confidence: Float,
    val warnings: List<String>
)

data class UltronActionSimulation(
    val accepted: Boolean,
    val steps: List<UltronSimulationStep>,
    val unknownActions: List<String>,
    val expectedTransitions: Int,
    val approvalBoundaries: Int,
    val warnings: List<String>,
    val summary: String
)


data class UltronCapabilityDescriptor(
    val id: String,
    val title: String,
    val permissionOrSetting: String,
    val boundary: String
)

/** Permission/capability vocabulary shared by planning diagnostics and the Android executor. */
object UltronCapabilityRegistry {
    val all: List<UltronCapabilityDescriptor> = listOf(
        UltronCapabilityDescriptor("NONE", "No extra capability", "None", "Action remains restricted to the allow-listed executor."),
        UltronCapabilityDescriptor("ANDROID_INTENTS", "Android app and URL intents", "A compatible installed app / browser", "Android resolves and controls the resulting activity."),
        UltronCapabilityDescriptor("SCREEN_ACCESSIBILITY", "Screen inspection and UI control", "Enable ULTRON in Android Accessibility settings", "Only currently visible, freshly inspected controls may be targeted."),
        UltronCapabilityDescriptor("DEVICE_AUDIO", "Audio and media controls", "Modify audio settings; media-session access for supported player actions", "Volume is read back where supported; player acceptance does not prove playback."),
        UltronCapabilityDescriptor("WRITE_SETTINGS", "Display brightness", "Grant ULTRON Modify system settings", "No secure settings or lock-screen bypass."),
        UltronCapabilityDescriptor("CAMERA_TORCH", "Flashlight", "Camera permission and torch-capable hardware", "Torch state may not be synchronously readable on every device."),
        UltronCapabilityDescriptor("CALL_PHONE", "Phone call", "Call permission for direct call; otherwise Android dialer", "Every call requires fresh user approval."),
        UltronCapabilityDescriptor("MESSAGING_INTENT", "Message drafting", "Compatible installed messaging app", "Drafting is not sending; a separate confirmed Send action is required."),
        UltronCapabilityDescriptor("PLUGIN_DECLARED_SCOPE", "Configured plugin", "User-configured HTTPS endpoint and declared credential/scope", "Mutating requests require approval; model output cannot add new plugin scope."),
        UltronCapabilityDescriptor("ACCESSIBILITY_SYSTEM_ACTION", "Android system navigation", "Enable ULTRON Accessibility; API/OEM support varies", "Secure lock screen and power-off confirmation remain under Android control."),
        UltronCapabilityDescriptor("DEVICE_ADMIN_OR_ACCESSIBILITY", "Screen lock", "Device Admin on API 26–27 or supported Accessibility system action", "No secure lock bypass or silent device shutdown."),
        UltronCapabilityDescriptor("ALARM_INTENT", "Create alarm", "Installed Clock app accepting ACTION_SET_ALARM", "Intent acceptance is not proof that the Clock app persisted the alarm.")
    )
    private val byId = all.associateBy { it.id }
    fun find(id: String): UltronCapabilityDescriptor? = byId[id]
}

/**
 * Preflight-only action simulation. It never dispatches Android APIs and never assumes that
 * an action will succeed. It checks the action vocabulary, surfaces risk/capability needs,
 * and records where the executor must obtain a fresh screen observation.
 */
object UltronActionSimulationEngine {
    private val supportedActions = setOf(
        "open_app", "set_alarm", "click_text", "type_text", "search_in_app", "find_text_on_screen",
        "long_press_text", "scroll", "swipe", "drag", "double_tap", "wait", "wait_for_text", "read_screen", "back",
        "home", "open_recent_apps", "open_notifications", "open_quick_settings", "open_power_menu",
        "lock_screen", "wake_screen", "take_screenshot", "set_volume_percent", "adjust_volume",
        "media_control", "set_brightness_percent", "adjust_brightness", "set_flashlight", "open_internet_settings",
        "open_bluetooth_settings", "open_system_settings", "tap", "submit_search", "open_url",
        "compose_whatsapp", "compose_sms", "call", "run_plugin"
    )

    private val screenActions = setOf(
        "click_text", "type_text", "search_in_app", "find_text_on_screen", "wait_for_text", "long_press_text", "scroll",
        "swipe", "drag", "double_tap", "read_screen", "submit_search", "tap"
    )

    private val transitionActions = setOf(
        "open_app", "open_url", "home", "back", "click_text", "type_text", "search_in_app",
        "submit_search", "tap", "double_tap", "long_press_text", "scroll", "swipe", "drag"
    )

    fun simulate(actions: List<UltronSimulationAction>, packageName: String?, liveScreenAvailable: Boolean): UltronActionSimulation {
        val bounded = actions.take(24)
        val unknown = bounded.map { it.type.trim().lowercase(Locale.ROOT) }
            .filter { it !in supportedActions }.distinct()
        val steps = bounded.mapIndexed { index, input ->
            val type = input.type.trim().lowercase(Locale.ROOT)
            val prediction = UltronWorldModel.predict(type, packageName)
            val actionWarnings = mutableListOf<String>()
            val needsScreen = type in screenActions
            val capability = capabilityFor(type)
            if (UltronCapabilityRegistry.find(capability) == null) actionWarnings += "No capability descriptor is registered for $capability."
            if (needsScreen && !liveScreenAvailable) {
                actionWarnings += "Accessibility screen inspection is unavailable; this step cannot safely target visible controls yet."
            }
            if (type == "click_text" && isCommitmentLabel(input.label)) {
                actionWarnings += "This visible control may create an external commitment and needs action-specific approval."
            }
            if (type == "run_plugin") {
                actionWarnings += "Plugin capability and HTTP/write scope must be checked by the plugin executor."
            }
            val approvalBoundary = type == "call" || isCommitmentLabel(input.label)
            UltronSimulationStep(
                index = index + 1,
                actionType = type,
                expectedTransition = prediction.expectedTransition,
                risk = if (approvalBoundary) UltronActionRisk.COMMITMENT else prediction.risk,
                capability = capability,
                requiresFreshScreen = needsScreen || type in transitionActions,
                requiresApproval = approvalBoundary,
                confidence = prediction.confidence,
                warnings = actionWarnings
            )
        }
        val warnings = buildList {
            if (actions.size > 24) add("Plan exceeds the 24-action limit; excess actions were not included in this dry-run.")
            if (unknown.isNotEmpty()) add("Unsupported action types: ${unknown.joinToString(", ")}.")
            if (steps.any { it.capability == "SCREEN_ACCESSIBILITY" } && !liveScreenAvailable) add("Enable ULTRON Accessibility before running screen-dependent steps.")
            val capabilities = steps.map { it.capability }.distinct().filter { it != "NONE" }
            if (capabilities.isNotEmpty()) add("Required capability categories: ${capabilities.joinToString(", ")}.")
            if (steps.any { it.requiresApproval }) add("One or more steps require fresh approval immediately before the external commitment.")
        }.distinct()
        val transitionCount = steps.count { it.expectedTransition == UltronTransitionExpectation.LIKELY }
        val approvalCount = steps.count { it.requiresApproval }
        val accepted = actions.size <= 24 && unknown.isEmpty()
        val summary = buildString {
            append("Preflight simulation: ").append(actions.size).append(" step(s), ")
            append(transitionCount).append(" expected UI transition(s), ")
            append(approvalCount).append(" approval boundary/boundaries. ")
            append(if (accepted) "Action vocabulary is valid; the dry-run does not guarantee runtime success." else "Plan rejected before execution.")
            if (warnings.isNotEmpty()) append(" ").append(warnings.joinToString(" ").take(650))
        }.take(900)
        return UltronActionSimulation(accepted, steps, unknown, transitionCount, approvalCount, warnings, summary)
    }

    private fun isCommitmentLabel(label: String): Boolean = Regex(
        "(?i)\\b(?:send|call|pay|payment|purchase|buy|order|transfer|delete|erase|factory reset|publish|post|share|revoke access|change password|disable security|remove two[- ]factor|reset security)\\b"
    ).containsMatchIn(label)

    private fun capabilityFor(type: String): String = when (type) {
        in screenActions -> "SCREEN_ACCESSIBILITY"
        "open_app", "open_url", "open_system_settings", "open_internet_settings", "open_bluetooth_settings" -> "ANDROID_INTENTS"
        "set_volume_percent", "adjust_volume", "media_control" -> "DEVICE_AUDIO"
        "set_brightness_percent", "adjust_brightness" -> "WRITE_SETTINGS"
        "set_flashlight" -> "CAMERA_TORCH"
        "call" -> "CALL_PHONE"
        "compose_sms", "compose_whatsapp" -> "MESSAGING_INTENT"
        "run_plugin" -> "PLUGIN_DECLARED_SCOPE"
        "lock_screen" -> "DEVICE_ADMIN_OR_ACCESSIBILITY"
        "open_power_menu", "open_quick_settings", "open_notifications", "open_recent_apps", "home", "back", "wake_screen", "take_screenshot" -> "ACCESSIBILITY_SYSTEM_ACTION"
        "set_alarm" -> "ALARM_INTENT"
        else -> "NONE"
    }
}
