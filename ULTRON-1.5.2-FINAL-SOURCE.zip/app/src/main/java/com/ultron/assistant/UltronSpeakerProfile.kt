package com.ultron.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sqrt

/** Experimental voice-familiarity profile. It is deliberately NOT a biometric authenticator. */
data class UltronSpeakerMatch(val similarity: Double, val resemblesEnrolledVoice: Boolean)

object UltronSpeakerProfile {
    private const val PREFS = "ultron_speaker_profile"
    private const val VECTOR_KEY = "voice_signature_v1"
    private const val SAMPLE_RATE = 16_000
    private const val CAPTURE_MILLIS = 2_200
    private const val FRAME_SIZE = 512
    private val probesHz = doubleArrayOf(120.0, 180.0, 250.0, 340.0, 460.0, 600.0, 780.0, 1_000.0, 1_280.0, 1_600.0, 2_000.0, 2_450.0, 2_950.0, 3_500.0, 4_100.0)

    fun isEnrolled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(VECTOR_KEY)

    /** Capture three consented samples and store only an encrypted acoustic summary; raw audio is discarded. */
    suspend fun enroll(context: Context): String = withContext(Dispatchers.IO) {
        requireMicPermission(context)
        val samples = (1..3).map { captureDescriptor(context.applicationContext) }
        val centroid = DoubleArray(samples.first().size) { index -> samples.map { it[index] }.average() }
        val encoded = centroid.joinToString(",") { "%.7f".format(java.util.Locale.US, it) }
        val encrypted = PrivateTextVault.encrypt(encoded)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(VECTOR_KEY, encrypted).apply()
        "Experimental voice profile saved from three samples. Raw audio was not retained."
    }

    /** Returns a resemblance score for UI personalization only; never authorize an action from it. */
    suspend fun compare(context: Context): UltronSpeakerMatch = withContext(Dispatchers.IO) {
        requireMicPermission(context)
        val stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(VECTOR_KEY, null)
            ?: throw IllegalStateException("Enroll a voice profile first.")
        val expected = PrivateTextVault.decrypt(stored).split(',').mapNotNull { it.toDoubleOrNull() }.toDoubleArray()
        val actual = captureDescriptor(context.applicationContext)
        require(expected.size == actual.size) { "Saved voice profile format is incompatible; enroll again." }
        val dot = expected.indices.sumOf { expected[it] * actual[it] }
        val normA = sqrt(expected.sumOf { it * it }).coerceAtLeast(1e-9)
        val normB = sqrt(actual.sumOf { it * it }).coerceAtLeast(1e-9)
        val similarity = (dot / (normA * normB)).coerceIn(-1.0, 1.0)
        UltronSpeakerMatch(similarity, similarity >= 0.90)
    }

    fun clear(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(VECTOR_KEY).apply() }

    private fun requireMicPermission(context: Context) {
        check(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            "Microphone permission is required for voice-profile capture."
        }
    }

    private fun captureDescriptor(context: Context): DoubleArray {
        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(minBuffer > 0) { "This device does not support 16 kHz microphone capture." }
        val recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuffer, FRAME_SIZE * 4))
        check(recorder.state == AudioRecord.STATE_INITIALIZED) { "Could not initialize the microphone." }
        val target = ShortArray(SAMPLE_RATE * CAPTURE_MILLIS / 1_000)
        val chunk = ShortArray(2_048)
        var offset = 0
        try {
            recorder.startRecording()
            while (offset < target.size) {
                val count = recorder.read(chunk, 0, minOf(chunk.size, target.size - offset))
                check(count > 0) { "Microphone capture stopped before a complete sample was recorded." }
                chunk.copyInto(target, offset, 0, count)
                offset += count
            }
        } finally {
            runCatching { recorder.stop() }
            recorder.release()
        }
        return describe(target)
    }

    /** Log spectral probe energies plus voice activity statistics; not a trained speaker embedding. */
    private fun describe(pcm: ShortArray): DoubleArray {
        val totals = DoubleArray(probesHz.size + 2)
        var frames = 0
        var voicedFrames = 0
        var offset = 0
        while (offset + FRAME_SIZE <= pcm.size) {
            var energy = 0.0
            var crossings = 0
            for (i in 0 until FRAME_SIZE) {
                val value = pcm[offset + i].toDouble()
                energy += value * value
                if (i > 0 && (pcm[offset + i - 1] >= 0) != (pcm[offset + i] >= 0)) crossings++
            }
            val rms = sqrt(energy / FRAME_SIZE)
            if (rms >= 180.0) {
                voicedFrames++
                probesHz.forEachIndexed { index, frequency ->
                    val omega = 2.0 * PI * frequency / SAMPLE_RATE
                    val coefficient = 2.0 * cos(omega)
                    var s1 = 0.0; var s2 = 0.0
                    for (i in 0 until FRAME_SIZE) {
                        val window = 0.5 - 0.5 * cos(2.0 * PI * i / (FRAME_SIZE - 1))
                        val sample = (pcm[offset + i].toDouble() / 32768.0) * window
                        val s0 = sample + coefficient * s1 - s2
                        s2 = s1; s1 = s0
                    }
                    val power = (s1 * s1 + s2 * s2 - coefficient * s1 * s2).coerceAtLeast(1e-12)
                    totals[index] += ln(power)
                }
                totals[probesHz.size] += crossings.toDouble() / FRAME_SIZE
                totals[probesHz.size + 1] += ln(rms + 1.0)
            }
            frames++
            offset += FRAME_SIZE / 2
        }
        require(frames >= 20 && voicedFrames >= 8) { "Too little clear speech detected. Speak naturally, closer to the microphone, and try again." }
        val vector = DoubleArray(totals.size) { totals[it] / voicedFrames }
        // Remove global level so a small microphone-distance change has less effect.
        val spectralMean = vector.take(probesHz.size).average()
        for (i in probesHz.indices) vector[i] -= spectralMean
        val norm = sqrt(vector.sumOf { it * it }).coerceAtLeast(1e-9)
        return DoubleArray(vector.size) { vector[it] / norm }
    }
}
