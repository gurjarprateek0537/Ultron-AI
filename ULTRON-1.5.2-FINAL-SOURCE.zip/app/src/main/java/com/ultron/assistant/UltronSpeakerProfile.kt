package com.ultron.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sqrt

/** A weak acoustic resemblance signal only; never an identity credential. */
data class UltronSpeakerMatch(val similarity: Double, val resemblesEnrolledVoice: Boolean, val confidence: String)

object UltronSpeakerProfile {
    private const val PREFS = "ultron_speaker_profile"
    private const val VECTOR_KEY = "voice_signature_mfcc_v2"
    private const val SAMPLE_RATE = 16_000
    private const val CAPTURE_MILLIS = 3_500
    private const val FRAME_SIZE = 512
    private const val HOP_SIZE = 256
    private val melCenters = doubleArrayOf(250.0, 310.0, 380.0, 460.0, 550.0, 650.0, 770.0, 900.0, 1_050.0, 1_220.0, 1_410.0, 1_620.0, 1_850.0, 2_100.0, 2_380.0, 2_680.0, 3_000.0, 3_350.0, 3_700.0, 4_050.0)

    fun isEnrolled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(VECTOR_KEY)

    suspend fun enroll(context: Context): String = withContext(Dispatchers.IO) {
        requireMicPermission(context)
        val samples = (1..3).map { captureDescriptor(context.applicationContext) }
        val consistency = pairwiseMinimum(samples)
        require(consistency >= 0.55) {
            "The three samples were too different or noisy (consistency ${(consistency * 100).toInt()}%). Re-enroll in a quiet room, using the same spoken sentence and microphone distance."
        }
        val encoded = samples.joinToString(";") { vector -> vector.joinToString(",") { "%.8f".format(java.util.Locale.US, it) } }
        val encrypted = PrivateTextVault.encrypt(encoded)
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(VECTOR_KEY, encrypted).commit()) {
            "Could not save the encrypted voice profile."
        }
        "Three voice samples captured and saved. Sample consistency ${(consistency * 100).toInt()}%. This is an experimental acoustic profile, not speaker authentication."
    }

    suspend fun compare(context: Context): UltronSpeakerMatch = withContext(Dispatchers.IO) {
        requireMicPermission(context)
        val stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(VECTOR_KEY, null)
            ?: throw IllegalStateException("Enroll a voice profile first.")
        val templates = PrivateTextVault.decrypt(stored).split(';').map { encoded ->
            encoded.split(',').mapNotNull { it.toDoubleOrNull() }.toDoubleArray()
        }.filter { it.isNotEmpty() }
        require(templates.size == 3 && templates.all { it.size == 26 }) { "Saved voice profile is invalid or from an older version. Delete it and enroll again." }
        val actual = captureDescriptor(context.applicationContext)
        val scores = templates.map { cosine(it, actual) }.sortedDescending()
        // Require agreement across multiple enrollment samples. A single unusually close template is insufficient.
        val meanTopTwo = (scores[0] + scores[1]) / 2.0
        val spread = scores[0] - scores[2]
        val confidence = when {
            meanTopTwo >= 0.90 && spread <= 0.22 -> "strong acoustic resemblance"
            meanTopTwo < 0.72 -> "low acoustic resemblance"
            else -> "inconclusive · repeat in a quiet room"
        }
        UltronSpeakerMatch(meanTopTwo.coerceIn(-1.0, 1.0), meanTopTwo >= 0.90 && spread <= 0.22, confidence)
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(VECTOR_KEY).remove("voice_signature_v1").apply()
    }

    private fun requireMicPermission(context: Context) {
        check(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            "Microphone permission is required for voice-profile capture."
        }
    }

    private fun captureDescriptor(context: Context): DoubleArray {
        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(minBuffer > 0) { "This device does not support 16 kHz microphone capture." }
        val recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuffer, FRAME_SIZE * 8))
        check(recorder.state == AudioRecord.STATE_INITIALIZED) { "Could not initialize the microphone." }
        val target = ShortArray(SAMPLE_RATE * CAPTURE_MILLIS / 1_000)
        val chunk = ShortArray(2_048)
        var offset = 0
        try {
            recorder.startRecording()
            while (offset < target.size) {
                val count = recorder.read(chunk, 0, minOf(chunk.size, target.size - offset))
                check(count > 0) { "Microphone capture stopped before a complete sample was recorded." }
                chunk.copyInto(target, offset, 0, count)
                offset += count
            }
        } finally {
            runCatching { recorder.stop() }
            recorder.release()
        }
        return describe(target)
    }

    /** 13 MFCC-like coefficients (mean + standard deviation) over voiced frames. */
    private fun describe(pcm: ShortArray): DoubleArray {
        val frameVectors = ArrayList<DoubleArray>()
        var totalRms = 0.0
        var clipped = 0
        var frameCount = 0
        var offset = 0
        while (offset + FRAME_SIZE <= pcm.size) {
            var energy = 0.0
            for (i in 0 until FRAME_SIZE) {
                val sample = pcm[offset + i].toDouble()
                energy += sample * sample
                if (kotlin.math.abs(sample) >= 32_000) clipped++
            }
            val rms = sqrt(energy / FRAME_SIZE)
            frameCount++
            if (rms >= 220.0) {
                totalRms += rms
                val logBands = DoubleArray(melCenters.size) { band ->
                    val frequency = melCenters[band]
                    val omega = 2.0 * PI * frequency / SAMPLE_RATE
                    val coefficient = 2.0 * cos(omega)
                    var s1 = 0.0; var s2 = 0.0
                    for (i in 0 until FRAME_SIZE) {
                        val window = 0.5 - 0.5 * cos(2.0 * PI * i / (FRAME_SIZE - 1))
                        val sample = pcm[offset + i].toDouble() / 32768.0 * window
                        val s0 = sample + coefficient * s1 - s2
                        s2 = s1; s1 = s0
                    }
                    ln((s1 * s1 + s2 * s2 - coefficient * s1 * s2).coerceAtLeast(1e-12))
                }
                val mfcc = DoubleArray(13) { coefficient ->
                    var sum = 0.0
                    for (band in logBands.indices) sum += logBands[band] * cos(PI * coefficient * (band + 0.5) / logBands.size)
                    sum / logBands.size
                }
                frameVectors.add(mfcc)
            }
            offset += HOP_SIZE
        }
        require(frameCount >= 80 && frameVectors.size >= 35) { "Too little clear speech detected. Speak continuously for 3–4 seconds and try again." }
        require(clipped.toDouble() / (frameCount * FRAME_SIZE) < 0.025) { "Recording was distorted or too loud. Move slightly farther from the microphone and retry." }
        val meanRms = totalRms / frameVectors.size
        require(meanRms >= 250.0) { "Recording was too quiet. Move closer to the microphone and speak clearly." }
        val means = DoubleArray(13) { i -> frameVectors.map { it[i] }.average() }
        val deviations = DoubleArray(13) { i -> sqrt(frameVectors.map { (it[i] - means[i]) * (it[i] - means[i]) }.average()) }
        val features = DoubleArray(26)
        for (i in 0 until 13) { features[i] = means[i]; features[i + 13] = deviations[i] }
        // Normalize cepstral dimensions separately to reduce dominance by channel gain.
        val mean = features.take(13).average()
        for (i in 0 until 13) features[i] -= mean
        val norm = sqrt(features.sumOf { it * it }).coerceAtLeast(1e-9)
        return DoubleArray(features.size) { features[it] / norm }
    }

    private fun cosine(a: DoubleArray, b: DoubleArray): Double {
        require(a.size == b.size)
        val dot = a.indices.sumOf { a[it] * b[it] }
        val na = sqrt(a.sumOf { it * it }).coerceAtLeast(1e-9)
        val nb = sqrt(b.sumOf { it * it }).coerceAtLeast(1e-9)
        return (dot / (na * nb)).coerceIn(-1.0, 1.0)
    }

    private fun pairwiseMinimum(samples: List<DoubleArray>): Double {
        if (samples.size != 3) return -1.0
        return minOf(cosine(samples[0], samples[1]), cosine(samples[0], samples[2]), cosine(samples[1], samples[2]))
    }
}
