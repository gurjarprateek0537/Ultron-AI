package com.ultron.assistant

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.Data
import java.util.concurrent.TimeUnit

/**
 * WorkManager-backed routine scheduling. Android may defer execution during Doze or battery
 * restrictions; a scheduled routine is a best-effort trigger, not an exact-time guarantee.
 * The normal ULTRON planner and executor still apply, including confirmation for commitments.
 */
object UltronRoutineScheduler {
    const val MIN_REPEAT_INTERVAL_MILLIS = 15L * 60L * 1000L
    private const val KEY_ROUTINE_ID = "routine_id"

    private fun uniqueName(id: String) = "ultron-routine-${id.take(64)}"

    fun schedule(context: Context, routine: UltronRoutine): Boolean {
        require(routine.id.isNotBlank()) { "Routine ID is missing." }
        require(routine.enabled) { "Disabled routines cannot be scheduled." }
        require(routine.triggerAtMillis > System.currentTimeMillis()) { "Choose a future start time." }
        require(routine.repeatIntervalMillis == 0L || routine.repeatIntervalMillis >= MIN_REPEAT_INTERVAL_MILLIS) {
            "Repeating routines must be at least 15 minutes apart (Android WorkManager limit)."
        }
        val delay = (routine.triggerAtMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val data = Data.Builder().putString(KEY_ROUTINE_ID, routine.id).build()
        val manager = WorkManager.getInstance(context.applicationContext)
        manager.cancelUniqueWork(uniqueName(routine.id))
        if (routine.repeatIntervalMillis > 0L) {
            val request = PeriodicWorkRequestBuilder<UltronRoutineWorker>(routine.repeatIntervalMillis, TimeUnit.MILLISECONDS)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(data)
                .build()
            manager.enqueueUniquePeriodicWork(uniqueName(routine.id), ExistingPeriodicWorkPolicy.REPLACE, request)
        } else {
            val request = OneTimeWorkRequestBuilder<UltronRoutineWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(data)
                .build()
            manager.enqueueUniqueWork(uniqueName(routine.id), ExistingWorkPolicy.REPLACE, request)
        }
        return true
    }

    fun cancel(context: Context, routineId: String) {
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(uniqueName(routineId))
    }

    fun runNow(context: Context, routine: UltronRoutine) {
        require(routine.enabled) { "Enable the routine before running it." }
        // Route through the same background planner and approval flow as ordinary commands.
        UltronAgentWorker.enqueue(context.applicationContext, routine.command)
    }
}

class UltronRoutineWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString("routine_id") ?: return Result.failure()
        val store = UltronRoutineStore(applicationContext)
        val routine = store.find(id) ?: return Result.success()
        if (!routine.enabled) return Result.success()
        val now = System.currentTimeMillis()
        return try {
            val occurrence = routine.pendingRunSlot.takeIf { it >= 0L } ?: if (routine.repeatIntervalMillis > 0L && now >= routine.triggerAtMillis) {
                (now - routine.triggerAtMillis) / routine.repeatIntervalMillis
            } else 0L
            val claimed = routine.copy(pendingRunSlot = occurrence)
            store.save(claimed) // Persist the slot before enqueue so a worker retry uses the same idempotency key.
            UltronAgentWorker.enqueueRoutine(applicationContext, claimed, occurrence)
            val updated = claimed.copy(lastRunAtMillis = now, pendingRunSlot = -1L)
            if (routine.repeatIntervalMillis == 0L) {
                // One-shot definitions remain visible but are disabled after dispatch.
                store.save(updated.copy(enabled = false))
            } else {
                store.save(updated)
            }
            UltronAgentNotifications.show(
                applicationContext,
                "ULTRON · Routine started",
                "${routine.name} was sent to the normal planner. Sensitive actions still require your approval."
            )
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
