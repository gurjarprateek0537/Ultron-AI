package com.ultron.assistant

import android.content.Intent
import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.core.content.FileProvider
import androidx.activity.result.ActivityResultLauncher
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.layout.ContentScale
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.lifecycle.lifecycleScope
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.File
import java.util.concurrent.TimeUnit

private val Night = Color(0xFF090A0D)
private val Panel = Color(0xFF11141A)
private val Crimson = Color(0xFFFF343D)
private val Orange = Color(0xFFFF9A52)
private val Purple = Color(0xFF9D83D8)

class MainActivity : FragmentActivity(), TextToSpeech.OnInitListener {
    companion object {
        val voiceCommands = MutableStateFlow<String?>(null)
        val externalReplies = MutableStateFlow<String?>(null)
        private const val REQUEST_CAMERA_VISION = 7812
    }
    private lateinit var cameraLauncher: ActivityResultLauncher<Uri>
    private lateinit var screenCaptureLauncher: ActivityResultLauncher<Intent>
    private var pendingVisionUri: Uri? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var settingsStore: SettingsStore
    private lateinit var database: UltronDatabase
    private val appLockEnabled = mutableStateOf(false)
    private val appUnlocked = mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        screenCaptureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                runCatching {
                    val capture = Intent(this, UltronScreenCaptureService::class.java)
                        .setAction(UltronScreenCaptureService.ACTION_START)
                        .putExtra(UltronScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                        .putExtra(UltronScreenCaptureService.EXTRA_RESULT_DATA, data)
                    if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, capture) else startService(capture)
                    Toast.makeText(this, "ULTRON screen awareness started", Toast.LENGTH_SHORT).show()
                }.onFailure {
                    Toast.makeText(this, "Screen awareness could not start: ${it.message ?: "Android restriction"}", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Screen capture permission was not granted; ULTRON will use accessible screen information only.", Toast.LENGTH_LONG).show()
            }
        }
        cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
            val uri = pendingVisionUri
            pendingVisionUri = null
            if (saved && uri != null) processVisionCapture(uri)
            else Toast.makeText(this, "Camera capture cancelled or unavailable.", Toast.LENGTH_SHORT).show()
        }
        voiceCommands.value = intent?.getStringExtra(UltronWakeWordService.EXTRA_WAKE_COMMAND)
        settingsStore = SettingsStore(this)
        database = UltronDatabase.get(this)
        intent?.data?.let { handleOAuthCallback(it) }
        appLockEnabled.value = AppLockStore.isEnabled(this)
        appUnlocked.value = !appLockEnabled.value
        tts = TextToSpeech(this, this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "ultron-chat-cleanup",
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ChatCleanupWorker>(6, TimeUnit.HOURS).build()
        )
        // Archived conversations are pruned by ChatCleanupWorker after their 72-hour expiry.
        // Active conversations are not age-pruned while the user is still chatting.
        setContent {
            if (appLockEnabled.value && !appUnlocked.value) {
                AppLockScreen(onUnlock = { authenticateAppUnlock() })
            } else UltronScreen(
                initialSettings = settingsStore.load(),
                database = database,
                onSaveSettings = { settingsStore.save(it) },
                onSpeak = { if (ttsReady) {
                    runCatching { VoiceOutputStore(this).apply(tts!!, VoiceOutputStore(this).load()) }
                    tts?.speak(UltronSpeechSummary.from(it), TextToSpeech.QUEUE_FLUSH, null, "ultron-reply")
                } },
                onVoiceSettingsChanged = { language, gender ->
                    val preference = VoiceOutputPreference(language, gender)
                    VoiceOutputStore(this).save(preference)
                    if (ttsReady) VoiceOutputStore(this).apply(tts!!, preference) else "Voice engine is still starting."
                },
                onAction = { action -> runAction(action) },
                onOpenSpecialSetting = { AndroidAccess.openSpecialSetting(this, it) },
                onSetAppLock = { enabled -> setAppLock(enabled) }
            )
        }
        // If the user previously enabled the persistent listener, resume it when they open
        // ULTRON after boot. On Android 14+ this foreground activity is the required user step.
        if (UltronWakeWordPreferences.isEnabled(this) &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED &&
            (UltronWakeWordPreferences.isBootResumePending(this) || intent?.getBooleanExtra(UltronBootReceiver.EXTRA_RESUME_WAKE, false) == true)
        ) {
            startWakeWordFromVisibleActivity()
        }
    }


    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        voiceCommands.value = intent.getStringExtra(UltronWakeWordService.EXTRA_WAKE_COMMAND)
        if (intent.getBooleanExtra(UltronBootReceiver.EXTRA_RESUME_WAKE, false) &&
            UltronWakeWordPreferences.isEnabled(this) &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) startWakeWordFromVisibleActivity()
        intent.data?.let { handleOAuthCallback(it) }
    }

    private fun startWakeWordFromVisibleActivity() {
        runCatching {
            val wake = Intent(this, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_RESTORE)
            if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, wake) else startService(wake)
            Toast.makeText(this, "ULTRON wake-word listener resuming", Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(this, "Wake-word resume blocked: ${it.message ?: "check microphone permission"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun handleOAuthCallback(uri: Uri) {
        if (uri.scheme != "ultron" || uri.host != "oauth" || uri.path != "/callback") return
        lifecycleScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { PluginStore(this@MainActivity).completeOAuthCallback(uri) } }
            Toast.makeText(this@MainActivity, result.getOrElse { "OAuth connection failed: ${it.message ?: "unknown error"}" }, Toast.LENGTH_LONG).show()
        }
    }

    private fun setAppLock(enabled: Boolean): Boolean {
        if (!enabled) {
            AppLockStore.setEnabled(this, false)
            appLockEnabled.value = false
            appUnlocked.value = true
            return true
        }
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK
        val availability = BiometricManager.from(this).canAuthenticate(authenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) return false
        AppLockStore.setEnabled(this, true)
        appLockEnabled.value = true
        appUnlocked.value = true
        return true
    }

    private fun authenticateAppUnlock() {
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK
        val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ULTRON")
            .setSubtitle("Authenticate to open your private assistant")
            .setAllowedAuthenticators(authenticators)
        if (Build.VERSION.SDK_INT < 30) promptInfoBuilder.setNegativeButtonText("Cancel")
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                appUnlocked.value = true
            }
        })
        runCatching { prompt.authenticate(promptInfoBuilder.build()) }
    }

    override fun onPause() {
        if (appLockEnabled.value) appUnlocked.value = false
        super.onPause()
    }

    private fun runAction(action: String) {
        val intent = when (action) {
            "Browser" -> Intent(this, UltronBrowserActivity::class.java)
            "Settings" -> Intent(Settings.ACTION_SETTINGS)
            "TTS_INSTALL" -> Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
            "Camera" -> { startVisionCapture(); return }
            "SCREEN_CAPTURE_START" -> { startScreenCapture(); return }
            "SCREEN_CAPTURE_STOP" -> {
                stopService(Intent(this, UltronScreenCaptureService::class.java).setAction(UltronScreenCaptureService.ACTION_STOP))
                Toast.makeText(this, "ULTRON screen awareness stopped", Toast.LENGTH_SHORT).show()
                return
            }
            "Dialer" -> Intent(Intent.ACTION_DIAL)
            "Maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=nearby places"))
            else -> if (action.startsWith("URL:")) Intent(Intent.ACTION_VIEW, Uri.parse(action.removePrefix("URL:"))) else null
        }
        if (intent != null) runCatching { startActivity(intent) }
    }

    private fun startScreenCapture() {
        if (UltronScreenCaptureStore.isCaptureActive()) {
            Toast.makeText(this, "ULTRON screen awareness is already active", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            val manager = getSystemService(android.media.projection.MediaProjectionManager::class.java)
                ?: throw IllegalStateException("Android MediaProjection service is unavailable.")
            screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
        }.onFailure {
            Toast.makeText(this, "Android screen-capture consent could not open: ${it.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startVisionCapture() {
        runCatching {
            val directory = File(cacheDir, "vision").apply { mkdirs() }
            val image = File(directory, "ultron-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", image)
            pendingVisionUri = uri
            cameraLauncher.launch(uri)
        }.onFailure { Toast.makeText(this, "Camera could not start: ${it.message ?: "file provider error"}", Toast.LENGTH_LONG).show() }
    }

    private fun processVisionCapture(uri: Uri) {
        lifecycleScope.launch {
            Toast.makeText(this@MainActivity, "ULTRON is analyzing the captured image…", Toast.LENGTH_SHORT).show()
            val result = runCatching {
                val dataUrl = withContext(Dispatchers.IO) {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw IllegalStateException("Captured image could not be read.")
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (bounds.outWidth / sample > 1280 || bounds.outHeight / sample > 1280) sample *= 2
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                        ?: throw IllegalStateException("Image decoding failed.")
                    val output = java.io.ByteArrayOutputStream()
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, output)
                    bitmap.recycle()
                    "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                }
                val profiles = AiProfileStore(this@MainActivity).load()
                val vision = profiles.firstOrNull { it.enabled && UltronAiRoleRouting.normalize(it.role) == "vision" && it.baseUrl.isNotBlank() && it.model.isNotBlank() }
                val settings = settingsStore.load()
                if (vision == null && settings.mode == InferenceMode.LOCAL) {
                    throw IllegalStateException("Image analysis needs an online vision-capable profile. Add one in Settings → AI profiles, with role ‘vision’ and a model endpoint that accepts image_url content.")
                }
                val prompt = "Analyze this camera image carefully. Describe visible objects, text, scene and useful details. Clearly state uncertainty and do not invent invisible details."
                val messages = listOf(ChatMessage("user", prompt, dataUrl))
                val answer = withContext(Dispatchers.IO) {
                    val repository = InferenceRepository(this@MainActivity)
                    if (vision != null) repository.completeProfile(messages, vision).text
                    else repository.complete(messages, settings).text
                }
                withContext(Dispatchers.IO) {
                    val sessionId = ConversationSessionStore(this@MainActivity).currentOrCreate()
                    database.chatDao().insert(ChatRecord(role = "user", content = PrivateTextVault.encrypt("[Camera image] $prompt"), conversationId = sessionId, archived = false))
                    database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(answer), conversationId = sessionId, archived = false))
                }
                answer
            }
            val response = result.getOrElse { "Vision analysis failed: ${it.message ?: "unknown error"}" }
            externalReplies.value = response
            val preference = VoiceOutputStore(this@MainActivity).load()
            if (ttsReady) {
                VoiceOutputStore(this@MainActivity).apply(tts!!, preference)
                tts?.speak(UltronSpeechSummary.from(response), TextToSpeech.QUEUE_FLUSH, null, "ultron-vision-reply")
            }
            Toast.makeText(this@MainActivity, if (result.isSuccess) "Vision analysis complete" else "Vision analysis failed", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.setPitch(.96f)
            tts?.setSpeechRate(.94f)
            runCatching { VoiceOutputStore(this).apply(tts!!, VoiceOutputStore(this).load()) }
        }
    }

    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun UltronScreen(
    initialSettings: LlmSettings,
    database: UltronDatabase,
    onSaveSettings: (LlmSettings) -> Unit,
    onSpeak: (String) -> Unit,
    onVoiceSettingsChanged: (String, String) -> String,
    onAction: (String) -> Unit,
    onOpenSpecialSetting: (String) -> Unit,
    onSetAppLock: (Boolean) -> Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(initialSettings) }
    var contextWindowText by remember { mutableStateOf(initialSettings.contextWindowTokens.toString()) }
    var maxOutputText by remember { mutableStateOf(initialSettings.maxOutputTokens.toString()) }
    val conversationMemory = remember(context, database) { UltronConversationMemory(context.applicationContext, database) }
    var conversationId by remember { mutableStateOf(conversationMemory.activeId()) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var activeChatJob by remember { mutableStateOf<Job?>(null) }
    var voiceReply by remember { mutableStateOf(true) }
    val savedVoicePreference = remember(context) { VoiceOutputStore(context).load() }
    var voiceLanguage by remember { mutableStateOf(savedVoicePreference.language) }
    var voiceGender by remember { mutableStateOf(savedVoicePreference.gender) }
    var voiceStatus by remember { mutableStateOf("Select your preferred spoken reply voice.") }
    var appLockOn by remember { mutableStateOf(AppLockStore.isEnabled(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf("HOME") }
    var showAccess by remember { mutableStateOf(false) }
    var accessRefresh by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Ready · configure your InstaBox gateway in Settings") }
    val aiProfileStore = remember(context) { AiProfileStore(context) }
    var aiProfiles by remember { mutableStateOf(aiProfileStore.load()) }
    var selectedAiId by remember { mutableStateOf(aiProfileStore.activeProfileId()) }
    var shareScreenWithVision by remember { mutableStateOf(UltronScreenCaptureStore.isCloudVisionEnabled(context)) }
    var screenCaptureActive by remember { mutableStateOf(UltronScreenCaptureStore.isCaptureActive()) }
    var allInOne by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf("") }
    var profileRole by remember { mutableStateOf("coding") }
    var profileUrl by remember { mutableStateOf("") }
    var profileModel by remember { mutableStateOf("") }
    var profileKey by remember { mutableStateOf("") }
    val lines = remember { mutableStateListOf(ChatMessage("assistant", "I am ULTRON. Online AI uses the endpoint you configure. Local AI will report clearly until a compatible native model runtime is installed.")) }
    val repository = remember(context) { InferenceRepository(context.applicationContext) }
    val pendingWakeCommand by MainActivity.voiceCommands.collectAsState()
    val externalReply by MainActivity.externalReplies.collectAsState()
    val router = remember(database) { UltronCommandRouter(context.applicationContext, database) }

    LaunchedEffect(Unit) {
        while (true) {
            screenCaptureActive = UltronScreenCaptureStore.isCaptureActive()
            delay(900L)
        }
    }

    var wakeStartPermissionRequested by remember { mutableStateOf(false) }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }
    val runtimePermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val granted = result.filterValues { it }.keys
        accessRefresh++
        status = if (granted.isNotEmpty()) "Permission result received · ${granted.size} granted" else "No new permissions granted"
        if (wakeStartPermissionRequested) {
            wakeStartPermissionRequested = false
            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                runCatching {
                    val wake = Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START)
                    if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(context, wake) else context.startService(wake)
                    status = "Wake-word listener starting · persistent preference saved"
                }.onFailure { status = "Microphone granted but wake-word service failed: ${it.message}" }
            } else status = "Microphone permission was not granted. Wake-word listener remains disabled."
        }
    }
    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Importing and extracting text locally…"
                try {
                    val record = DocumentIngestor.import(context, uri)
                    val id = withContext(Dispatchers.IO) { database.documentDao().insert(record.copy(title = PrivateTextVault.encrypt(record.title), extractedText = PrivateTextVault.encrypt(record.extractedText))) }
                    lines.add(ChatMessage("assistant", "Imported ‘${record.title}’ and extracted ${record.extractedText.length} characters locally (document #$id). Ask me a question about it; relevant excerpts are added to the next AI request."))
                    withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(lines.last().content), conversationId = conversationId, archived = false)) }
                    status = "Document imported · on-device OCR/text extraction"
                } catch (e: Exception) {
                    val error = "Document import failed: ${e.message ?: "unsupported file or extraction error"}"
                    lines.add(ChatMessage("assistant", error))
                    status = "Import failed"
                } finally { busy = false }
            }
        }
    }

    var chatAttachmentText by remember { mutableStateOf("") }
    var chatAttachmentName by remember { mutableStateOf("") }
    var chatAttachmentImageDataUrl by remember { mutableStateOf<String?>(null) }
    val chatAttachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            status = "Reading attachment locally…"
            try {
                val record = DocumentIngestor.import(context, uri)
                chatAttachmentName = record.title
                chatAttachmentText = record.extractedText.take(24_000)
                chatAttachmentImageDataUrl = if (record.mimeType.startsWith("image/")) DocumentIngestor.imageDataUrl(context, uri) else null
                status = if (chatAttachmentImageDataUrl != null) "Attached ${record.title} · image and OCR text will be sent to the selected vision-capable model" else "Attached ${record.title} · ${record.extractedText.length} characters extracted"
            } catch (e: Exception) {
                status = "Attachment failed: ${e.message ?: "unsupported file"}"
            } finally { busy = false }
        }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Copying GGUF model into private storage…"
                try {
                    val file = withContext(Dispatchers.IO) { NativeLlamaRuntime.importModel(context, uri.toString()) }
                    status = "GGUF model imported · ${file.length() / 1_000_000} MB · ready to load on first local prompt"
                    lines.add(ChatMessage("assistant", "Imported local GGUF model: ${NativeLlamaRuntime.activeModelName(context)}. Choose Local LLM and send a prompt to load it. Model loading may fail if the model format or memory requirements are incompatible; ULTRON will report the failure without switching models."))
                } catch (e: Exception) {
                    status = "Model import failed"
                    lines.add(ChatMessage("assistant", "Model import failed: ${e.message ?: "unknown error"}"))
                } finally { busy = false }
            }
        }
    }

    LaunchedEffect(conversationId) {
        runCatching {
            val stored = withContext(Dispatchers.IO) {
                database.chatDao().activeConversation(conversationId, 120)
                    .map { it.copy(content = PrivateTextVault.decrypt(it.content)) }
            }
            if (stored.isNotEmpty()) {
                lines.clear()
                stored.forEach { lines.add(ChatMessage(it.role, it.content)) }
                status = "Restored ${stored.size} messages from this conversation"
            }
        }.onFailure { status = "Chat restore failed: ${it.message ?: "local storage error"}" }
    }

    fun send(promptOverride: String? = null) {
        val typedPrompt = (promptOverride ?: draft).trim()
        val attachedText = chatAttachmentText
        val attachedImage = chatAttachmentImageDataUrl
        val prompt = buildString {
            append(typedPrompt.ifBlank { if (attachedText.isNotBlank()) "Please analyze the attached file and summarize its important contents." else "" })
            if (attachedText.isNotBlank()) append("\n\n[Attached file: ${chatAttachmentName.ifBlank { "document" }}]\n").append(attachedText)
        }.trim()
        if (prompt.isEmpty() || busy) return
        draft = ""
        chatAttachmentText = ""
        chatAttachmentName = ""
        chatAttachmentImageDataUrl = null
        busy = true
        status = "ULTRON is working…"
        activeChatJob = scope.launch {
            try {
                val previousConversationId = conversationId
                val decision = UltronApprovalCommandParser.parse(prompt)
                val pendingId = UltronPendingActionStore.latestId(context)
                val pendingPlan = pendingId?.let { UltronPendingActionStore.load(context, it) }
                if (pendingId != null && pendingPlan != null && decision != null) {
                    lines.add(ChatMessage("user", prompt))
                    val approval = decision == UltronApprovalDecision.APPROVE
                    UltronAgentApprovalReceiver.applyDecision(context, pendingId, approval)
                    val reply = if (approval) "YES received. Your confirmed sensitive task has been queued." else "NO received. The pending task was cancelled."
                    lines.add(ChatMessage("assistant", reply))
                    withContext(Dispatchers.IO) {
                        database.chatDao().insert(ChatRecord(role = "user", content = PrivateTextVault.encrypt(prompt), conversationId = conversationId, archived = false))
                        database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(reply), conversationId = conversationId, archived = false))
                    }
                    status = if (approval) "Confirmation accepted · task queued" else "Confirmation rejected · task cancelled"
                    if (voiceReply) onSpeak(reply)
                    busy = false
                    return@launch
                }
                val nextConversationId = conversationMemory.rolloverIfNeeded(
                    previousConversationId, lines.toList(), prompt, settings.contextWindowTokens
                )
                if (nextConversationId != null) {
                    conversationId = nextConversationId
                    lines.clear()
                    val rolloverNotice = "The context budget was reached. I saved the previous conversation in your private three-day archive and started a fresh chat. I can retrieve relevant details from that archive when needed."
                    lines.add(ChatMessage("assistant", rolloverNotice))
                    withContext(Dispatchers.IO) {
                        database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(rolloverNotice), conversationId = nextConversationId, archived = false))
                    }
                    status = "New chat started · previous conversation archived for 3 days"
                }
                lines.add(ChatMessage("user", prompt, attachedImage))
                val activeSessionId = conversationId
                withContext(Dispatchers.IO) {
                    database.chatDao().insert(ChatRecord(role = "user", content = PrivateTextVault.encrypt(prompt), conversationId = activeSessionId, archived = false))
                }
                // Deterministic, safe commands (time/date, a simple app launch, basic web search)
                // are handled on-device first. They must not fail merely because the online model
                // is temporarily unavailable. Compound/ambiguous commands still go to the agent.
                val quickLocalAction = if (router.isQuickLocalCommand(prompt)) router.handle(prompt) else null
                val resumeRequested = Regex("(?i)^\\s*(?:please\\s+)?(?:resume|continue)\\s+(?:the\\s+)?(?:last|previous)\\s+task[.!?]*$").matches(prompt) || Regex("(?i)^resume the task[.!?]*$").matches(prompt)
                val intelligenceStore = UltronIntelligenceStore(context.applicationContext)
                val interruptedTask = if (resumeRequested) withContext(Dispatchers.IO) { intelligenceStore.loadResumableTask() } else null
                val plannerInput = if (interruptedTask != null) {
                    withContext(Dispatchers.IO) { intelligenceStore.markTaskStatus(interruptedTask.taskId, "interrupted") }
                    """
                    RESUME AN INTERRUPTED ULTRON TASK BY RE-PLANNING FROM THE CURRENT LIVE SCREEN.
                    Original objective: ${interruptedTask.objective.take(1_600)}
                    Previously completed action types (never blindly repeat these): ${interruptedTask.completedActionTypes.joinToString(", ").take(600)}
                    Previous task state: ${interruptedTask.status}; previous package: ${interruptedTask.packageName ?: "unknown"}.
                    Re-inspect the current screen and determine what remains. Do not replay old coordinates or blindly repeat any external commitment. Sensitive actions require fresh approval. If the objective is already complete, return actions=[] and report that.
                    """.trimIndent()
                } else prompt
                val plannedAgent = if (quickLocalAction == null && (UltronMultiAgentCoordinator.shouldRouteToDeviceAgent(prompt) || interruptedTask != null)) {
                    // Do not swallow planner transport errors: surface the real failure instead of
                    // silently falling through and sending a second, different chat prompt.
                    UltronAgentPlanner(context).plan(plannerInput)
                } else null
                val agentPlan = plannedAgent?.takeIf { it.actions.isNotEmpty() }
                val agentResponse = if (resumeRequested && interruptedTask == null) {
                    InferenceResult("There is no paused or interrupted ULTRON task available to resume. Start a task first, or restore the last execution state from the Agent history.", "ULTRON Agent · resume")
                } else if (resumeRequested && interruptedTask != null && agentPlan == null) {
                    val detail = plannedAgent?.summary?.takeIf { it.isNotBlank() }?.let { " Planner note: $it" }.orEmpty()
                    InferenceResult("ULTRON re-inspected the current task context and produced no safe remaining actions. It did not replay saved coordinates or previous action payloads. Check the current app state before starting a new action.$detail", "ULTRON Agent · resume")
                } else if (agentPlan != null) {
                    val executor = UltronAgentExecutor(context)
                    if (executor.requiresApproval(agentPlan)) {
                        withContext(Dispatchers.IO) {
                            val pendingId = java.util.UUID.randomUUID().toString()
                            UltronPendingActionStore.save(context, pendingId, agentPlan)
                            UltronAgentHistoryStore.record(context, UltronAgentHistoryItem(command = agentPlan.summary, status = "awaiting confirmation", total = agentPlan.actions.size, details = agentPlan.actions.map { "${it.type}: ${it.text.ifBlank { it.app.ifBlank { it.message.ifBlank { it.plugin } } }}" }))
                            UltronAgentNotifications.confirm(context, pendingId, agentPlan)
                        }
                        InferenceResult(buildString {
                            append("I prepared ${agentPlan.actions.size} action(s). Review the ULTRON confirmation notification and choose YES to execute or NO to cancel. Nothing sensitive has been done yet.\n")
                            append(agentPlan.summary.take(520))
                        }, "ULTRON Agent · awaiting confirmation")
                    } else {
                        val report = executor.execute(agentPlan, approved = false)
                        withContext(Dispatchers.IO) { UltronAgentHistoryStore.record(context, UltronAgentHistoryItem(command = agentPlan.summary, status = report.historyStatus, completed = report.completed, verified = report.verified, total = report.total, details = report.details)) }
                        InferenceResult(buildString {
                            append(report.displayStatus)
                            append(" · ${report.completed}/${report.total} action(s) completed; ${report.verified} independently verified.\n")
                            append(agentPlan.summary.take(520)).append("\n")
                            report.details.forEach { append(it).append('\n') }
                        }, "ULTRON Agent · action execution")
                    }
                } else null
                val localAction = if (agentResponse == null) quickLocalAction ?: router.handle(prompt) else null
                val manuallySelectedProfile = aiProfiles.firstOrNull { it.id == selectedAiId && it.enabled }
                val selectedProfile = if (UltronAiRoleRouting.isCodingRequest(prompt)) {
                    UltronAiRoleRouting.profileForRole(aiProfiles, "coding") ?: manuallySelectedProfile
                } else manuallySelectedProfile
                val effectiveSettings = if (selectedAiId == "default" || selectedProfile == null) settings else selectedProfile.asSettings()
                val response = agentResponse ?: if (localAction != null) {
                    status = "On-device command"
                    InferenceResult(localAction, "On-device · ULTRON actions")
                } else {
                    val prepared = router.buildMessages(lines.toList(), effectiveSettings.contextWindowTokens)
                    if (settings.mode == InferenceMode.LOCAL) repository.complete(prepared, settings)
                    else if (settings.mode == InferenceMode.HYBRID) {
                        repository.completeHybrid(prepared, settings, selectedProfile, aiProfiles)
                    } else {
                        val defaultProfile = AiEndpointProfile(
                            "default", "General AI", "general", settings.baseUrl, settings.model, settings.apiKey,
                            contextWindowTokens = settings.contextWindowTokens, maxOutputTokens = settings.maxOutputTokens
                        )
                        val configuredProfiles = listOf(defaultProfile) + aiProfiles
                        if (allInOne) repository.completeAllInOne(prepared, configuredProfiles)
                        else if (selectedAiId == "default" || selectedProfile == null) repository.complete(prepared, settings)
                        else repository.completeProfile(prepared, selectedProfile)
                    }
                }
                lines.add(ChatMessage("assistant", response.text))
                withContext(Dispatchers.IO) {
                    database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(response.text), conversationId = activeSessionId, archived = false))
                }
                status = response.provider
                if (voiceReply) onSpeak(response.text)
            } catch (e: kotlinx.coroutines.CancellationException) {
                if (e.message == "Task cancelled by user.") {
                    val stopped = "ULTRON stopped the active task at a safe action boundary. Actions already completed were not rolled back."
                    lines.add(ChatMessage("assistant", stopped))
                    withContext(NonCancellable + Dispatchers.IO) {
                        runCatching { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(stopped), conversationId = conversationId, archived = false)) }
                    }
                    status = "Agent task stopped by user"
                } else {
                    throw e
                }
            } catch (e: Exception) {
                val message = e.message ?: "Unknown inference error"
                val friendly = "ULTRON couldn't complete that request: $message"
                lines.add(ChatMessage("assistant", friendly))
                withContext(Dispatchers.IO) {
                    runCatching { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(friendly), conversationId = conversationId, archived = false)) }
                }
                status = "Action / inference failed · ${message.take(140)}"
            } finally { busy = false; activeChatJob = null }
        }
    }

    LaunchedEffect(externalReply) {
        val reply = externalReply?.trim().orEmpty()
        if (reply.isNotBlank()) {
            lines.add(ChatMessage("assistant", reply))
            MainActivity.externalReplies.value = null
        }
    }

    LaunchedEffect(pendingWakeCommand) {
        val command = pendingWakeCommand?.trim().orEmpty()
        if (command.isNotBlank()) {
            MainActivity.voiceCommands.value = null
            activeTab = "CHAT"
            send(command)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Orange, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        var showBootSplash by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { delay(3_200); showBootSplash = false }
        Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16090D), Night, Color(0xFF08090D))))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ULTRON", color = Crimson, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("YOUR AI. YOUR COMMANDS.", color = Orange, fontSize = 9.sp, letterSpacing = 1.8.sp)
                }
                Surface(color = Color(0xFF102116), shape = RoundedCornerShape(30.dp), border = BorderStroke(1.dp, Color(0xFF35C76B).copy(alpha=.65f))) {
                    Row(Modifier.padding(horizontal=10.dp, vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).background(Color(0xFF39E878), RoundedCornerShape(50)))
                        Spacer(Modifier.width(6.dp)); Text(if (busy) "WORKING" else when (settings.mode) { InferenceMode.LOCAL -> "OFFLINE"; InferenceMode.HYBRID -> "HYBRID"; InferenceMode.ONLINE -> if (settings.baseUrl.isBlank()) "SETUP" else "ONLINE" }, color=if (settings.mode == InferenceMode.LOCAL) Purple else if (settings.mode == InferenceMode.HYBRID) Orange else Color(0xFF72E99A), fontSize=9.sp, fontWeight=FontWeight.Bold)
                    }
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Orange) }
            }
            when (activeTab) {
                "HOME" -> DashboardScreen(
                    modifier = Modifier.weight(1f), mode = when (settings.mode) { InferenceMode.LOCAL -> "OFFLINE"; InferenceMode.HYBRID -> "HYBRID"; InferenceMode.ONLINE -> if (allInOne) "ALL-IN-ONE" else (aiProfiles.firstOrNull { it.id == selectedAiId }?.name ?: "GENERAL AI") }, status = status,
                    selectedAiName = when (settings.mode) { InferenceMode.LOCAL -> "OFFLINE MODEL"; InferenceMode.HYBRID -> "HYBRID · AUTO FAILOVER"; InferenceMode.ONLINE -> if (allInOne) "ALL-IN-ONE" else (aiProfiles.firstOrNull { it.id == selectedAiId }?.name ?: "GENERAL AI") },
                    aiNames = listOf("General AI") + aiProfiles.map { it.name } + listOf("All-in-One"),
                    onSelectAi = { name ->
                        settings = settings.copy(mode = InferenceMode.ONLINE); onSaveSettings(settings)
                        allInOne = name == "All-in-One"
                        if (!allInOne) {
                            selectedAiId = if (name == "General AI") "default" else aiProfiles.firstOrNull { it.name == name }?.id ?: "default"
                            aiProfileStore.setActiveProfileId(selectedAiId)
                        }
                    },
                    onChat = { activeTab = "CHAT" },
                    onVoice = { activeTab = "VOICE"; runCatching { speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")) }.onFailure { status = "Speech recognizer unavailable" } },
                    onVision = { onAction("Camera") }, onBrowser = { onAction("Browser") },
                    onMemory = { activeTab = "MEMORY" }, onModels = { activeTab = "MODELS" },
                    onSecurity = { accessRefresh++; showAccess = true }, onPlugins = { activeTab = "PLUGINS" }, onCapabilities = { activeTab = "CAPABILITIES" }
                )
                "CHAT" -> Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text("AI CHAT", color=Crimson, fontSize=16.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                        IconButton(enabled = !busy, onClick = {
                            scope.launch {
                                val nextId = conversationMemory.archiveAndStartNew(conversationId, lines.toList())
                                conversationId = nextId
                                lines.clear()
                                val note = "A new conversation is ready. Your previous chat has been saved in the private archive for three days."
                                lines.add(ChatMessage("assistant", note))
                                withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(note), conversationId = nextId, archived = false)) }
                                status = "New conversation started · previous chat archived"
                            }
                        }) { Icon(Icons.Default.Add, contentDescription = "New chat", tint = Orange) }
                        Text(when (settings.mode) { InferenceMode.LOCAL -> "OFFLINE · ${NativeLlamaRuntime.activeModelName(context)}"; InferenceMode.HYBRID -> "HYBRID · ONLINE → PROVIDER FAILOVER → LOCAL"; InferenceMode.ONLINE -> if (allInOne) "ALL-IN-ONE DEBATE" else (aiProfiles.firstOrNull { it.id == selectedAiId }?.name ?: "GENERAL AI") }, color=Orange, fontSize=10.sp)
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(lines) { line ->
                            val isUser = line.role == "user"
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                                Column(Modifier.widthIn(max = 380.dp), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        if (!isUser) Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Orange, modifier = Modifier.size(12.dp))
                                        Text(if (isUser) "YOU" else "ULTRON · NEURAL RESPONSE", color = if (isUser) Crimson else Purple, fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
                                    }
                                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(if (isUser) 19.dp else 19.dp)).background(
                                        if (isUser) Brush.linearGradient(listOf(Color(0xFF641722), Color(0xFF32111D))) else Brush.linearGradient(listOf(Color(0xFF1A1822), Color(0xFF111117)))
                                    ).border(1.dp, Brush.linearGradient(if (isUser) listOf(Crimson, Orange.copy(alpha=.55f)) else listOf(Purple.copy(alpha=.75f), Color(0xFF55303A))), RoundedCornerShape(19.dp)).padding(14.dp)) {
                                        Text(line.content, color=Color(0xFFF5F0F2), fontSize=14.sp, lineHeight=21.sp)
                                    }
                                }
                            }
                        }
                        if (busy) item { Text("ULTRON IS THINKING…", color=Orange, fontSize=11.sp) }
                    }
                    if (chatAttachmentName.isNotBlank()) {
                        Row(Modifier.fillMaxWidth().padding(bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AttachFile, null, tint = Orange, modifier = Modifier.size(15.dp))
                            Text(chatAttachmentName, color = Purple, fontSize = 10.sp, modifier = Modifier.weight(1f), maxLines = 1)
                            TextButton(onClick = { chatAttachmentName = ""; chatAttachmentText = ""; chatAttachmentImageDataUrl = null }) { Text("REMOVE", color = Crimson, fontSize = 9.sp) }
                        }
                    }
                    Row(Modifier.fillMaxWidth().background(Color(0xFF171219), RoundedCornerShape(28.dp)).border(1.dp, Color(0xFF4B2634), RoundedCornerShape(28.dp)).padding(horizontal=5.dp, vertical=5.dp), verticalAlignment=Alignment.CenterVertically) {
                        IconButton(onClick = { chatAttachmentPicker.launch(arrayOf("*/*")) }, enabled = !busy) { Icon(Icons.Default.Add, "Attach file", tint=Orange) }
                        Box(Modifier.weight(1f).padding(horizontal=8.dp)) { if (draft.isEmpty()) Text(if (chatAttachmentName.isNotBlank()) "Ask about ${chatAttachmentName}…" else "Message ULTRON…", color=Color.Gray, fontSize=13.sp); BasicTextField(draft, { draft=it }, Modifier.fillMaxWidth(), textStyle=androidx.compose.ui.text.TextStyle(color=Color.White,fontSize=14.sp), maxLines=5) }
                        if (busy && activeChatJob != null) {
                            Surface(
                                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(9.dp)).clickable {
                                    activeChatJob?.cancel(CancellationException("Task cancelled by user."))
                                }, color = Crimson, shape = RoundedCornerShape(9.dp), border = BorderStroke(1.dp, Orange.copy(alpha=.7f))
                            ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Stop, "Stop generation", tint = Color.White) } }
                        } else {
                            IconButton(onClick={send()}, enabled=!busy && (draft.isNotBlank() || chatAttachmentText.isNotBlank())) { Icon(Icons.Default.Send, "Send", tint=Orange) }
                        }
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("Voice replies", color=Color.LightGray, fontSize=10.sp); Switch(checked=voiceReply,onCheckedChange={voiceReply=it}); Spacer(Modifier.weight(1f)); Text("Auto-rollover · 3-day encrypted archive", color=Purple,fontSize=9.sp) }
                }
                "VOICE" -> VoiceFeatureScreen(modifier=Modifier.weight(1f), onStart={
                    val toRequest = mutableListOf<String>()
                    if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) toRequest += android.Manifest.permission.RECORD_AUDIO
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) toRequest += android.Manifest.permission.POST_NOTIFICATIONS
                    if (toRequest.isNotEmpty()) {
                        wakeStartPermissionRequested = true
                        runtimePermissions.launch(toRequest.toTypedArray())
                    } else runCatching {
                        val wake=Intent(context,UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START)
                        if(Build.VERSION.SDK_INT>=26) ContextCompat.startForegroundService(context,wake) else context.startService(wake)
                        status="Wake-word service requested · saved for reboot resume"
                    }.onFailure { status="Wake-word start failed: ${it.message}" }
                }, onStop={ UltronWakeWordPreferences.setEnabled(context, false); UltronWakeWordPreferences.setBootResumePending(context, false); context.stopService(Intent(context,UltronWakeWordService::class.java)); status="Wake-word service stopped · auto-resume disabled" }, onSpeak={ activeTab="CHAT" })
                "PLUGINS" -> PluginHubScreen(Modifier.weight(1f), onOpen = { onAction("URL:$it") })
                "MODELS" -> OfflineModelScreen(
                    Modifier.weight(1f), enabled = settings.mode != InferenceMode.ONLINE,
                    onEnabled = { enabled ->
                        if (enabled && (NativeLlamaRuntime.activeModelPath(context) == null || !NativeLlamaRuntime.isAvailable())) status = "Import a GGUF model and use a successful native build before enabling Offline AI"
                        else { settings = settings.copy(mode = if (enabled) InferenceMode.LOCAL else InferenceMode.ONLINE); onSaveSettings(settings); status = if (enabled) "Offline AI enabled" else "Online AI selected" }
                    },
                    modelStatus = LocalModelStore(context).status(),
                    onFindQwen = { onAction("URL:https://huggingface.co/models?search=Qwen3.5-4B-Amadeus-GGUF") },
                    onImport = { modelPicker.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*")) },
                    onDownload = { url -> scope.launch {
                        busy = true; status = "Downloading GGUF into private storage…"
                        try {
                            val file = withContext(Dispatchers.IO) { NativeLlamaRuntime.downloadModel(context, url) }
                            status = "Offline model downloaded and installed · ${file.length() / 1_000_000} MB"
                        } catch (e: Exception) { status = "Model download failed: ${e.message}" }
                        finally { busy = false }
                    } },
                    onDelete = { NativeLlamaRuntime.deleteModel(context); status = "Offline model deleted" }
                )
                "MEMORY" -> MemoryVaultScreen(Modifier.weight(1f), database)
                "CAPABILITIES" -> AdvancedCapabilitiesScreen(Modifier.weight(1f), context)
                else -> SimpleFeatureScreen(Modifier.weight(1f), activeTab, "ULTRON SYSTEM MODULE", listOf("InstaBox online AI configuration", "Optional offline GGUF model", "Permissions and device access", "Biometric app lock"), status)
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF100D12)).padding(horizontal=5.dp, vertical=7.dp), horizontalArrangement=Arrangement.SpaceEvenly, verticalAlignment=Alignment.CenterVertically) {
                BottomNavItem(Icons.Default.Home, "HOME", activeTab=="HOME") { activeTab="HOME" }
                BottomNavItem(Icons.Default.Chat, "CHAT", activeTab=="CHAT") { activeTab="CHAT" }
                BottomNavItem(Icons.Default.Mic, "VOICE", activeTab=="VOICE") { activeTab="VOICE" }
                BottomNavItem(Icons.Default.GridView, "MODULES", activeTab=="PLUGINS") { activeTab="PLUGINS" }
                BottomNavItem(Icons.Default.Settings, "SETTINGS", false) { showSettings=true }
            }
        }

        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("ULTRON · Inference settings", color = Crimson) },
            text = {
                Column(Modifier.heightIn(max = 640.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("INFERENCE ROUTING", color = Orange, fontWeight = FontWeight.Bold)
                    Text("ULTRON uses the saved routing configuration automatically. Online gateway and specialist profiles are managed below; local model management remains in Model Manager. Mode switching controls are hidden until their runtime paths are verified.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
                    Text("INSTABOX CLOUD COMPUTERS · ACCOUNT CONNECTION", color = Orange, fontWeight = FontWeight.Bold)
                    var instaBoxKey by remember { mutableStateOf(InstaBoxConnectionStore.loadKey(context)) }
                    var instaBoxCheck by remember { mutableStateOf("Not connected · enter an InstaBox API key (ibk_…)") }
                    var instaBoxBusy by remember { mutableStateOf(false) }
                    OutlinedTextField(value = instaBoxKey, onValueChange = { instaBoxKey = it }, label = { Text("InstaBox API key (ibk_…)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
                    Text("This authenticates directly with api.instabox.sh and checks machines in your workspace. It is separate from your model-provider URL and does not create or start a billable machine.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
                    OutlinedButton(onClick = {
                        if (instaBoxBusy) return@OutlinedButton
                        instaBoxBusy = true
                        instaBoxCheck = "Checking InstaBox API authentication…"
                        scope.launch {
                            val result = runCatching { withContext(Dispatchers.IO) { InstaBoxApi.checkAccount(instaBoxKey) } }
                            result.onSuccess {
                                InstaBoxConnectionStore.saveKey(context, instaBoxKey)
                                instaBoxCheck = it.summary
                                status = "InstaBox authenticated · ${it.machines.size} machine(s) visible"
                            }.onFailure {
                                instaBoxCheck = "Connection failed · ${it.message ?: "unknown error"}"
                                status = instaBoxCheck
                            }
                            instaBoxBusy = false
                        }
                    }, enabled = !instaBoxBusy && instaBoxKey.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (instaBoxBusy) "CHECKING INSTABOX…" else "VERIFY INSTABOX API KEY") }
                    Text(instaBoxCheck, color = if (instaBoxCheck.startsWith("Authenticated")) Color(0xFF70D99A) else Color(0xFFFFC477), fontSize = 10.sp)
                    OutlinedButton(onClick = { InstaBoxConnectionStore.saveKey(context, ""); instaBoxKey = ""; instaBoxCheck = "InstaBox API key removed from this device." }, modifier = Modifier.fillMaxWidth()) { Text("DISCONNECT INSTABOX") }
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Text("ONLINE AI · OPENAI-COMPATIBLE MODEL GATEWAY", color = Orange, fontWeight = FontWeight.Bold)
                    Text("Offline AI is managed separately in Dashboard → Model Manager. Online profiles remain independent.", color = Color.LightGray, fontSize = 10.sp)
                    OutlinedTextField(value = settings.baseUrl, onValueChange = { settings = settings.copy(baseUrl = it) }, label = { Text("LLM API base URL (e.g. https://host/v1)") }, singleLine = true)
                    OutlinedTextField(value = settings.model, onValueChange = { settings = settings.copy(model = it) }, label = { Text("Model ID") }, singleLine = true)
                    OutlinedTextField(value = settings.apiKey, onValueChange = { settings = settings.copy(apiKey = it) }, label = { Text("API token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                    Text("GENERAL AI · CONTEXT CONTROL", color = Orange, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    OutlinedTextField(value = contextWindowText, onValueChange = { contextWindowText = it.filter { ch -> ch.isDigit() }.take(5) }, label = { Text("App context budget (tokens)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = maxOutputText, onValueChange = { maxOutputText = it.filter { ch -> ch.isDigit() }.take(4) }, label = { Text("Maximum reply tokens") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Text("This controls how much ULTRON sends and how much it asks the model to generate. It cannot enlarge the server's runtime n_ctx. Set the InstaBox model server n_ctx to at least this context value; your current server reported 4096.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
                    OutlinedButton(onClick = {
                        scope.launch {
                            status = "Testing General AI from this Android device…"
                            val probe = runCatching {
                                repository.complete(
                                    listOf(ChatMessage("user", "Reply with exactly: ULTRON_CONNECTION_OK")),
                                    settings.copy(mode = InferenceMode.ONLINE, maxOutputTokens = 64)
                                )
                            }
                            status = probe.fold(
                                onSuccess = { "General AI connection successful · ${it.provider} · ${it.text.take(80)}" },
                                onFailure = { "General AI connection failed · ${it.message ?: "unknown error"}" }
                            )
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("TEST GENERAL AI CONNECTION") }
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Text("MULTI-AI NETWORK", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("General AI uses the model gateway above. Add Coding, Vision, or any custom AI with its own OpenAI-compatible URL, model path and key. InstaBox cloud computers are connected separately below.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("All-in-One debate mode", color = Color.White, fontWeight = FontWeight.SemiBold); Text("Parallel answers → peer review → final synthesis. Requires at least two working profiles.", color = Color.LightGray, fontSize = 9.sp) }
                        Switch(checked = allInOne, onCheckedChange = { allInOne = it })
                    }
                    aiProfiles.forEach { profile ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selectedAiId == profile.id, onClick = { selectedAiId = profile.id; aiProfileStore.setActiveProfileId(profile.id); allInOne = false })
                            Column(Modifier.weight(1f)) { Text(profile.name, color = Color.White, fontSize = 12.sp); Text("${profile.role} · ${profile.model}", color = Color.LightGray, fontSize = 9.sp) }
                            TextButton(onClick = { aiProfiles = aiProfiles.filterNot { it.id == profile.id }; aiProfileStore.save(aiProfiles); if (selectedAiId == profile.id) { selectedAiId = "default"; aiProfileStore.setActiveProfileId("default") } }) { Text("REMOVE", color = Crimson, fontSize = 9.sp) }
                        }
                    }
                    OutlinedTextField(value = profileName, onValueChange = { profileName = it }, label = { Text("New AI name (e.g. Coding)") }, singleLine = true)
                    OutlinedTextField(value = profileRole, onValueChange = { profileRole = it }, label = { Text("AI role (general / coding / vision / custom)") }, singleLine = true)
                    OutlinedTextField(value = profileUrl, onValueChange = { profileUrl = it }, label = { Text("AI gateway base URL ending in /v1") }, singleLine = true)
                    OutlinedTextField(value = profileModel, onValueChange = { profileModel = it }, label = { Text("Exact model path / ID") }, singleLine = true)
                    OutlinedTextField(value = profileKey, onValueChange = { profileKey = it }, label = { Text("AI API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                    Button(onClick = {
                        if (profileName.isBlank() || profileUrl.isBlank() || profileModel.isBlank()) status = "Enter AI name, gateway URL and model ID first"
                        else runCatching {
                            val profile = AiEndpointProfile(java.util.UUID.randomUUID().toString(), profileName.trim(), profileRole.trim().ifBlank { "custom" }, profileUrl.trim(), profileModel.trim(), profileKey.trim())
                            aiProfiles = aiProfiles + profile
                            aiProfileStore.save(aiProfiles)
                            selectedAiId = profile.id; aiProfileStore.setActiveProfileId(profile.id); allInOne = false
                            profileName = ""; profileUrl = ""; profileModel = ""; profileKey = ""
                            status = "Added ${profile.name} AI profile"
                        }.onFailure { status = "Could not save AI profile: ${it.message}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("ADD ONLINE AI PROFILE") }
                    Text("Expected route: POST {base URL}/chat/completions. Enter an actual OpenAI-compatible inference server, exact model path/name and its provider API key. Do not enter api.instabox.sh here: that is the separate cloud-computer API, connected above. A sandbox-hosted model worker can still return 502 if that worker is stopped or disconnected.", color = Color.LightGray, fontSize = 11.sp)

                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Text("LIVE SCREEN UNDERSTANDING · VISION → GENERAL AI", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Start Android's screen-capture consent once per session. ULTRON keeps only a short-lived frame in memory. With cloud sharing enabled, the current image goes to the configured Vision-role endpoint; its visual description goes to the General planner. The current accessibility text/control snapshot is also shared with General for that task. Secure windows may remain blank. Do not enable cloud sharing on screens containing information you do not want sent to these providers.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Share live screen frames with Vision AI", color = Color.White, fontSize = 12.sp)
                            Text("Separate opt-in · off by default", color = Color.LightGray, fontSize = 9.sp)
                        }
                        Switch(checked = shareScreenWithVision, onCheckedChange = {
                            shareScreenWithVision = it
                            UltronScreenCaptureStore.setCloudVisionEnabled(context, it)
                            status = if (it) "Cloud screen analysis enabled · frames go only to the configured Vision profile" else "Cloud screen analysis disabled · screen frames remain local"
                        })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { onAction("SCREEN_CAPTURE_START"); status = "Waiting for Android screen-capture approval…" }, modifier = Modifier.weight(1f)) { Text("START SCREEN AWARENESS", fontSize = 9.sp) }
                        OutlinedButton(onClick = { onAction("SCREEN_CAPTURE_STOP"); screenCaptureActive = false; status = "Screen awareness stop requested" }, modifier = Modifier.weight(1f)) { Text("STOP", fontSize = 9.sp) }
                    }
                    Text(if (screenCaptureActive) "CAPTURE STATUS · ACTIVE" else "CAPTURE STATUS · INACTIVE", color = if (screenCaptureActive) Color(0xFF58D68D) else Color.LightGray, fontSize = 9.sp)
                    Text("Role routing: configure a General profile (or main endpoint), an image-capable Vision profile, and a Coding profile. General AI plans actions, Vision AI describes live screenshots, and Coding AI handles coding conversations. Live screenshot analysis requires Online or Hybrid mode, screen-capture consent and the separate cloud-sharing switch. The planner treats screen content as untrusted evidence, never instructions.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)

                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Biometric / device-credential app lock", color = Color.White)
                            Text("Locks ULTRON when it leaves the foreground. Android 11+ can use strong biometrics or your device credential; older Android versions require enrolled biometrics.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                        }
                        Switch(checked = appLockOn, onCheckedChange = { requested ->
                            if (onSetAppLock(requested)) appLockOn = requested
                            else status = "App lock not changed: set up a supported biometric/device credential in Android settings first."
                        })
                    }
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Text("ULTRON SPOKEN VOICE", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Choose the language and preferred voice presentation for ULTRON's spoken replies. Available voices depend on the Text-to-Speech engine installed on this phone.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("LANGUAGE", color = Color.LightGray, fontSize = 9.sp)
                            var languageMenu by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(onClick = { languageMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(if (voiceLanguage == "hi-IN") "Hindi" else "English", fontSize = 11.sp) }
                                DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                                    DropdownMenuItem(text = { Text("English (India)") }, onClick = { voiceLanguage = "en-IN"; languageMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                    DropdownMenuItem(text = { Text("English (US)") }, onClick = { voiceLanguage = "en-US"; languageMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                    DropdownMenuItem(text = { Text("Hindi (India)") }, onClick = { voiceLanguage = "hi-IN"; languageMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                }
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            Text("VOICE STYLE", color = Color.LightGray, fontSize = 9.sp)
                            var genderMenu by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(onClick = { genderMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(if (voiceGender == "male") "Male" else "Female", fontSize = 11.sp) }
                                DropdownMenu(expanded = genderMenu, onDismissRequest = { genderMenu = false }) {
                                    DropdownMenuItem(text = { Text("Male") }, onClick = { voiceGender = "male"; genderMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                    DropdownMenuItem(text = { Text("Female") }, onClick = { voiceGender = "female"; genderMenu = false; voiceStatus = onVoiceSettingsChanged(voiceLanguage, voiceGender) })
                                }
                            }
                        }
                    }
                    Text(voiceStatus, color = Purple, fontSize = 10.sp, lineHeight = 13.sp)
                    OutlinedButton(onClick = { onSpeak(if (voiceLanguage.startsWith("hi")) "नमस्ते। मैं अल्ट्रॉन हूँ। मैं आपकी कैसे सहायता कर सकता हूँ?" else "Hello. I am ULTRON. How can I assist you?") }, modifier = Modifier.fillMaxWidth()) { Text("TEST SELECTED VOICE") }
                    OutlinedButton(onClick = { onAction("TTS_INSTALL") }, modifier = Modifier.fillMaxWidth()) { Text("INSTALL / DOWNLOAD VOICE DATA") }
                    Text("Voice packages are supplied by your installed Android speech engine. Use this installer to download supported Hindi and English voices; ULTRON selects the closest available male/female voice and reports when the engine does not expose that choice.", color = Color.LightGray, fontSize = 9.sp, lineHeight = 13.sp)
                    Text("VOICE WAKE WORD", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Persistent, user-opt-in foreground listener. It prefers on-device recognition when the phone supports it and requests offline recognition elsewhere. ULTRON remembers your choice across app closure and reboot; Android 14+ requires one tap on the post-reboot resume notification before microphone capture can restart. An ongoing notification always provides Stop.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            val toRequest = mutableListOf<String>()
                            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) toRequest += android.Manifest.permission.RECORD_AUDIO
                            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) toRequest += android.Manifest.permission.POST_NOTIFICATIONS
                            if (toRequest.isNotEmpty()) {
                                wakeStartPermissionRequested = true
                                runtimePermissions.launch(toRequest.toTypedArray())
                            } else runCatching {
                                val wake = Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START)
                                if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(context, wake) else context.startService(wake)
                                status = "Wake-word listener requested · check its ongoing notification"
                            }.onFailure { status = "Could not start wake-word listener: ${it.message}" }
                        }, modifier = Modifier.weight(1f)) { Text("Start listening", fontSize = 11.sp) }
                        OutlinedButton(onClick = {
                            UltronWakeWordPreferences.setEnabled(context, false)
                            UltronWakeWordPreferences.setBootResumePending(context, false)
                            context.stopService(Intent(context, UltronWakeWordService::class.java))
                            status = "Wake-word listener stopped · auto-resume disabled"
                        }, modifier = Modifier.weight(1f)) { Text("Stop", fontSize = 11.sp) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Speak replies", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = voiceReply, onCheckedChange = { voiceReply = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val requestedContext = contextWindowText.toIntOrNull()?.coerceIn(2048, 32768) ?: 4096
                    val requestedOutput = maxOutputText.toIntOrNull()?.coerceIn(64, 1024) ?: 256
                    settings = settings.copy(
                        baseUrl = settings.baseUrl.trim().trimEnd('/'), model = settings.model.trim(),
                        contextWindowTokens = requestedContext, maxOutputTokens = requestedOutput
                    )
                    contextWindowText = requestedContext.toString()
                    maxOutputText = requestedOutput.toString()
                    runCatching { onSaveSettings(settings) }
                        .onSuccess { status = "Saved ${settings.mode} settings"; showSettings = false }
                        .onFailure { status = "Could not securely save token: ${it.message}" }
                }) { Text("Save settings") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } },
            containerColor = Panel
        )

        if (showAccess) {
            val itemsNow = remember(accessRefresh, context) { AndroidAccess.items(context) }
            androidx.compose.ui.window.Dialog(onDismissRequest = { showAccess = false }) {
                Surface(modifier = Modifier.fillMaxWidth().heightIn(max = 660.dp), color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .5f))) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ULTRON · Permission center", color = Crimson, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Enable only the access you want to use.", color = Color.LightGray, fontSize = 11.sp)
                            }
                            IconButton(onClick = { accessRefresh++ }) { Icon(Icons.Default.Refresh, "Refresh permission statuses", tint = Orange) }
                        }
                        HorizontalDivider(color = Crimson.copy(alpha = .35f))
                        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(itemsNow) { item ->
                                Surface(color = Color(0xFF171B22), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text(item.description, color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                                            Text(if (item.granted) "ENABLED" else "NOT ENABLED", color = if (item.granted) Color(0xFF9AD6A5) else Orange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                        if (item.action.startsWith("runtime:")) {
                                            TextButton(onClick = {
                                                val permission = item.action.removePrefix("runtime:")
                                                if (item.granted) onOpenSpecialSetting("app_permissions")
                                                else if (permission == android.Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33) {
                                                    status = "Notification runtime permission is not required on this Android version"
                                                } else runtimePermissions.launch(arrayOf(permission))
                                            }) { Text(if (item.granted) "Review" else "Grant", color = Orange) }
                                        } else TextButton(onClick = { onOpenSpecialSetting(item.action.removePrefix("settings:")); accessRefresh++ }) { Text(if (item.granted) "Open" else "Enable", color = Orange) }
                                    }
                                }
                            }
                        }
                        Text("Accessibility and notification access are powerful. ULTRON reads screen text only when you command it and does not save notification message contents. Device admin does not provide root access.", color = Purple, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 8.dp))
                        TextButton(onClick = { accessRefresh++; showAccess = false }) { Text("Done", color = Crimson) }
                    }
                }
            }
        }
    }
        if (showBootSplash) {
            Box(Modifier.fillMaxSize().background(Color(0xFF05040A)), contentAlignment = Alignment.Center) {
                AndroidView(factory = { viewContext -> UltronGifView(viewContext, R.raw.ultron_startup, cropToFill = true) }, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x4405040A), Color(0x1105040A), Color(0xCC05040A)))))
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 76.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("ULTRON", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
                    Text("NEURAL CORE INITIALIZING", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("VOICE COMMAND SYSTEM · READYING", color = Color(0xFFE1D4E9), fontSize = 9.sp, letterSpacing = 1.3.sp)
                    CircularProgressIndicator(color = Crimson, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                }
            }
        }
    }
}

@Composable
private fun MemoryVaultScreen(modifier: Modifier = Modifier, database: UltronDatabase) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var memories by remember { mutableStateOf<List<MemoryRecord>>(emptyList()) }
    var notes by remember { mutableStateOf<List<NoteRecord>>(emptyList()) }
    var documents by remember { mutableStateOf<List<DocumentRecord>>(emptyList()) }
    var archives by remember { mutableStateOf<List<ChatArchiveRecord>>(emptyList()) }
    var agentHistory by remember { mutableStateOf<List<UltronAgentHistoryItem>>(emptyList()) }
    var chats by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Loading private memory…") }
    var refresh by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    val q = search.trim().lowercase(Locale.ROOT)
    val visibleMemories = memories.filter { it.value.lowercase(Locale.ROOT).contains(q) }
    val visibleNotes = notes.filter { it.title.lowercase(Locale.ROOT).contains(q) || it.body.lowercase(Locale.ROOT).contains(q) }
    val visibleDocuments = documents.filter { it.title.lowercase(Locale.ROOT).contains(q) || it.extractedText.lowercase(Locale.ROOT).contains(q) }
    val visibleArchives = archives.filter { it.summary.lowercase(Locale.ROOT).contains(q) }
    fun reload() {
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val m = database.memoryDao().all().map { it.copy(value = runCatching { PrivateTextVault.decrypt(it.value) }.getOrDefault("[Unable to decrypt item]")) }
                    val n = database.noteDao().latest(40).map { it.copy(title = runCatching { PrivateTextVault.decrypt(it.title) }.getOrDefault("Private note"), body = runCatching { PrivateTextVault.decrypt(it.body) }.getOrDefault("[Unable to decrypt note]")) }
                    val d = database.documentDao().latest(40).map { it.copy(title = runCatching { PrivateTextVault.decrypt(it.title) }.getOrDefault("Imported document"), extractedText = runCatching { PrivateTextVault.decrypt(it.extractedText) }.getOrDefault("")) }
                    val c = database.chatDao().latest(500).size
                    val a = database.chatDao().recentArchives(System.currentTimeMillis(), 40).map {
                        it.copy(summary = runCatching { PrivateTextVault.decrypt(it.summary) }.getOrDefault("[Unable to decrypt archived conversation]"))
                    }
                    listOf(m, n, d, c, a)
                }
                @Suppress("UNCHECKED_CAST")
                memories = result[0] as List<MemoryRecord>
                @Suppress("UNCHECKED_CAST")
                notes = result[1] as List<NoteRecord>
                @Suppress("UNCHECKED_CAST")
                documents = result[2] as List<DocumentRecord>
                chats = result[3] as Int
                @Suppress("UNCHECKED_CAST")
                archives = result[4] as List<ChatArchiveRecord>
                agentHistory = withContext(Dispatchers.IO) { UltronAgentHistoryStore.load(context) }
                status = "Private data loaded from this device"
            } catch (e: Exception) { status = "Memory could not be loaded: ${e.message ?: "storage error"}" }
        }
    }
    LaunchedEffect(refresh) { reload() }
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("MEMORY CORE", color = Crimson, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
        Text("PRIVATE KNOWLEDGE VAULT · ON DEVICE", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(status, color = Purple, fontSize = 10.sp)
        OutlinedTextField(
            value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Search memories, notes, documents and archived chats") }, singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Orange) }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MemoryMetric("FACTS", memories.size.toString(), Modifier.weight(1f))
            MemoryMetric("NOTES", notes.size.toString(), Modifier.weight(1f))
            MemoryMetric("DOCUMENTS", documents.size.toString(), Modifier.weight(1f))
            MemoryMetric("CHATS", chats.toString(), Modifier.weight(1f))
        }
        MemorySection("SAVED KNOWLEDGE", visibleMemories.isEmpty()) {
            if (visibleMemories.isEmpty()) Text(if (q.isBlank()) "No facts saved yet. Say ‘remember that …’ in chat to add a memory." else "No matching saved facts.", color=Color.LightGray, fontSize=11.sp)
            visibleMemories.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("• ${item.value}", color=Color.White, fontSize=12.sp, lineHeight=17.sp, modifier=Modifier.weight(1f))
                    IconButton(onClick = { scope.launch { withContext(Dispatchers.IO) { database.memoryDao().deleteByKey(item.key) }; refresh++ } }) { Icon(Icons.Default.Delete, contentDescription = "Delete memory", tint = Crimson) }
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        MemorySection("PRIVATE NOTES", visibleNotes.isEmpty()) {
            if (visibleNotes.isEmpty()) Text(if (q.isBlank()) "No notes saved. Use ‘note: …’ in chat to create one." else "No matching private notes.", color=Color.LightGray, fontSize=11.sp)
            visibleNotes.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(item.title, color=Orange, fontWeight=FontWeight.Bold, fontSize=12.sp); Text(item.body, color=Color.White, fontSize=11.sp, lineHeight=16.sp) }
                    IconButton(onClick = { scope.launch { withContext(Dispatchers.IO) { database.noteDao().delete(item.id) }; refresh++ } }) { Icon(Icons.Default.Delete, contentDescription = "Delete note", tint = Crimson) }
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        MemorySection("IMPORTED DOCUMENTS", visibleDocuments.isEmpty()) {
            if (visibleDocuments.isEmpty()) Text(if (q.isBlank()) "No imported documents yet. Import documents from the document tools to build persistent knowledge." else "No matching imported documents.", color=Color.LightGray, fontSize=11.sp)
            visibleDocuments.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(item.title, color=Color.White, fontWeight=FontWeight.Bold, fontSize=12.sp); Text("${item.mimeType} · ${item.extractedText.length} extracted characters", color=Purple, fontSize=10.sp) }
                    IconButton(onClick = { scope.launch { withContext(Dispatchers.IO) { database.documentDao().delete(item.id) }; refresh++ } }) { Icon(Icons.Default.Delete, contentDescription = "Delete document", tint = Crimson) }
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        MemorySection("THREE-DAY CONVERSATION ARCHIVE", visibleArchives.isEmpty()) {
            if (visibleArchives.isEmpty()) Text(if (q.isBlank()) "No conversations have been archived yet. ULTRON automatically saves a conversation here when its context budget is reached, or when you start a new chat." else "No matching archived conversations.", color=Color.LightGray, fontSize=11.sp)
            visibleArchives.forEach { item ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${item.messageCount} messages", color=Orange, fontSize=10.sp, modifier=Modifier.weight(1f))
                        Text("Expires ${java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(item.expiresAt))}", color=Purple, fontSize=8.sp)
                        IconButton(onClick = { scope.launch { withContext(Dispatchers.IO) { database.withTransaction { database.chatDao().deleteConversation(item.conversationId); database.chatDao().deleteArchive(item.conversationId) } }; refresh++ } }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete archived conversation", tint = Crimson)
                        }
                    }
                    Text(item.summary.take(1_800), color=Color.White, fontSize=10.sp, lineHeight=14.sp)
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        MemorySection("AGENT ACTIVITY · LOCAL AUDIT", agentHistory.isEmpty()) {
            if (agentHistory.isEmpty()) Text("No agent actions recorded yet. Device commands and confirmation decisions will appear here.", color=Color.LightGray, fontSize=11.sp)
            agentHistory.take(12).forEach { item ->
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(item.status.uppercase(), color = if (item.status.contains("completed")) Orange else Purple, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(item.createdAt)), color=Color.LightGray, fontSize=8.sp)
                    }
                    Text(item.command.ifBlank { "ULTRON action plan" }, color=Color.White, fontSize=11.sp)
                    if (item.total > 0) Text("${item.completed}/${item.total} actions accepted · ${item.verified} verified", color=Purple, fontSize=9.sp)
                    item.details.take(4).forEach { Text("· $it", color=Color.LightGray, fontSize=9.sp, lineHeight=12.sp) }
                }
                Divider(color=Color(0xFF3A2028))
            }
        }
        NeonAction("REFRESH MEMORY", Icons.Default.Refresh, { refresh++ }, Modifier.fillMaxWidth())
        NeonAction("DELETE SAVED FACTS", Icons.Default.Delete, {
            scope.launch { withContext(Dispatchers.IO) { database.memoryDao().clear() }; refresh++ }
        }, Modifier.fillMaxWidth())
        Text("Archived chats and their encrypted summaries expire 72 hours after archiving. ULTRON retrieves only relevant archive excerpts for later AI requests. Saved facts, notes and imported documents remain separate and persistent.", color=Color.LightGray, fontSize=10.sp, lineHeight=14.sp)
    }
}

@Composable
private fun MemoryMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color=Color(0xFF171019), shape=RoundedCornerShape(14.dp), border=BorderStroke(1.dp, Purple.copy(alpha=.6f))) {
        Column(Modifier.padding(11.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text(value, color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Black)
            Text(label, color=Orange, fontSize=9.sp, fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
private fun MemorySection(title: String, empty: Boolean, content: @Composable ColumnScope.() -> Unit) {
    Surface(color=Color(0xFF151117), shape=RoundedCornerShape(16.dp), border=BorderStroke(1.dp, Crimson.copy(alpha=.55f)), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) { Text(title, color=if(empty) Purple else Orange, fontSize=11.sp, fontWeight=FontWeight.ExtraBold); Spacer(Modifier.weight(1f)); Text(if(empty) "EMPTY" else "LOCAL", color=Purple, fontSize=8.sp) }
            content()
        }
    }
}

@Composable
private fun AdvancedCapabilitiesScreen(modifier: Modifier, context: Context) {
    var network by remember { mutableStateOf(UltronNetworkDiagnostics.inspect(context)) }
    var clipboard by remember { mutableStateOf(UltronClipboardIntelligence.read(context).orEmpty()) }
    var routines by remember { mutableStateOf(UltronRoutineStore(context).all()) }
    var selectedFolder by remember { mutableStateOf<android.net.Uri?>(null) }
    var fileEntries by remember { mutableStateOf(emptyList<UltronFileIntelligence.Entry>()) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            selectedFolder = uri
            fileEntries = UltronFileIntelligence.listChildren(context, uri)
        }
    }
    var name by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    var delayMinutes by remember { mutableStateOf("0") }
    var repeatMinutes by remember { mutableStateOf("0") }
    var routineEditorError by remember { mutableStateOf("") }
    var routineStatus by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    val store = remember { UltronRoutineStore(context) }
    LazyColumn(modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("ADVANCED INTELLIGENCE", color=Orange, fontSize=18.sp, fontWeight=FontWeight.Black); Text("Local capability controls and privacy-aware diagnostics", color=Color.LightGray, fontSize=11.sp) }
        item {
            var showAgentRoster by remember { mutableStateOf(false) }
            Surface(color=Color(0xFF17121A), shape=RoundedCornerShape(16.dp), border=BorderStroke(1.dp,Crimson.copy(alpha=.8f))) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text("ULTRON MULTI-AGENT NETWORK", color=Orange, fontWeight=FontWeight.Bold, fontSize=12.sp)
                    Text("${UltronMultiAgentCoordinator.availableRoles.size} specialist roles · adaptive task routing · ordered collaboration phases", color=Color.White, fontSize=13.sp, fontWeight=FontWeight.Bold)
                    Text("For each phone task, ULTRON selects the relevant specialists. Their real inference workers share findings across phases and report to one central planner. They reuse the configured General, Vision and Coding model profiles; they are not 28 independent model deployments. Local-only mode uses the local planner without remote specialist fan-out.", color=Color.LightGray, fontSize=10.sp, lineHeight=14.sp)
                    TextButton(onClick = { showAgentRoster = !showAgentRoster }) { Text(if (showAgentRoster) "HIDE SPECIALIST ROSTER" else "VIEW ALL 28 SPECIALISTS", color=Orange) }
                    if (showAgentRoster) {
                        UltronMultiAgentCoordinator.availableRoles.forEach { role ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(role.title, color=Color.White, fontSize=10.sp, fontWeight=FontWeight.SemiBold)
                                    Text(role.department.uppercase(), color=Color.LightGray, fontSize=8.sp)
                                }
                                Surface(color=Color(0xFF251A2A), shape=RoundedCornerShape(8.dp)) {
                                    Text(role.modelRole.uppercase(), color=Purple, fontSize=8.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=8.dp, vertical=4.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Surface(color=Color(0xFF17121A), shape=RoundedCornerShape(16.dp), border=BorderStroke(1.dp,Purple)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text("NETWORK DIAGNOSTICS", color=Purple, fontWeight=FontWeight.Bold, fontSize=12.sp)
                    Text("${network.transport} · ${if(network.connected) "Connected" else "Offline"}", color=Color.White, fontSize=15.sp, fontWeight=FontWeight.Bold)
                    Text("${network.details} · Metered: ${network.metered} · Roaming: ${network.roaming}", color=Color.LightGray, fontSize=11.sp)
                    TextButton(onClick={ network=UltronNetworkDiagnostics.inspect(context) }) { Text("REFRESH", color=Orange) }
                }
            }
        }
        item {
            Surface(color=Color(0xFF17121A), shape=RoundedCornerShape(16.dp), border=BorderStroke(1.dp,Crimson)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text("CLIPBOARD INTELLIGENCE", color=Orange, fontWeight=FontWeight.Bold, fontSize=12.sp)
                    Text(if(clipboard.isBlank()) "No safe text available (sensitive values are hidden)." else clipboard.take(500), color=Color.White, fontSize=12.sp, maxLines=6)
                    TextButton(onClick={ clipboard=UltronClipboardIntelligence.read(context).orEmpty() }) { Text("READ SAFE CLIPBOARD", color=Orange) }
                }
            }
        }
        item {
            Surface(color=Color(0xFF17121A), shape=RoundedCornerShape(16.dp), border=BorderStroke(1.dp,Purple)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("ROUTINE LIBRARY", color=Purple, fontWeight=FontWeight.Bold, fontSize=12.sp, modifier=Modifier.weight(1f)); TextButton(onClick={ name=""; command=""; delayMinutes="0"; repeatMinutes="0"; routineEditorError=""; showEditor=true }) { Text("+ NEW", color=Orange) } }
                    if(routines.isEmpty()) Text("No saved routines yet.", color=Color.LightGray, fontSize=11.sp)
                    routines.forEach { routine ->
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(routine.name, color=Color.White, fontWeight=FontWeight.Bold, fontSize=12.sp)
                                Text(routine.command, color=Color.LightGray, fontSize=10.sp, maxLines=2)
                                val scheduleLabel = when {
                                    routine.lastRunAtMillis > 0L && !routine.enabled -> "Completed once · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(routine.lastRunAtMillis))}"
                                    routine.triggerAtMillis > 0L && !routine.enabled -> "Paused · not scheduled"
                                    routine.triggerAtMillis > 0L && routine.enabled && routine.repeatIntervalMillis > 0L -> "Repeats every ${routine.repeatIntervalMillis / 60_000L} min · first run ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(routine.triggerAtMillis))}"
                                    routine.triggerAtMillis > 0L && routine.enabled -> "Scheduled · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(routine.triggerAtMillis))}"
                                    else -> "Manual routine · not scheduled"
                                }
                                Text(scheduleLabel, color=Purple, fontSize=9.sp)
                                Row {
                                    TextButton(onClick={ runCatching { UltronRoutineScheduler.runNow(context, routine); routineStatus="${routine.name} queued · normal approval rules apply" }.onFailure { routineStatus=it.message ?: "Could not queue routine" } }) { Text("RUN NOW", color=Orange, fontSize=9.sp) }
                                    if (routine.triggerAtMillis > 0L && routine.enabled) TextButton(onClick={ UltronRoutineScheduler.cancel(context, routine.id); store.save(routine.copy(enabled=false)); routines=store.all() }) { Text("PAUSE", color=Purple, fontSize=9.sp) }
                                    if (routine.triggerAtMillis > 0L && !routine.enabled && routine.lastRunAtMillis == 0L) TextButton(onClick={ runCatching { val resumed=routine.copy(enabled=true, triggerAtMillis=System.currentTimeMillis()+60_000L); store.save(resumed); UltronRoutineScheduler.schedule(context,resumed); routines=store.all(); routineStatus="${routine.name} rescheduled for one minute from now" }.onFailure { routineStatus=it.message ?: "Could not resume routine" } }) { Text("RESUME", color=Purple, fontSize=9.sp) }
                                }
                            }
                            TextButton(onClick={ store.delete(routine.id); routines=store.all() }) { Text("DELETE", color=Crimson, fontSize=9.sp) }
                        }
                    }
                    if (routineStatus.isNotBlank()) Text(routineStatus, color=Orange, fontSize=10.sp)
                    Text("Scheduled routines are dispatched through WorkManager and ULTRON's normal planner. Android may delay them during Doze; sensitive actions still need your approval.", color=Color(0xFFFFC477), fontSize=10.sp)
                }
            }
        }
        item {
            Surface(color=Color(0xFF17121A), shape=RoundedCornerShape(16.dp), border=BorderStroke(1.dp,Orange)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text("FILE INTELLIGENCE · USER-SELECTED FOLDER", color=Orange, fontWeight=FontWeight.Bold, fontSize=12.sp)
                    Text(selectedFolder?.lastPathSegment ?: "Choose a folder to inspect its files", color=Color.LightGray, fontSize=10.sp)
                    TextButton(onClick={ folderPicker.launch(null) }) { Text("CHOOSE FOLDER", color=Orange) }
                    fileEntries.take(12).forEach { entry -> Text((if(entry.directory) "▸ " else "• ")+entry.name+(if(entry.directory) "/" else " · ${entry.size} bytes"), color=Color.White, fontSize=10.sp) }
                    if(fileEntries.size>12) Text("And ${fileEntries.size-12} more…", color=Color.Gray, fontSize=9.sp)
                }
            }
        }
        item {
            Surface(color=Color(0xFF17121A), shape=RoundedCornerShape(16.dp), border=BorderStroke(1.dp,Crimson)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("NOTIFICATION INTELLIGENCE", color=Orange, fontWeight=FontWeight.Bold, fontSize=12.sp)
                    Text("${UltronNotificationListener.notificationCount()} active notifications", color=Color.White, fontSize=13.sp)
                    Text("Notification access is optional. ULTRON only reads active notifications after you grant access; verification codes and payment-like numbers are filtered from its safe summary view.", color=Color.LightGray, fontSize=10.sp)
                    TextButton(onClick={ runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) { Text("MANAGE NOTIFICATION ACCESS", color=Orange) }
                }
            }
        }
        item { Text("Files use user-selected SAF folders. Local OCR is available through the vision engine. Plugin SDK interfaces are in the source; no untrusted downloaded code is executed.", color=Color.LightGray, fontSize=10.sp) }
    }
    if(showEditor) AlertDialog(
        onDismissRequest={showEditor=false},
        title={Text("New routine", color=Crimson)},
        text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, {name=it}, label={Text("Routine name")}, singleLine=true)
            OutlinedTextField(command, {command=it}, label={Text("Command / workflow")}, minLines=2)
            OutlinedTextField(delayMinutes, {delayMinutes=it.filter(Char::isDigit).take(7)}, label={Text("Run after minutes (0 = manual only)")}, singleLine=true)
            OutlinedTextField(repeatMinutes, {repeatMinutes=it.filter(Char::isDigit).take(7)}, label={Text("Repeat every minutes (0 = once)")}, singleLine=true)
            Text("Repeating routines require at least 15 minutes. Android battery and Doze policies can delay scheduled work.", color=Color.Gray, fontSize=10.sp)
            if (routineEditorError.isNotBlank()) Text(routineEditorError, color=Crimson, fontSize=10.sp)
        } },
        confirmButton={ TextButton(onClick={
            runCatching {
                val delay = delayMinutes.toLongOrNull() ?: 0L
                val repeat = repeatMinutes.toLongOrNull() ?: 0L
                require(delay >= 0L && repeat >= 0L) { "Schedule values must be positive." }
                require(delay <= 525_600L) { "Schedule no more than one year ahead." }
                require(repeat == 0L || delay > 0L) { "Set a first-run delay before enabling repetition." }
                require(repeat == 0L || repeat * 60_000L >= UltronRoutineScheduler.MIN_REPEAT_INTERVAL_MILLIS) { "Repeat interval must be at least 15 minutes." }
                val routine = UltronRoutine(name=name.trim(), command=command.trim(), triggerAtMillis=if(delay > 0L) System.currentTimeMillis() + delay * 60_000L else 0L, repeatIntervalMillis=repeat * 60_000L)
                store.save(routine)
                if (routine.triggerAtMillis > 0L) UltronRoutineScheduler.schedule(context, routine)
                routines=store.all(); showEditor=false; routineEditorError=""
            }.onFailure { routineEditorError=it.message ?: "Could not save routine" }
        }) { Text("SAVE", color=Orange) } },
        dismissButton={ TextButton(onClick={showEditor=false}) { Text("CANCEL") } }
    )
}

@Composable
private fun DashboardScreen(modifier: Modifier = Modifier, mode: String, status: String, selectedAiName: String, aiNames: List<String>, onSelectAi: (String)->Unit, onChat:()->Unit, onVoice:()->Unit, onVision:()->Unit, onBrowser:()->Unit, onMemory:()->Unit, onModels:()->Unit, onSecurity:()->Unit, onPlugins:()->Unit, onCapabilities:()->Unit) {
    LazyColumn(modifier.fillMaxWidth(), contentPadding=PaddingValues(start=13.dp,end=13.dp,top=5.dp,bottom=18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ULTRON // COMMAND DECK", color=Color.White, fontSize=17.sp, fontWeight=FontWeight.Black, letterSpacing=1.3.sp)
                    Text("AUTONOMOUS INTELLIGENCE SYSTEM", color=Orange, fontSize=8.sp, letterSpacing=1.7.sp, fontWeight=FontWeight.Bold)
                }
                Surface(color=Color(0xFF211018), shape=RoundedCornerShape(30.dp), border=BorderStroke(1.dp,Crimson.copy(alpha=.8f))) {
                    Row(Modifier.padding(horizontal=10.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(6.dp).background(if(status.contains("fail",true)) Color(0xFFFF5555) else Color(0xFF72E6A4),RoundedCornerShape(8.dp)))
                        Text(if(status.contains("fail",true)) "ATTENTION" else "SYSTEM READY",color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Surface(color=Color(0xFF0D0B10), shape=RoundedCornerShape(25.dp), border=BorderStroke(1.dp,Brush.horizontalGradient(listOf(Crimson,Orange,Purple))), modifier=Modifier.fillMaxWidth()) {
                Box(Modifier.height(348.dp)) {
                    AndroidView(factory = { viewContext -> UltronGifView(viewContext, R.raw.ultron_dashboard, cropToFill = true) }, modifier = Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x33000000),Color(0x22000000),Color(0xF308090D)))))
                    Column(Modifier.align(Alignment.TopStart).padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        Surface(color=Color(0xBB110D14),shape=RoundedCornerShape(20.dp),border=BorderStroke(1.dp,Crimson.copy(alpha=.7f))) {
                            Text("◉  NEURAL CORE ${mode.uppercase()} MODE",Modifier.padding(horizontal=10.dp,vertical=6.dp),color=Orange,fontSize=8.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                        }
                    }
                    Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("THE MACHINE IS AWAKE",color=Orange,fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
                        Text("I AM ULTRON",color=Color.White,fontSize=29.sp,fontWeight=FontWeight.Black,letterSpacing=1.6.sp)
                        Text(status.take(100),color=Color(0xFFE0D8DF),fontSize=9.sp,maxLines=2)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            Surface(Modifier.weight(1f).height(45.dp).clickable(onClick=onChat),color=Color(0xFF8D1724),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Crimson)) {
                                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center) { Icon(Icons.Default.Bolt,null,tint=Orange); Spacer(Modifier.width(7.dp)); Text("COMMAND",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp) }
                            }
                            Surface(Modifier.weight(1f).height(45.dp).clickable(onClick=onVoice),color=Color(0xDD17111B),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Purple)) {
                                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center) { Icon(Icons.Default.Mic,null,tint=Orange); Spacer(Modifier.width(7.dp)); Text("VOICE LINK",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp) }
                            }
                        }
                    }
                }
            }
        }
        item {
            var expanded by remember { mutableStateOf(false) }
            Surface(color=Color(0xFF14111A),shape=RoundedCornerShape(19.dp),border=BorderStroke(1.dp,Purple.copy(alpha=.78f)),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ACTIVE INTELLIGENCE",color=Purple,fontSize=8.sp,fontWeight=FontWeight.Black,letterSpacing=1.7.sp)
                            Text(selectedAiName,color=Color.White,fontSize=18.sp,fontWeight=FontWeight.ExtraBold)
                        }
                        TextButton(onClick={ expanded=true }) { Text("SWITCH AI  ▾",color=Orange,fontSize=10.sp,fontWeight=FontWeight.Bold) }
                        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { aiNames.forEach { name -> DropdownMenuItem(text={Text(name)},onClick={expanded=false;onSelectAi(name)}) } }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        listOf("REASONING","MEMORY","TOOLS").forEach { tag -> Surface(color=Color(0xFF211925),shape=RoundedCornerShape(7.dp)) { Text(tag,Modifier.padding(horizontal=8.dp,vertical=5.dp),color=if(tag=="TOOLS")Orange else Color.LightGray,fontSize=7.sp,fontWeight=FontWeight.Bold,letterSpacing=.6.sp) } }
                    }
                    Text("All-in-One can run parallel AI responses, peer review and final synthesis when two or more profiles are configured.",color=Color(0xFFBEB1C5),fontSize=9.sp,lineHeight=13.sp)
                }
            }
        }
        item { Row(verticalAlignment=Alignment.CenterVertically) { Text("SYSTEM MODULES",color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Black,letterSpacing=1.8.sp); Spacer(Modifier.weight(1f)); Text("SELECT A MODULE",color=Crimson,fontSize=8.sp,fontWeight=FontWeight.Bold) } }
        item {
            Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("VISION", "Camera intelligence", Icons.Default.Visibility, Modifier.weight(1f), onVision)
                    DashboardTile("BROWSER", "Web operations", Icons.Default.Language, Modifier.weight(1f), onBrowser)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("MEMORY", "Private knowledge vault", Icons.Default.Psychology, Modifier.weight(1f), onMemory)
                    DashboardTile("PLUGINS", "Connected capabilities", Icons.Default.Extension, Modifier.weight(1f), onPlugins)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("MODEL VAULT", "Offline GGUF models", Icons.Default.Memory, Modifier.weight(1f), onModels)
                    DashboardTile("SECURITY", "Permissions & protection", Icons.Default.Security, Modifier.weight(1f), onSecurity)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    DashboardTile("INTELLIGENCE", "Routines · files · network · clipboard", Icons.Default.Hub, Modifier.weight(1f), onCapabilities)
                    Spacer(Modifier.weight(1f))
                }
            }
        }
        item { Text("ULTRON // BUILT TO UNDERSTAND. DESIGNED TO ACT.",color=Purple,fontSize=8.sp,letterSpacing=1.1.sp,modifier=Modifier.fillMaxWidth().padding(vertical=6.dp)) }
    }
}

@Composable
private fun DashboardTile(title:String, subtitle:String, icon:androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier=Modifier, onClick:()->Unit) {
    Surface(modifier=modifier.height(112.dp).clickable(onClick=onClick), color=Color(0xFF14121A), shape=RoundedCornerShape(17.dp), border=BorderStroke(1.dp,Brush.linearGradient(listOf(Crimson.copy(alpha=.72f),Purple.copy(alpha=.45f),Color(0xFF4B2930))))) {
        Row(Modifier.fillMaxSize().padding(13.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(11.dp)) {
            Surface(color=Color(0xFF28151E),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Crimson.copy(alpha=.45f))) { Box(Modifier.size(43.dp),contentAlignment=Alignment.Center) { Icon(icon,contentDescription=null,tint=if(title=="MEMORY") Purple else Orange,modifier=Modifier.size(23.dp)) } }
            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                Text(title,color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=.9.sp,maxLines=1)
                Text(subtitle,color=Color(0xFFBDB5C2),fontSize=8.sp,maxLines=2,lineHeight=11.sp)
            }
            Icon(Icons.Default.ChevronRight,null,tint=Crimson,modifier=Modifier.size(17.dp))
        }
    }
}

@Composable
private fun NeonAction(label:String, icon:androidx.compose.ui.graphics.vector.ImageVector, onClick:()->Unit, modifier:Modifier=Modifier) {
    Surface(modifier=modifier.height(46.dp).clickable(onClick=onClick), color=Color(0xFF351016), shape=RoundedCornerShape(13.dp), border=BorderStroke(1.dp,Crimson)) {
        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.Center) { Icon(icon,contentDescription=null,tint=Orange); Spacer(Modifier.width(9.dp)); Text(label,color=Color.White,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp) }
    }
}

@Composable
private fun VoiceFeatureScreen(modifier:Modifier=Modifier,onStart:()->Unit,onStop:()->Unit,onSpeak:()->Unit) {
    val context = LocalContext.current
    var wakeHealth by remember { mutableStateOf(UltronWakeWordHealth.snapshot(context)) }
    var speakerProfileStatus by remember { mutableStateOf(if (UltronSpeakerProfile.isEnrolled(context)) "VOICE PROFILE ENROLLED · experimental familiarity signal" else "NO VOICE PROFILE ENROLLED") }
    var speakerProfileBusy by remember { mutableStateOf(false) }
    val speakerProfileScope = rememberCoroutineScope()
    val speakerPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        speakerProfileStatus = if (granted) "Permission granted. Tap Enroll voice profile again." else "Microphone permission was not granted."
    }
    LaunchedEffect(Unit) {
        while (true) {
            wakeHealth = UltronWakeWordHealth.snapshot(context)
            delay(1_500L)
        }
    }
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=18.dp, vertical=12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(13.dp)) {
        Surface(color=Color(0xFF100B11), shape=RoundedCornerShape(24.dp), border=BorderStroke(1.dp,Crimson.copy(alpha=.8f)), modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("NEURAL VOICE LINK", color=Orange, fontSize=9.sp, fontWeight=FontWeight.Bold, letterSpacing=1.6.sp); Text("NEURAL CORE · LIVE LINK", color=Color.White, fontSize=17.sp, fontWeight=FontWeight.Black) }
                    Surface(color=Color(0xFF251018), shape=RoundedCornerShape(20.dp), border=BorderStroke(1.dp,Crimson)) { Text("ULTRON", color=Crimson, fontSize=9.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=10.dp, vertical=6.dp)) }
                }
                Spacer(Modifier.height(18.dp))
                Box(Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF09070D)), contentAlignment=Alignment.Center) {
                    AndroidView(factory = { viewContext -> UltronGifView(viewContext, R.raw.ultron_voice_core, cropToFill = true) }, modifier = Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color.Transparent, Color(0x66000000)))))
                }
                Text("WAKE WORD · ULTRON", color=Crimson, fontSize=15.sp, fontWeight=FontWeight.Black, letterSpacing=1.8.sp)
                Text("Say ‘ULTRON’, pause, then speak your command", color=Color.LightGray, fontSize=10.sp)
                Text("PERSISTENT MODE · Remembers your opt-in across app closure and reboot. Android 14+ requires one tap to resume after reboot.", color=Purple, fontSize=9.sp, lineHeight=13.sp, textAlign=TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(5.dp), verticalAlignment=Alignment.CenterVertically) {
                    repeat(17) { i -> Box(Modifier.width(5.dp).height((10 + (i * 13 % 34)).dp).background(if (i % 3 == 0) Orange else Crimson.copy(alpha=.8f), RoundedCornerShape(4.dp))) }
                }
                Spacer(Modifier.height(18.dp))
                NeonAction("ARM WAKE-WORD LISTENER",Icons.Default.Mic,onStart,Modifier.fillMaxWidth())
                NeonAction("DISARM LISTENER",Icons.Default.Stop,onStop,Modifier.fillMaxWidth())
            }
        }
        Surface(color=Color(0xFF151117), shape=RoundedCornerShape(17.dp), border=BorderStroke(1.dp,Orange.copy(alpha=.45f)), modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Text("WAKE-WORD HEALTH · LIVE DIAGNOSTICS", color=Orange, fontWeight=FontWeight.Bold, fontSize=10.sp)
                Text(wakeHealth.status, color=if (wakeHealth.status.startsWith("READY") || wakeHealth.status == "WAKE WORD DETECTED") Color(0xFF70D99A) else Crimson, fontSize=12.sp, fontWeight=FontWeight.Bold)
                Text(wakeHealth.provider, color=Color.LightGray, fontSize=9.sp)
                Text(wakeHealth.summary(), color=Color(0xFFD0CBD3), fontSize=9.sp, lineHeight=13.sp)
                Text("This reports recognizer callbacks and recovery attempts; it cannot prove that every spoken wake word was understood.", color=Color(0xFFFFC477), fontSize=9.sp)
            }
        }
        Surface(color=Color(0xFF151117), shape=RoundedCornerShape(17.dp), border=BorderStroke(1.dp,Purple.copy(alpha=.55f)), modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("VOICE PROFILE · SPEAKER FAMILIARITY", color=Purple, fontWeight=FontWeight.Bold, fontSize=10.sp)
                Text(speakerProfileStatus, color=Color.White, fontSize=10.sp, lineHeight=14.sp)
                Text("Enroll three 3–4 second samples speaking the same sentence at a similar distance, then compare a fresh sample for personalization. This experimental acoustic similarity is not secure speaker authentication, cannot prove identity and is never used to unlock Android or approve sensitive actions. Use fingerprint, face unlock or device PIN for security.", color=Color(0xFFFFC477), fontSize=9.sp, lineHeight=13.sp)
                Text("Disarm the wake-word listener first so the app can use the microphone for enrollment or comparison.", color=Color.LightGray, fontSize=9.sp)
                NeonAction(if (speakerProfileBusy) "CAPTURING VOICE SAMPLES…" else "ENROLL SPEAKER PROFILE", Icons.Default.RecordVoiceOver, {
                    if (speakerProfileBusy) return@NeonAction
                    if (UltronWakeWordPreferences.isEnabled(context)) {
                        speakerProfileStatus = "Please disarm the wake-word listener, then try again."
                    } else if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        speakerPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    } else {
                        speakerProfileScope.launch {
                            speakerProfileBusy = true
                            speakerProfileStatus = "Recording three samples. Speak the same 3–4 second sentence each time, in a quiet room…"
                            try {
                                speakerProfileStatus = withContext(Dispatchers.IO) { UltronSpeakerProfile.enroll(context) }
                            } catch (error: Exception) {
                                speakerProfileStatus = "Enrollment failed: ${error.message ?: error.javaClass.simpleName}"
                            } finally { speakerProfileBusy = false }
                        }
                    }
                }, Modifier.fillMaxWidth())
                NeonAction("CHECK SPEAKER RESEMBLANCE", Icons.Default.GraphicEq, {
                    if (speakerProfileBusy) return@NeonAction
                    if (UltronWakeWordPreferences.isEnabled(context)) {
                        speakerProfileStatus = "Please disarm the wake-word listener, then try again."
                    } else if (!UltronSpeakerProfile.isEnrolled(context)) {
                        speakerProfileStatus = "Enroll a voice profile first."
                    } else if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        speakerPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    } else {
                        speakerProfileScope.launch {
                            speakerProfileBusy = true
                            speakerProfileStatus = "Capturing a comparison sample…"
                            try {
                                val match = withContext(Dispatchers.IO) { UltronSpeakerProfile.compare(context) }
                                speakerProfileStatus = "Acoustic resemblance ${(match.similarity * 100).toInt()}% · ${match.confidence}. Not authentication; do not use for security."
                            } catch (error: Exception) {
                                speakerProfileStatus = "Voice comparison failed: ${error.message ?: error.javaClass.simpleName}"
                            } finally { speakerProfileBusy = false }
                        }
                    }
                }, Modifier.fillMaxWidth())
                TextButton(onClick = {
                    UltronSpeakerProfile.clear(context)
                    speakerProfileStatus = "Voice profile deleted from this device."
                }, modifier = Modifier.align(Alignment.End)) { Text("DELETE VOICE PROFILE", color = Crimson, fontSize = 9.sp) }
            }
        }
        Surface(color=Color(0xFF151117), shape=RoundedCornerShape(17.dp), border=BorderStroke(1.dp,Purple.copy(alpha=.55f)), modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Text("COMMAND EXAMPLES", color=Orange, fontWeight=FontWeight.Bold, fontSize=10.sp)
                Text("• ‘ULTRON, open YouTube and search BMW’", color=Color.White, fontSize=11.sp)
                Text("• ‘ULTRON, open Settings’", color=Color.White, fontSize=11.sp)
                Text("• ‘ULTRON’ then say ‘search the web for latest Android news’", color=Color.White, fontSize=11.sp)
                Text("• ‘set volume to 70 percent’ · ‘pause music’ · ‘next song’", color=Color.White, fontSize=11.sp)
                Text("• ‘scroll left’ · ‘find BMW on screen’ · ‘open power menu’", color=Color.White, fontSize=11.sp)
            }
        }
        Text("Requires microphone permission and an ongoing foreground-service notification. On Android 8–13 the opted-in listener can attempt to restart after boot; Android 14+ blocks microphone-service startup directly from BOOT_COMPLETED, so ULTRON posts a resume notification. ColorOS/Oppo autostart and battery controls can still stop it. Android SpeechRecognizer is session-based, provider-dependent and not a dedicated low-power hotword engine. On Android 8.1 this uses the installed recognition provider and may require network access; the diagnostics above show provider readiness and recovery, not perfect recognition.",color=Color.LightGray,fontSize=9.sp,lineHeight=13.sp)
    }
}

@Composable
private fun OfflineModelScreen(
    modifier: Modifier = Modifier,
    enabled: Boolean,
    onEnabled: (Boolean) -> Unit,
    modelStatus: String,
    onFindQwen: () -> Unit,
    onImport: () -> Unit,
    onDownload: (String) -> Unit,
    onDelete: () -> Unit
) {
    var directUrl by remember { mutableStateOf("") }
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text("LOCAL MODEL VAULT", color = Crimson, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
        Text("OFFLINE INTELLIGENCE · ON DEVICE", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Surface(color = Color(0xFF171019), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Purple.copy(alpha = .65f)), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Enable Offline AI", color = Color.White, fontWeight = FontWeight.Bold); Text("When enabled, chat uses the imported local GGUF instead of online endpoints.", color = Color.LightGray, fontSize = 9.sp) }
                Switch(checked = enabled, onCheckedChange = onEnabled)
            }
        }
        Text("RECOMMENDED MODEL", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Surface(color = Color(0xFF151117), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .6f)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("Qwen3.5-4B-Amadeus Q4_K", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                Text("GGUF · local inference · user-controlled installation", color = Orange, fontSize = 9.sp)
                Text("The model repository page lets you choose a compatible GGUF asset. ULTRON does not silently download or replace models.", color = Color.LightGray, fontSize = 10.sp)
                NeonAction("FIND QWEN GGUF DOWNLOAD", Icons.Default.Search, onFindQwen, Modifier.fillMaxWidth())
                OutlinedTextField(value = directUrl, onValueChange = { directUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Direct HTTPS .gguf asset URL") }, placeholder = { Text("https://.../resolve/main/model.gguf") }, minLines = 2)
                NeonAction("DOWNLOAD FROM DIRECT URL", Icons.Default.Download, { if (directUrl.isNotBlank()) onDownload(directUrl.trim()) }, Modifier.fillMaxWidth())
            }
        }
        Text("CURRENT LOCAL MODEL", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(modelStatus, color = Color.LightGray, fontSize = 10.sp, lineHeight = 15.sp)
        NeonAction("IMPORT / REPLACE GGUF MODEL", Icons.Default.FileOpen, onImport, Modifier.fillMaxWidth())
        NeonAction("DELETE LOCAL MODEL", Icons.Default.Delete, onDelete, Modifier.fillMaxWidth())
        Text("This vault is separate from Online AI profiles. Importing a model does not configure or change your InstaBox connections.", color = Purple, fontSize = 10.sp, lineHeight = 14.sp)
    }
}

@Composable
private fun PluginHubScreen(modifier: Modifier = Modifier, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { PluginStore(context) }
    val pluginScope = rememberCoroutineScope()
    var plugins by remember { mutableStateOf(store.load()) }
    var name by remember { mutableStateOf("") }
    var template by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Connect a service account to let ULTRON use its supported API actions.") }
    var showConnectionSetup by remember { mutableStateOf(false) }
    var apiName by remember { mutableStateOf("") }
    var apiEndpoint by remember { mutableStateOf("") }
    var apiMethod by remember { mutableStateOf("GET") }
    var apiAuth by remember { mutableStateOf("bearer") }
    var apiCredential by remember { mutableStateOf("") }
    var apiSecondCredential by remember { mutableStateOf("") }
    var apiHeader by remember { mutableStateOf("X-API-Key") }
    var apiBody by remember { mutableStateOf("{\"query\":\"{query}\"}") }
    var oauthAuthUrl by remember { mutableStateOf("") }
    var oauthTokenUrl by remember { mutableStateOf("") }
    var oauthClientId by remember { mutableStateOf("") }
    var oauthClientSecret by remember { mutableStateOf("") }
    var oauthRedirect by remember { mutableStateOf("ultron://oauth/callback") }
    var oauthScope by remember { mutableStateOf("") }
    var oauthExtraAuthParameters by remember { mutableStateOf("{}") }
    val builtIns = listOf(
        WebPlugin("youtube", "YouTube", "https://www.youtube.com/results?search_query={query}"),
        WebPlugin("google", "Google", "https://www.google.com/search?q={query}"),
        WebPlugin("wikipedia", "Wikipedia", "https://en.wikipedia.org/w/index.php?search={query}"),
        WebPlugin("github", "GitHub", "https://github.com/search?q={query}"),
        WebPlugin("stackoverflow", "Stack Overflow", "https://stackoverflow.com/search?q={query}")
    )
    LazyColumn(modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("PLUGIN ARMORY", color = Crimson, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text("CONNECT YOUR OWN WEB TOOLS", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("Built-in websites and your custom HTTPS plugins can be opened or searched from ULTRON commands.", color = Color.LightGray, fontSize = 10.sp)
        }
        item { Text("BUILT-IN", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        items(builtIns) { plugin ->
            Surface(color = Color(0xFF151117), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .55f)), modifier = Modifier.fillMaxWidth().clickable { onOpen(PluginStore.expand(plugin.urlTemplate, "")) }) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(plugin.name, color = Color.White, fontWeight = FontWeight.Bold); Text("Searchable website · HTTPS", color = Color.LightGray, fontSize = 9.sp) }
                    TextButton(onClick = { onOpen(PluginStore.expand(plugin.urlTemplate, "")) }) { Text("OPEN", color = Orange) }
                }
            }
        }
        item { Text("YOUR PLUGINS", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        items(plugins, key = { it.id }) { plugin ->
            Surface(color = Color(0xFF151117), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Purple.copy(alpha = .55f)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(plugin.name, color = Color.White, fontWeight = FontWeight.Bold)
                        val state = if (plugin.kind == "oauth2") if (plugin.credential.isNotBlank()) "ACCOUNT CONNECTED · ${plugin.method}" else "AUTHORIZE ACCOUNT · ${plugin.method}" else if (plugin.kind == "website") "WEBSITE SHORTCUT" else "REST API · ${plugin.method} · ${plugin.authType}"
                        Text(state, color = if (plugin.kind == "oauth2" && plugin.credential.isNotBlank()) Color(0xFF70D99A) else Color.LightGray, fontSize = 8.sp, maxLines = 2)
                    }
                    if (plugin.kind == "website") TextButton(onClick = { onOpen(PluginStore.expand(plugin.urlTemplate, "")) }) { Text("OPEN", color = Orange) }
                    else TextButton(onClick = {
                        pluginScope.launch {
                            message = "Testing ${plugin.name} connection…"
                            runCatching { store.execute(plugin, "") }
                                .onSuccess { result -> message = if (result.success) "${plugin.name} is responding (HTTP ${result.statusCode}). ${result.body.take(220)}" else "${plugin.name} returned HTTP ${result.statusCode}: ${result.body.take(220)}" }
                                .onFailure { message = "${plugin.name} test failed: ${it.message ?: it.javaClass.simpleName}" }
                            plugins = store.load()
                        }
                    }) { Text("TEST", color = Orange) }
                    TextButton(onClick = { plugins = plugins.filterNot { it.id == plugin.id }; store.save(plugins); message = "Removed ${plugin.name}" }) { Text("×", color = Crimson) }
                }
            }
        }
        item {
            if (showConnectionSetup) {
            HorizontalDivider(color = Crimson.copy(alpha = .4f))
            Text("ADD WEBSITE SHORTCUT", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Plugin name (e.g. BMW Forum)") }, singleLine = true)
            OutlinedTextField(value = template, onValueChange = { template = it }, modifier = Modifier.fillMaxWidth(), label = { Text("HTTPS URL template") }, placeholder = { Text("https://example.com/search?q={query}") }, minLines = 2)
            Text("Use {query} where ULTRON should insert the search terms. Example command: ‘search BMW on BMW Forum’. Only HTTPS URLs are accepted.", color = Color.LightGray, fontSize = 9.sp)
            NeonAction("ADD PLUGIN", Icons.Default.Add, {
                runCatching { store.add(name, template); plugins = store.load(); message = "Added $name. Try ‘search BMW on $name’."; name = ""; template = "" }
                    .onFailure { message = it.message ?: "Could not add plugin" }
            }, Modifier.fillMaxWidth())
            Text(message, color = Purple, fontSize = 10.sp)
            }
        }
        item {
            if (!showConnectionSetup) {
                Surface(color = Color(0xFF151117), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Orange.copy(alpha = .55f)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("CONNECT AN ACCOUNT", color = Orange, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Authorize a website or service once. ULTRON can then use the API operations and permissions that provider exposes, including read, create and edit where supported.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 15.sp)
                        NeonAction("CONNECT ACCOUNT", Icons.Default.Link, { showConnectionSetup = true }, Modifier.fillMaxWidth())
                    }
                }
            } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ACCOUNT CONNECTION SETUP", color = Orange, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { showConnectionSetup = false }) { Text("CLOSE", color = Crimson) }
            }
            Text("Choose OAuth when the service supports it. Otherwise configure its HTTPS API and the exact permissions it provides. There is no universal login that grants access to every website; each provider must authorize ULTRON.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 14.sp)
            HorizontalDivider(color = Purple.copy(alpha = .5f))
            Text("QUICK ACCOUNT PRESETS", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Text("Choose a provider to fill its standard OAuth values. You still need your own registered OAuth application, client ID and provider-approved redirect URI.", color = Color.LightGray, fontSize = 9.sp, lineHeight = 13.sp)
            UltronProviderPresets.all.forEach { preset ->
                TextButton(onClick = {
                    apiName = preset.label
                    apiEndpoint = preset.endpoint
                    apiMethod = preset.method
                    apiAuth = "bearer"
                    apiBody = if (preset.method in setOf("POST", "PUT", "PATCH")) "{}" else ""
                    oauthAuthUrl = preset.authorizationUrl
                    oauthTokenUrl = preset.tokenUrl
                    oauthScope = preset.scope
                    oauthExtraAuthParameters = preset.extraAuthorizationParameters
                    oauthRedirect = "ultron://oauth/callback"
                    message = preset.note
                }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(preset.label, color = Orange, fontWeight = FontWeight.Bold)
                        Text("USE PRESET", color = Purple, fontSize = 9.sp)
                    }
                }
            }
            HorizontalDivider(color = Purple.copy(alpha = .5f))
            Text("API INTEGRATION", color = Orange, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("Connect your own HTTPS REST API. Credentials are encrypted locally with Android Keystore. Use {query} in the endpoint and request body.", color = Color.LightGray, fontSize = 10.sp)
            OutlinedTextField(value = apiName, onValueChange = { apiName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Integration name") }, singleLine = true)
            OutlinedTextField(value = apiEndpoint, onValueChange = { apiEndpoint = it }, modifier = Modifier.fillMaxWidth(), label = { Text("HTTPS resource/API endpoint") }, placeholder = { Text("https://api.example.com/v1/action") }, singleLine = true)
            OutlinedTextField(value = apiMethod, onValueChange = { apiMethod = it.uppercase().take(6) }, modifier = Modifier.fillMaxWidth(), label = { Text("HTTP method: GET / POST / PUT / PATCH / DELETE") }, singleLine = true)
            OutlinedTextField(value = apiAuth, onValueChange = { apiAuth = it.lowercase().take(20) }, modifier = Modifier.fillMaxWidth(), label = { Text("Auth: none / bearer / api_key_header / api_key_query / basic") }, singleLine = true)
            OutlinedTextField(value = apiCredential, onValueChange = { apiCredential = it }, modifier = Modifier.fillMaxWidth(), label = { Text("API token / username") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(value = apiSecondCredential, onValueChange = { apiSecondCredential = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Password (Basic auth only)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(value = apiHeader, onValueChange = { apiHeader = it }, modifier = Modifier.fillMaxWidth(), label = { Text("API key header or query parameter name") }, singleLine = true)
            OutlinedTextField(value = apiBody, onValueChange = { apiBody = it }, modifier = Modifier.fillMaxWidth(), label = { Text("JSON body template (POST/PUT/PATCH)") }, minLines = 2)
            NeonAction("SAVE API INTEGRATION", Icons.Default.Add, {
                runCatching {
                    val saved = store.addIntegration(WebPlugin(id = "", name = apiName, kind = "rest", endpoint = apiEndpoint, method = apiMethod, authType = apiAuth, credential = apiCredential, secondaryCredential = apiSecondCredential, headerName = apiHeader, bodyTemplate = apiBody))
                    plugins = store.load(); message = "Saved ${saved.name}. Use ‘run plugin ${saved.name} with your request’ in chat."
                    apiName = ""; apiEndpoint = ""; apiCredential = ""; apiSecondCredential = ""
                }.onFailure { message = it.message ?: "Could not save API integration" }
            }, Modifier.fillMaxWidth())
            Text("OAUTH 2.0 CONNECTION", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("OAuth 2.0 Authorization Code + PKCE. ULTRON stores tokens encrypted and refreshes them when the provider supplies a refresh token. Register the exact redirect URI shown below with your provider. Some providers require Android package/signing registration or do not allow custom URI redirects. Each saved integration currently represents one API endpoint/action; configure separate endpoints for additional read/write operations.", color = Color.LightGray, fontSize = 9.sp, lineHeight = 13.sp)
            OutlinedTextField(value = oauthAuthUrl, onValueChange = { oauthAuthUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Authorization URL") }, singleLine = true)
            OutlinedTextField(value = oauthTokenUrl, onValueChange = { oauthTokenUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Token URL") }, singleLine = true)
            OutlinedTextField(value = oauthClientId, onValueChange = { oauthClientId = it }, modifier = Modifier.fillMaxWidth(), label = { Text("OAuth client ID") }, singleLine = true)
            OutlinedTextField(value = oauthClientSecret, onValueChange = { oauthClientSecret = it }, modifier = Modifier.fillMaxWidth(), label = { Text("OAuth client secret") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(value = oauthRedirect, onValueChange = { oauthRedirect = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Redirect URI") }, singleLine = true)
            OutlinedTextField(value = oauthScope, onValueChange = { oauthScope = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Scopes (space-separated)") }, singleLine = true)
            OutlinedTextField(value = oauthExtraAuthParameters, onValueChange = { oauthExtraAuthParameters = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Extra authorization parameters (JSON)") }, singleLine = true)
            NeonAction("SAVE OAUTH CONFIGURATION", Icons.Default.Security, {
                runCatching {
                    val saved = store.addIntegration(WebPlugin(id = "", name = apiName, kind = "oauth2", endpoint = apiEndpoint, method = apiMethod, authType = "bearer", bodyTemplate = apiBody, oauthAuthorizeUrl = oauthAuthUrl, oauthTokenUrl = oauthTokenUrl, oauthClientId = oauthClientId, oauthClientSecret = oauthClientSecret, oauthRedirectUri = oauthRedirect, oauthScope = oauthScope, oauthExtraAuthParameters = oauthExtraAuthParameters))
                    plugins = store.load(); message = "OAuth configuration saved for ${saved.name}. Provider-specific callback and token exchange must be supported by that service."
                }.onFailure { message = it.message ?: "Could not save OAuth configuration" }
            }, Modifier.fillMaxWidth())
            plugins.filter { it.kind == "oauth2" }.forEach { plugin ->
                TextButton(onClick = { runCatching { onOpen(store.beginOAuth(plugin)); message = "Opening ${plugin.name} authorization…" }.onFailure { message = it.message ?: "Could not open OAuth" } }) { Text("AUTHORIZE ${plugin.name.uppercase()}", color = Orange) }
            }
            Text(message, color = Purple, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun SimpleFeatureScreen(modifier:Modifier=Modifier,title:String, subtitle:String, items:List<String>, note:String) {
    Column(modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(title,color=Crimson,fontSize=20.sp,fontWeight=FontWeight.Black,letterSpacing=1.5.sp); Text(subtitle,color=Orange,fontSize=10.sp)
        items.forEach { item -> Surface(color=Color(0xFF151117),shape=RoundedCornerShape(13.dp),border=BorderStroke(1.dp,Crimson.copy(alpha=.45f)),modifier=Modifier.fillMaxWidth()) { Text(item,color=Color.White,fontSize=12.sp,modifier=Modifier.padding(14.dp)) } }
        Text(note,color=Purple,fontSize=10.sp,lineHeight=15.sp)
    }
}

@Composable
private fun BottomNavItem(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,selected:Boolean,onClick:()->Unit) {
    Column(Modifier.clickable(onClick=onClick).padding(horizontal=7.dp,vertical=3.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(icon,contentDescription=label,tint=if(selected) Crimson else Color(0xFFAAA3AD),modifier=Modifier.size(21.dp))
        Text(label,color=if(selected) Orange else Color(0xFFAAA3AD),fontSize=8.sp,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun AppLockScreen(onUnlock: () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Orange, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF24080D), Night))), contentAlignment = Alignment.Center) {
            Surface(color = Panel, shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .7f)), modifier = Modifier.padding(24.dp)) {
                Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("◉", color = Crimson, fontSize = 54.sp, fontWeight = FontWeight.Black)
                    Text("ULTRON LOCKED", color = Crimson, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Authenticate to access your assistant and locally stored private data.", color = Color.LightGray, fontSize = 13.sp)
                    Button(onClick = onUnlock, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Fingerprint, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Unlock ULTRON") }
                }
            }
        }
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean = false, onClick: (() -> Unit)? = null) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = { onClick?.invoke() }) { Icon(icon, contentDescription = label, tint = if (active) Crimson else Color(0xFFB7B5C0), modifier = Modifier.size(22.dp)) }
        Text(label, color = Color(0xFFB7B5C0), fontSize = 8.sp)
    }
}
