package com.ultron.assistant

import java.util.Locale
import kotlin.math.ln

/** Small on-device lexical retriever for imported documents; no embedding service or network is needed. */
data class UltronDocumentSource(val id: Long, val title: String, val extractedText: String)
data class UltronRetrievedExcerpt(val documentId: Long, val title: String, val excerpt: String, val score: Double)

object UltronDocumentRetrieval {
    private val stopWords = setOf(
        "the", "and", "for", "with", "that", "this", "from", "have", "has", "was", "were", "are", "you", "your", "what", "when", "where", "which", "who", "how", "why", "can", "could", "would", "should", "please", "about", "tell", "show", "find", "मेरे", "मुझे", "क्या", "कैसे", "कब", "कहाँ", "और", "का", "की", "के", "है", "हैं"
    )

    private fun tokens(value: String): List<String> = Regex("[\\p{L}\\p{N}]{2,}")
        .findAll(value.lowercase(Locale.ROOT)).map { it.value }.filterNot { it in stopWords }.toList()

    fun search(documents: List<UltronDocumentSource>, query: String, maxDocuments: Int = 3, excerptChars: Int = 900): List<UltronRetrievedExcerpt> {
        val terms = tokens(query).distinct().take(32)
        if (terms.isEmpty() || documents.isEmpty()) return emptyList()
        val prepared = documents.filter { it.extractedText.isNotBlank() }.map { doc ->
            doc to tokens(doc.extractedText)
        }
        val documentFrequency = terms.associateWith { term -> prepared.count { (_, body) -> term in body } }
        val averageLength = prepared.map { it.second.size }.average().takeIf { it.isFinite() && it > 0.0 } ?: 1.0
        return prepared.mapNotNull { (doc, body) ->
            if (body.isEmpty()) return@mapNotNull null
            val frequencies = body.groupingBy { it }.eachCount()
            val titleTokens = tokens(doc.title).toSet()
            var score = 0.0
            terms.forEach { term ->
                val tf = frequencies[term] ?: 0
                if (tf > 0) {
                    val df = documentFrequency[term] ?: 0
                    val idf = ln(1.0 + (prepared.size - df + 0.5) / (df + 0.5))
                    val k1 = 1.2
                    val b = 0.75
                    score += idf * (tf * (k1 + 1.0)) / (tf + k1 * (1.0 - b + b * body.size / averageLength))
                }
                if (term in titleTokens) score += 1.8
            }
            val normalizedBody = doc.extractedText.lowercase(Locale.ROOT)
            val normalizedQuery = query.trim().lowercase(Locale.ROOT)
            if (normalizedQuery.length >= 5 && normalizedBody.contains(normalizedQuery)) score += 3.0
            if (score <= 0.0) null else UltronRetrievedExcerpt(doc.id, doc.title, bestParagraph(doc.extractedText, terms, excerptChars), score)
        }.sortedByDescending { it.score }.take(maxDocuments.coerceIn(1, 8))
    }

    private fun bestParagraph(content: String, terms: List<String>, maxChars: Int): String {
        val chunks = content.split(Regex("\\n\\s*\\n|(?<=[.!?।])\\s+")).map { it.trim() }.filter { it.isNotBlank() }
        val best = chunks.maxByOrNull { chunk ->
            val words = tokens(chunk).toSet()
            terms.count { it in words } * 2 + terms.fold(0) { acc, term -> acc + if (chunk.contains(term, true)) 1 else 0 }
        }.orEmpty()
        if (best.length <= maxChars) return best
        val lowered = best.lowercase(Locale.ROOT)
        val firstHit = terms.map { lowered.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: 0
        val start = (firstHit - maxChars / 3).coerceAtLeast(0)
        return best.substring(start, minOf(best.length, start + maxChars))
    }
}
