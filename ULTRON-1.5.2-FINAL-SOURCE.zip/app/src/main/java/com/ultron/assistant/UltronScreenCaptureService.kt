package com.ultron.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Explicitly user-authorized screen observation for Android 8.0+.
 * Frames stay in memory as a small JPEG. They are not written to shared storage.
 * Online Vision upload is separately controlled by UltronScreenCaptureStore's opt-in.
 */
class UltronScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.ultron.assistant.SCREEN_CAPTURE_START"
        const val ACTION_STOP = "com.ultron.assistant.SCREEN_CAPTURE_STOP"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "ultron_screen_observer"
        private const val NOTIFICATION_ID = 4621
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var lastStoredFrameAt = 0L
    private val stopping = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_STICKY

        // Start foreground before obtaining the projection token, as required by Android.
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultCode == 0 || resultData == null) {
            Log.w("ULTRONScreen", "Screen capture started without a valid MediaProjection consent result")
            stopSelf()
            return START_NOT_STICKY
        }

        return try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            startProjectionCapture()
            START_STICKY
        } catch (error: Exception) {
            Log.e("ULTRONScreen", "Could not start screen observation", error)
            stopCapture()
            stopSelf()
            START_NOT_STICKY
        }
    }

    private fun startProjectionCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi.coerceAtLeast(1)

        workerThread = HandlerThread("UltronScreenFrames").also { it.start() }
        workerHandler = Handler(workerThread!!.looper)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).also { reader ->
            reader.setOnImageAvailableListener({ source -> consumeFrame(source, width, height) }, workerHandler)
        }

        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                Log.i("ULTRONScreen", "Android stopped the screen projection")
                stopCapture()
                stopSelf()
            }
        }
        projection?.registerCallback(callback, workerHandler)
        virtualDisplay = projection?.createVirtualDisplay(
            "ULTRON screen observer",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            workerHandler
        )
        if (virtualDisplay == null) throw IllegalStateException("Android did not create the screen display stream.")
        UltronScreenCaptureStore.setCaptureActive(true)
        Log.i("ULTRONScreen", "Screen observation active at ${width}x$height")
    }

    private fun consumeFrame(reader: ImageReader, width: Int, height: Int) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastStoredFrameAt < 1_000L || stopping.get()) return
        val image = try { reader.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            val jpeg = imageToJpeg(image, width, height) ?: return
            UltronScreenCaptureStore.publish(jpeg)
            lastStoredFrameAt = now
        } catch (error: Exception) {
            Log.w("ULTRONScreen", "Could not process a screen frame: ${error.message}")
        } finally {
            runCatching { image.close() }
        }
    }

    private fun imageToJpeg(image: Image, width: Int, height: Int): ByteArray? {
        val plane = image.planes.firstOrNull() ?: return null
        val pixelStride = plane.pixelStride
        if (pixelStride != 4) return null // RGBA_8888 should expose four bytes per pixel.
        val rowStride = plane.rowStride
        val rowBytes = width * pixelStride
        if (rowStride < rowBytes) return null
        val source = plane.buffer.duplicate()
        source.rewind()
        val rgba = ByteArray(width * height * 4)
        for (row in 0 until height) {
            val sourceOffset = row * rowStride
            if (sourceOffset + rowBytes > source.limit()) return null
            source.position(sourceOffset)
            source.get(rgba, row * rowBytes, rowBytes)
        }
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        try {
            bitmap.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(rgba))
            val maxDimension = 1440
            val scale = minOf(1f, maxDimension.toFloat() / maxOf(width, height).toFloat())
            val resized = if (scale < 1f) {
                Bitmap.createScaledBitmap(bitmap, (width * scale).toInt().coerceAtLeast(1), (height * scale).toInt().coerceAtLeast(1), true)
            } else bitmap
            try {
                val output = ByteArrayOutputStream()
                if (!resized.compress(Bitmap.CompressFormat.JPEG, 72, output)) return null
                return output.toByteArray()
            } finally {
                if (resized !== bitmap) runCatching { resized.recycle() }
            }
        } finally {
            runCatching { bitmap.recycle() }
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, UltronScreenCaptureService::class.java).setAction(ACTION_STOP)
        val stop = PendingIntent.getService(
            this,
            4622,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val open = PendingIntent.getActivity(
            this,
            4623,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ULTRON screen awareness is active")
            .setContentText("A recent frame is kept briefly in memory. Remote Vision sharing requires a separate ULTRON opt-in.")
            .setContentIntent(open)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Stop capture", stop)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "ULTRON screen awareness", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun stopCapture() {
        if (!stopping.compareAndSet(false, true)) return
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { projection?.stop() }
        projection = null
        UltronScreenCaptureStore.setCaptureActive(false)
        UltronScreenCaptureStore.clearLatestFrame()
        runCatching { workerThread?.quitSafely() }
        workerThread = null
        workerHandler = null
        runCatching { stopForeground(true) }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}

/** Volatile, short-lived frame cache. Raw frames are never persisted to disk or database. */
object UltronScreenCaptureStore {
    private val lock = Any()
    @Volatile private var latestJpeg: ByteArray? = null
    @Volatile private var capturedAtElapsed: Long = 0L
    @Volatile private var captureActive: Boolean = false

    fun setCaptureActive(active: Boolean) { captureActive = active }
    fun isCaptureActive(): Boolean = captureActive

    fun publish(jpeg: ByteArray) {
        if (jpeg.isEmpty() || jpeg.size > 6_000_000) return
        synchronized(lock) {
            latestJpeg = jpeg
            capturedAtElapsed = SystemClock.elapsedRealtime()
        }
    }

    fun latestJpeg(maxAgeMs: Long = 3_500L): ByteArray? = synchronized(lock) {
        val bytes = latestJpeg ?: return@synchronized null
        if (!captureActive || SystemClock.elapsedRealtime() - capturedAtElapsed > maxAgeMs.coerceAtLeast(0)) return@synchronized null
        bytes.copyOf()
    }

    fun latestBitmap(maxAgeMs: Long = 3_500L): Bitmap? {
        val bytes = latestJpeg(maxAgeMs) ?: return null
        return runCatching { android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }.getOrNull()
    }

    fun latestDataUrl(maxAgeMs: Long = 3_500L): String? {
        val bytes = latestJpeg(maxAgeMs) ?: return null
        return "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun isCloudVisionEnabled(context: Context): Boolean =
        context.getSharedPreferences("ultron_screen_observer", Context.MODE_PRIVATE).getBoolean("share_with_vision", false)

    fun setCloudVisionEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences("ultron_screen_observer", Context.MODE_PRIVATE).edit().putBoolean("share_with_vision", enabled).apply()
    }

    fun clearLatestFrame() {
        synchronized(lock) {
            latestJpeg = null
            capturedAtElapsed = 0L
        }
    }
}
