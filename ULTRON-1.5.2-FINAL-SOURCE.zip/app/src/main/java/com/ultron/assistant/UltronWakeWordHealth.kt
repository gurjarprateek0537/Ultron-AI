package com.ultron.assistant

import android.content.Context

/** Durable, truthful diagnostics for the SpeechRecognizer-based wake listener. */
data class UltronWakeWordHealthSnapshot(
    val status: String,
    val provider: String,
    val lastReadyAtMillis: Long,
    val lastAudioCallbackAtMillis: Long,
    val lastWakeAtMillis: Long,
    val recognizedSessions: Int,
    val restartCount: Int,
    val lastErrorCode: Int,
    val lastError: String,
    val lastUpdatedAtMillis: Long
) {
    fun summary(): String {
        val audio = if (lastAudioCallbackAtMillis > 0L &&
            System.currentTimeMillis() - lastAudioCallbackAtMillis in 0L..30_000L) {
            "Recent audio-level callbacks received"
        } else {
            "No recent audio-level callback (silence or recognizer input may be inactive)"
        }
        val ready = if (lastReadyAtMillis > 0L) "Provider last ready at ${java.text.DateFormat.getTimeInstance().format(java.util.Date(lastReadyAtMillis))}" else "Provider has not reported ready yet"
        val error = if (lastError.isBlank()) "No recorded recognizer error" else "Last error $lastErrorCode: ${lastError.take(120)}"
        return "$status · $provider · $ready · $audio · sessions=$recognizedSessions · restarts=$restartCount · $error"
    }
}

object UltronWakeWordHealth {
    private const val PREFS = "ultron_wake_word_health_v1"
    private const val KEY_STATUS = "status"
    private const val KEY_PROVIDER = "provider"
    private const val KEY_READY = "ready_at"
    private const val KEY_AUDIO = "audio_at_epoch_ms"
    private const val KEY_WAKE = "wake_at"
    private const val KEY_SESSIONS = "sessions"
    private const val KEY_RESTARTS = "restarts"
    private const val KEY_ERROR_CODE = "error_code"
    private const val KEY_ERROR = "error"
    private const val KEY_UPDATED = "updated"

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun starting(context: Context, provider: String) {
        prefs(context).edit().putString(KEY_STATUS, "STARTING")
            .putString(KEY_PROVIDER, provider.take(100)).putLong(KEY_UPDATED, System.currentTimeMillis()).apply()
    }

    fun ready(context: Context) {
        prefs(context).edit().putString(KEY_STATUS, "READY · waiting for speech")
            .putLong(KEY_READY, System.currentTimeMillis()).putLong(KEY_UPDATED, System.currentTimeMillis()).apply()
    }

    /** Called for audio-level callbacks only; write to disk at most once every five seconds. */
    fun audioCallback(context: Context) {
        val now = System.currentTimeMillis()
        val p = prefs(context)
        val previous = p.getLong(KEY_AUDIO, 0L)
        if (now - previous >= 5_000L || now < previous) {
            p.edit().putLong(KEY_AUDIO, now).putLong(KEY_UPDATED, now).apply()
        }
    }

    fun recognized(context: Context) {
        val p = prefs(context)
        p.edit().putInt(KEY_SESSIONS, p.getInt(KEY_SESSIONS, 0) + 1)
            .putLong(KEY_UPDATED, System.currentTimeMillis()).apply()
    }

    fun wakeDetected(context: Context) {
        prefs(context).edit().putLong(KEY_WAKE, System.currentTimeMillis())
            .putString(KEY_STATUS, "WAKE WORD DETECTED").putLong(KEY_UPDATED, System.currentTimeMillis()).apply()
    }

    fun recovering(context: Context, reason: String) {
        val p = prefs(context)
        p.edit().putString(KEY_STATUS, "RECOVERING")
            .putString(KEY_ERROR, reason.take(180)).putInt(KEY_ERROR_CODE, p.getInt(KEY_ERROR_CODE, 0))
            .putInt(KEY_RESTARTS, p.getInt(KEY_RESTARTS, 0) + 1)
            .putLong(KEY_UPDATED, System.currentTimeMillis()).apply()
    }

    fun error(context: Context, code: Int, message: String) {
        prefs(context).edit().putString(KEY_STATUS, "ERROR · recovering")
            .putInt(KEY_ERROR_CODE, code).putString(KEY_ERROR, message.take(180))
            .putLong(KEY_UPDATED, System.currentTimeMillis()).apply()
    }

    fun stopped(context: Context, reason: String = "Stopped by user") {
        prefs(context).edit().putString(KEY_STATUS, "STOPPED")
            .putString(KEY_ERROR, reason.take(180)).putLong(KEY_UPDATED, System.currentTimeMillis()).apply()
    }

    fun snapshot(context: Context): UltronWakeWordHealthSnapshot {
        val p = prefs(context)
        return UltronWakeWordHealthSnapshot(
            status = p.getString(KEY_STATUS, "NOT STARTED") ?: "NOT STARTED",
            provider = p.getString(KEY_PROVIDER, "Unknown speech provider") ?: "Unknown speech provider",
            lastReadyAtMillis = p.getLong(KEY_READY, 0L),
            lastAudioCallbackAtMillis = p.getLong(KEY_AUDIO, 0L),
            lastWakeAtMillis = p.getLong(KEY_WAKE, 0L),
            recognizedSessions = p.getInt(KEY_SESSIONS, 0),
            restartCount = p.getInt(KEY_RESTARTS, 0),
            lastErrorCode = p.getInt(KEY_ERROR_CODE, 0),
            lastError = p.getString(KEY_ERROR, "") ?: "",
            lastUpdatedAtMillis = p.getLong(KEY_UPDATED, 0L)
        )
    }
}
