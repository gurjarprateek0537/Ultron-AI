package com.ultron.assistant

import java.util.Locale

/** Wake-word matching for Android SpeechRecognizer hypotheses (not a dedicated acoustic hotword model). */
object UltronWakeWordPhrase {
    private val canonicalWakeTokens = setOf("ultron", "अल्ट्रॉन", "अल्ट्रोन", "altron")
    private val greetingTokens = setOf("hey", "hello", "hi")

    fun containsWakeWord(value: String): Boolean = wakeTokenIndex(normalize(value)) != null

    /** Returns the command after the wake token, preserving a split "ultra on" transcription. */
    fun commandAfterWakeWord(value: String): String? {
        val tokens = normalize(value)
        val index = wakeTokenIndex(tokens) ?: return null
        val end = if (tokens.getOrNull(index) == "ultra" && tokens.getOrNull(index + 1) == "on") index + 2 else index + 1
        return tokens.drop(end).joinToString(" ")
    }

    /** Choose the best complete recognizer alternative, then merge it with the richest partial. */
    fun bestHypothesis(partial: String, candidates: List<String>): String {
        val final = candidates.asSequence().map(String::trim).filter(String::isNotBlank)
            .distinct().maxByOrNull(::hypothesisScore).orEmpty()
        val p = partial.trim()
        if (p.isBlank()) return final
        if (final.isBlank()) return p
        if (containsWakeWord(p) && !containsWakeWord(final)) return mergeOverlappingWords(p, final)
        if (!containsWakeWord(p) && containsWakeWord(final)) return final
        return if (hypothesisScore(p) > hypothesisScore(final)) p else bestPhrase(p, final)
    }

    fun bestPhrase(partial: String, final: String): String {
        val p = partial.trim()
        val f = final.trim()
        if (f.isBlank()) return p
        if (p.isBlank()) return f
        if (containsWakeWord(p) && !containsWakeWord(f)) return mergeOverlappingWords(p, f)
        return if (hypothesisScore(p) > hypothesisScore(f)) p else f
    }

    private fun hypothesisScore(value: String): Int {
        val tokens = normalize(value)
        if (tokens.isEmpty()) return 0
        val wake = wakeTokenIndex(tokens)
        val commandWords = if (wake == null) 0 else tokens.size - (if (tokens.getOrNull(wake) == "ultra" && tokens.getOrNull(wake + 1) == "on") wake + 2 else wake + 1)
        return (if (wake != null) 10_000 else 0) + commandWords * 100 + tokens.size * 8 + value.trim().length.coerceAtMost(80)
    }

    private fun normalize(value: String): List<String> = value.lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9\\u0900-\\u097f]+"), " ")
        .trim().split(Regex("\\s+")).filter { it.isNotBlank() }

    private fun wakeTokenIndex(tokens: List<String>): Int? {
        val canonical = tokens.indexOfFirst { it in canonicalWakeTokens }
        if (canonical >= 0) return canonical
        // Older speech providers may split the spoken name into "ultra on".
        if (tokens.size >= 2 && tokens[0] == "ultra" && tokens[1] == "on") return 0
        val firstCandidate = when {
            tokens.firstOrNull() in greetingTokens -> 1
            else -> 0
        }
        val first = tokens.getOrNull(firstCandidate) ?: return null
        if (first in setOf("ultra", "altron")) return firstCandidate
        // Allow only a one-edit recognizer typo at the wake-word position, never mid-sentence.
        if (first.length in 5..7 && editDistanceAtMostOne(first, "ultron")) return firstCandidate
        return null
    }

    private fun editDistanceAtMostOne(a: String, b: String): Boolean {
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        var i = 0; var j = 0; var edits = 0
        while (i < a.length && j < b.length) {
            if (a[i] == b[j]) { i++; j++ } else {
                edits++
                if (edits > 1) return false
                when {
                    a.length > b.length -> i++
                    b.length > a.length -> j++
                    else -> { i++; j++ }
                }
            }
        }
        if (i < a.length || j < b.length) edits++
        return edits <= 1
    }

    private fun mergeOverlappingWords(first: String, second: String): String {
        val left = first.split(Regex("\\s+")).filter { it.isNotBlank() }
        val right = second.split(Regex("\\s+")).filter { it.isNotBlank() }
        val maxOverlap = minOf(left.size, right.size)
        val overlap = (maxOverlap downTo 1).firstOrNull { count ->
            left.takeLast(count).map { it.lowercase(Locale.ROOT) } == right.take(count).map { it.lowercase(Locale.ROOT) }
        } ?: 0
        return (left + right.drop(overlap)).joinToString(" ")
    }
}
