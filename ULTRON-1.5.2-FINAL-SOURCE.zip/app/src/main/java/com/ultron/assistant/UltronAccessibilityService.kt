package com.ultron.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Bitmap
import android.os.Handler
import android.os.Bundle
import android.os.Build
import android.util.DisplayMetrics
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import android.view.Display
import java.util.Locale

/** User-enabled helper. It only reads or acts after a user command; it does not send screen contents to a server. */
class UltronAccessibilityService : AccessibilityService() {
    @Volatile private var windowGeneration: Long = 0L
    @Volatile private var lastWindowEventAt: Long = 0L
    @Volatile private var lastEventPackage: String? = null

    override fun onServiceConnected() { super.onServiceConnected(); active = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        // Keep only transition metadata. Screen text is read on-demand by a user-requested task.
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                windowGeneration++
                lastWindowEventAt = android.os.SystemClock.elapsedRealtime()
                event.packageName?.toString()?.takeIf { it.isNotBlank() }?.let { lastEventPackage = it }
            }
        }
    }
    fun screenGeneration(): Long = windowGeneration
    fun lastTransitionPackage(): String? = lastEventPackage
    fun isWindowSettled(quietMs: Long = 350L): Boolean =
        android.os.SystemClock.elapsedRealtime() - lastWindowEventAt >= quietMs.coerceIn(100L, 1_500L)
    override fun onInterrupt() = Unit
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }

    /** Prefer the foreground application window over the soft keyboard's input-method window. */
    private fun activeApplicationRoot(): AccessibilityNodeInfo? {
        val snapshot = try { windows } catch (_: Exception) { emptyList() }
        val appRoot = try {
            val appWindow = snapshot.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.isActive }
                ?: snapshot.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.isFocused }
                ?: snapshot.lastOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            appWindow?.root
        } catch (_: Exception) {
            null
        } finally {
            snapshot.forEach { window -> runCatching { window.recycle() } }
        }
        return appRoot ?: rootInActiveWindow
    }

    fun findVisibleText(text: String): AccessibilityNodeInfo? {
        val root = activeApplicationRoot() ?: return null
        val matches = try { root.findAccessibilityNodeInfosByText(text) } finally { root.recycle() }
        val match = matches.firstOrNull { it.isVisibleToUser }
        matches.filter { it !== match }.forEach { it.recycle() }
        return match
    }

    fun clickText(text: String): Boolean {
        val query = text.trim().take(180)
        if (query.isBlank()) return false
        val root = activeApplicationRoot() ?: return false
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        fun collect(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 32 || candidates.size >= 120) return
            if (node.isVisibleToUser && node.isEnabled) candidates += AccessibilityNodeInfo.obtain(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                try { collect(child, depth + 1) } finally { child?.recycle() }
            }
        }
        return try {
            collect(root, 0)
            val rankedMatches = candidates.mapNotNull { node ->
                val labels = listOf(node.text, node.contentDescription, node.hintText, node.viewIdResourceName)
                    .filterNotNull().map { it.toString() }
                if (labels.none { it.equals(query, true) || it.contains(query, true) }) return@mapNotNull null
                val exact = labels.any { it.equals(query, true) }
                val score = (if (exact) 100 else 45) + (if (node.isClickable) 30 else 0) +
                    (if (node.className?.toString()?.contains("Button", true) == true) 15 else 0)
                node to score
            }
            val bestScore = rankedMatches.maxOfOrNull { it.second }
            val bestMatches = rankedMatches.filter { it.second == bestScore }
            // Never guess when two equally strong visible controls share the requested label.
            // The planner can inspect the hierarchy again or ask the user to disambiguate.
            bestMatches.singleOrNull()?.first?.let { clickNodeOrAncestor(AccessibilityNodeInfo.obtain(it)) } ?: false
        } finally {
            candidates.forEach { it.recycle() }
            root.recycle()
        }
    }

    /**
     * Compact semantic snapshot for the LLM planner. Unlike a plain text dump this keeps
     * unlabeled interactive controls, image/avatar nodes, resource IDs and screen bounds.
     * Bounds are refreshed on every call and must never be reused after a window event.
     */
    fun describeVisibleUi(limit: Int = 6_000): String {
        val root = activeApplicationRoot() ?: return "SCREEN package=unknown generation=$windowGeneration\nNo active application window is available."
        data class RankedNode(val order: Int, val score: Int, val line: String)
        val output = StringBuilder()
        val packageName = root.packageName?.toString().orEmpty().ifBlank { "unknown" }
        val display = resources.displayMetrics
        output.append("SCREEN package=").append(packageName)
            .append(" generation=").append(windowGeneration)
            .append(" size=").append(display.widthPixels).append('x').append(display.heightPixels)
            .append(" density=").append(String.format(Locale.US, "%.2f", display.density))
            .append(" lastEventPackage=").append(lastEventPackage ?: "unknown").append('\n')

        // Breadth-first collection avoids spending the whole node budget deep inside a long
        // text column. Rank interactive controls first, while keeping a stable traversal order
        // for nodes with equal importance. All node bounds are created from this fresh call.
        val queue = java.util.ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        val ranked = mutableListOf<RankedNode>()
        queue.add(root to 0)
        var visited = 0
        var sequence = 0
        while (queue.isNotEmpty() && visited < 360 && ranked.size < 220) {
            val (node, depth) = queue.removeFirst()
            try {
                visited++
                if (node.isVisibleToUser && depth <= 24) {
                    val password = node.isPassword
                    val text = if (password) "[redacted]" else safeScreenLabel(node.text?.toString().orEmpty()).take(100)
                    val description = if (password) "[redacted]" else safeScreenLabel(node.contentDescription?.toString().orEmpty()).take(120)
                    val hint = if (password) "[redacted]" else safeScreenLabel(node.hintText?.toString().orEmpty()).take(80)
                    val resource = runCatching { node.viewIdResourceName }.getOrNull().orEmpty().take(100)
                    val className = node.className?.toString()?.substringAfterLast('.')?.take(50).orEmpty()
                    val interactive = node.isClickable || node.isLongClickable || node.isFocusable || node.isEditable || node.isScrollable
                    if (text.isNotBlank() || description.isNotBlank() || hint.isNotBlank() || resource.isNotBlank() || interactive || className.contains("Image", true)) {
                        val bounds = android.graphics.Rect()
                        node.getBoundsInScreen(bounds)
                        val score = (if (node.isClickable) 100 else 0) +
                            (if (node.isEditable) 95 else 0) +
                            (if (node.isScrollable) 55 else 0) +
                            (if (node.isLongClickable) 30 else 0) +
                            (if (node.isFocusable) 15 else 0) +
                            (if (text.isNotBlank() || description.isNotBlank() || hint.isNotBlank()) 20 else 0) +
                            (if (className.contains("Button", true)) 12 else 0) +
                            (if (className.contains("Image", true)) 8 else 0)
                        val line = buildString {
                            append("NODE depth=").append(depth)
                                .append(" class=").append(className.ifBlank { "unknown" })
                                .append(" text=").append(text.ifBlank { "-" })
                                .append(" desc=").append(description.ifBlank { "-" })
                                .append(" hint=").append(hint.ifBlank { "-" })
                                .append(" id=").append(resource.ifBlank { "-" })
                                .append(" bounds=").append(bounds.left).append(',').append(bounds.top).append(',').append(bounds.right).append(',').append(bounds.bottom)
                                .append(" click=").append(node.isClickable)
                                .append(" longClick=").append(node.isLongClickable)
                                .append(" focus=").append(node.isFocusable)
                                .append(" edit=").append(node.isEditable)
                                .append(" password=").append(password)
                                .append(" scroll=").append(node.isScrollable)
                                .append(" check=").append(node.isCheckable)
                                .append(" checked=").append(node.isChecked)
                                .append(" selected=").append(node.isSelected)
                                .append(" children=").append(node.childCount)
                        }
                        ranked += RankedNode(sequence++, score, line)
                    }
                }
                if (depth < 24) {
                    for (index in 0 until node.childCount) {
                        if (visited + queue.size >= 360) break
                        val child = runCatching { node.getChild(index) }.getOrNull() ?: continue
                        queue.add(child to (depth + 1))
                    }
                }
            } finally {
                runCatching { node.recycle() }
            }
        }
        val chosen = ranked.sortedWith(compareByDescending<RankedNode> { it.score }.thenBy { it.order })
        for (candidate in chosen) {
            if (output.length + candidate.line.length + 1 > limit) continue
            output.append(candidate.line).append('\n')
        }
        while (queue.isNotEmpty()) runCatching { queue.removeFirst().first.recycle() }
        if (ranked.isEmpty()) output.append("No visible accessibility nodes were exposed.")
        return output.toString().take(limit)
    }

    private fun safeScreenLabel(raw: String): String {
        if (raw.isBlank()) return ""
        return raw
            .replace(Regex("(?i)\\b(?:otp|one[- ]time password|verification code|passcode)\\b[^\\d]{0,20}\\d{4,8}"), "[verification code hidden]")
            .replace(Regex("(?i)\\b(?:password|passphrase|secret|recovery code)\\s*[:=]?\\s*\\S+"), "[private value hidden]")
            .replace(Regex("(?<!\\d)\\d{6}(?!\\d)"), "[possible code hidden]")
            .replace(Regex("\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b", RegexOption.IGNORE_CASE), "[email hidden]")
            .replace(Regex("(?<!\\w)\\+?[0-9][0-9 ()-]{7,}[0-9](?!\\w)"), "[number hidden]")
            .take(240)
    }

    fun readVisibleText(limit: Int = 5_000): String {
        val root = activeApplicationRoot() ?: return "No active app window is available."
        val result = StringBuilder()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || result.length >= limit || depth > 30) return
            if (node.isVisibleToUser) {
                val label = if (node.isPassword) "[redacted]" else safeScreenLabel(
                    node.text?.toString()?.trim().orEmpty()
                        .ifBlank { node.contentDescription?.toString()?.trim().orEmpty() }
                        .ifBlank { node.hintText?.toString()?.trim().orEmpty() }
                )
                if (label.isNotBlank()) result.append(label).append('\n')
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                try { walk(child, depth + 1) } finally { child?.recycle() }
            }
        }
        try { walk(root, 0) } finally { root.recycle() }
        return result.toString().take(limit).ifBlank { "No readable text was exposed by the active app." }
    }

    fun scroll(forward: Boolean): Boolean {
        val root = activeApplicationRoot() ?: return false
        fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (node.isVisibleToUser && node.isEnabled && node.isScrollable) return AccessibilityNodeInfo.obtain(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                val found = try { findScrollable(child) } finally { child?.recycle() }
                if (found != null) return found
            }
            return null
        }
        val target = try { findScrollable(root) } finally { root.recycle() }
        if (target != null) {
            return try {
                target.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
            } finally { target.recycle() }
        }
        // Many Compose/WebView screens expose no scrollable node; use a bounded swipe fallback.
        return swipe(if (forward) "up" else "down")
    }

    fun scrollDirection(direction: String): Boolean = when (direction.lowercase()) {
        "down" -> scroll(true)
        "up" -> scroll(false)
        "left", "right" -> swipe(direction)
        else -> false
    }

    /** Return locally-visible text hits without exporting screen content to a network service. */
    fun findTextOnScreen(query: String, limit: Int = 8): String {
        val needle = query.trim().take(160)
        if (needle.isBlank()) return "Search text was empty."
        val root = activeApplicationRoot() ?: return "No active application window is available."
        val hits = mutableListOf<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 32 || hits.size >= limit.coerceIn(1, 20)) return
            if (node.isVisibleToUser) {
                val label = listOf(node.text, node.contentDescription, node.hintText)
                    .filterNotNull().map { it.toString().trim() }.firstOrNull { it.isNotBlank() }.orEmpty()
                if (label.contains(needle, ignoreCase = true) && label !in hits) hits += safeScreenLabel(label).take(220)
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                try { walk(child, depth + 1) } finally { child?.recycle() }
            }
        }
        return try {
            walk(root, 0)
            if (hits.isEmpty()) "No visible accessibility text matched ‘$needle’." else hits.joinToString("\n")
        } finally { root.recycle() }
    }

    fun longPressText(text: String): Boolean {
        val query = text.trim().take(180)
        if (query.isBlank()) return false
        val root = activeApplicationRoot() ?: return false
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        fun collect(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 32 || nodes.size >= 120) return
            if (node.isVisibleToUser && node.isEnabled) nodes += AccessibilityNodeInfo.obtain(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                try { collect(child, depth + 1) } finally { child?.recycle() }
            }
        }
        try {
            collect(root, 0)
            val target = nodes.firstOrNull { node ->
                listOf(node.text, node.contentDescription, node.hintText)
                    .filterNotNull().any { it.toString().contains(query, true) }
            } ?: return false
            var current: AccessibilityNodeInfo? = AccessibilityNodeInfo.obtain(target)
            while (current != null) {
                val worked = current.isEnabled && current.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
                val parent = current.parent
                current.recycle()
                if (worked) { parent?.recycle(); return true }
                current = parent
            }
            return false
        } finally {
            nodes.forEach { it.recycle() }
            root.recycle()
        }
    }

    fun dragNormalized(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 550): Boolean {
        val metrics = resources.displayMetrics
        val startX = x1.coerceIn(0f, 1f) * metrics.widthPixels
        val startY = y1.coerceIn(0f, 1f) * metrics.heightPixels
        val endX = x2.coerceIn(0f, 1f) * metrics.widthPixels
        val endY = y2.coerceIn(0f, 1f) * metrics.heightPixels
        val path = Path().apply { moveTo(startX, startY); lineTo(endX, endY) }
        val gesture = GestureDescription.Builder().addStroke(
            GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(150, 2_000))
        ).build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }

    fun doubleTapNormalized(x: Float, y: Float): Boolean {
        val metrics = resources.displayMetrics
        val px = x.coerceIn(0f, 1f) * metrics.widthPixels
        val py = y.coerceIn(0f, 1f) * metrics.heightPixels
        val first = Path().apply { moveTo(px, py) }
        val second = Path().apply { moveTo(px, py) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(first, 0, 70))
            .addStroke(GestureDescription.StrokeDescription(second, 140, 70))
            .build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }

    /** API 30+ local screen capture for on-device OCR; the bitmap is never persisted or uploaded. */
    fun captureDisplayBitmap(callback: (Bitmap?, String?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            callback(null, "Visual screen capture for OCR requires Android 11+; this phone version can still use accessibility text.")
            return
        }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val buffer = screenshot.hardwareBuffer
                    val wrapped = runCatching { Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace) }.getOrNull()
                    val bitmap = runCatching { wrapped?.copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
                    runCatching { wrapped?.recycle() }
                    runCatching { buffer.close() }
                    callback(bitmap, if (bitmap == null) "Android returned an empty screen capture." else null)
                }
                override fun onFailure(errorCode: Int) {
                    callback(null, "Android screen capture failed (code $errorCode); the window may be secure or capture may be rate-limited.")
                }
            })
        } catch (error: Exception) {
            callback(null, "Screen capture unavailable: ${error.message ?: "system restriction"}")
        }
    }

    fun performSystemAction(action: String): Boolean {
        val global = when (action.lowercase()) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recent", "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "power_menu" -> GLOBAL_ACTION_POWER_DIALOG
            "lock" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return false
            else -> return false
        }
        return performGlobalAction(global)
    }

    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }

    /**
     * Focuses the best visible search control. It prefers an editable field whose hint,
     * content-description or resource id identifies it as search; otherwise it taps a
     * visible Search control and lets the caller wait for the field to appear.
     */
    fun focusSearchField(): Boolean {
        val root = activeApplicationRoot() ?: return false
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        fun collect(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 32 || candidates.size >= 80) return
            if (node.isVisibleToUser && node.isEnabled) candidates += AccessibilityNodeInfo.obtain(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                try { collect(child, depth + 1) } finally { child?.recycle() }
            }
        }
        try {
            collect(root, 0)
            fun searchScore(node: AccessibilityNodeInfo): Int {
                val hint = node.hintText?.toString().orEmpty()
                val desc = node.contentDescription?.toString().orEmpty()
                val viewId = node.viewIdResourceName.orEmpty()
                val label = node.text?.toString().orEmpty()
                var score = 0
                val searchTerms = listOf("search", "query", "find", "recherche", "buscar", "поиск", "検索", "검색", "ค้นหา", "खोज")
                if (searchTerms.any { hint.contains(it, true) }) score += 120
                if (searchTerms.any { viewId.contains(it, true) }) score += 110
                if (searchTerms.any { desc.contains(it, true) }) score += 100
                if (searchTerms.any { label.contains(it, true) }) score += 80
                if (viewId.contains("url_bar", true) || viewId.contains("address_bar", true)) score += 90
                if (node.isEditable) score += 10
                if (node.isClickable) score += 5
                return score
            }
            val editable = candidates.filter { it.isEditable }.maxByOrNull(::searchScore)
            if (editable != null && searchScore(editable) >= 80) {
                val focused = editable.performAction(AccessibilityNodeInfo.ACTION_CLICK) ||
                    editable.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                if (focused) return true
            }
            val searchButton = candidates.filter { !it.isEditable && it.isClickable }
                .maxByOrNull(::searchScore)
            if (searchButton != null && searchScore(searchButton) >= 80) {
                return clickNodeOrAncestor(AccessibilityNodeInfo.obtain(searchButton))
            }
            // Do not guess: a lone editable field may be a login, comment, or payment field.
            return false
        } finally {
            candidates.forEach { it.recycle() }
            root.recycle()
        }
    }

    private fun clickNodeOrAncestor(start: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = start
        while (current != null) {
            val clicked = current.isEnabled && current.isClickable &&
                current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val parent = current.parent
            current.recycle()
            if (clicked) {
                parent?.recycle()
                return true
            }
            current = parent
        }
        return false
    }

    /**
     * Fills only the currently focused editable node. It never guesses based on a lone
     * text field: ambiguous entry could otherwise target a password, comment or payment box.
     */
    private fun isSemanticSearchField(node: AccessibilityNodeInfo): Boolean {
        val labels = listOf(
            node.hintText?.toString().orEmpty(),
            node.contentDescription?.toString().orEmpty(),
            node.viewIdResourceName.orEmpty(),
            node.text?.toString().orEmpty()
        )
        val terms = listOf("search", "query", "find", "recherche", "buscar", "поиск", "検索", "검색", "ค้นหา", "खोज")
        return labels.any { label ->
            terms.any { term -> label.contains(term, ignoreCase = true) } ||
                listOf("url_bar", "address_bar", "omnibox").any { label.contains(it, ignoreCase = true) }
        }
    }

    private fun isSensitiveEntryField(node: AccessibilityNodeInfo): Boolean {
        if (node.isPassword) return true
        val labels = listOf(
            node.hintText?.toString().orEmpty(),
            node.contentDescription?.toString().orEmpty(),
            node.viewIdResourceName.orEmpty(),
            node.text?.toString().orEmpty()
        ).joinToString(" ").lowercase(Locale.ROOT)
        return listOf(
            "password", "passcode", "one-time password", "verification code", "security code",
            "otp", "recovery code", "cvv", "cvc", "card number", "credit card", "pin code"
        ).any { it in labels }
    }

    fun typeText(value: String, requireSearchField: Boolean = false): Boolean {
        val safeValue = value.filter { it == '\n' || it == '\t' || it >= ' ' && it != '\u007f' }.take(2_000)
        if (safeValue.isEmpty()) return false
        val root = activeApplicationRoot() ?: return false
        val target = runCatching { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
        return try {
            val node = target ?: return false
            if (!node.isVisibleToUser || !node.isEnabled || !node.isEditable) return false
            // ULTRON never injects secrets/OTP/payment credentials into a focused field.
            // Those must be entered manually by the user in the target app.
            if (isSensitiveEntryField(node)) return false
            if (requireSearchField && !isSemanticSearchField(node)) return false
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, safeValue)
            }
            val accepted = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            val resultingText = node.text?.toString()
            accepted && (resultingText == null || resultingText == safeValue)
        } finally {
            target?.recycle()
            root.recycle()
        }
    }

    /**
     * On Android 8/9, ACTION_IME_ENTER is not exposed as an AccessibilityAction.
     * Inspect only the system input-method window and activate a clearly named Search/Go key.
     */
    private fun clickImeSearchAction(): Boolean {
        val inputWindows = runCatching { windows.filter { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } }.getOrDefault(emptyList())
        val acceptedLabels = setOf("search", "go", "enter", "submit", "खोज", "खोजें", "buscar", "recherche")
        for (window in inputWindows) {
            val root = runCatching { window.root }.getOrNull() ?: continue
            val candidates = mutableListOf<AccessibilityNodeInfo>()
            fun collect(node: AccessibilityNodeInfo?, depth: Int) {
                if (node == null || depth > 18 || candidates.size >= 100) return
                if (node.isVisibleToUser && node.isEnabled && node.isClickable) candidates += AccessibilityNodeInfo.obtain(node)
                for (index in 0 until node.childCount) {
                    val child = node.getChild(index)
                    try { collect(child, depth + 1) } finally { child?.recycle() }
                }
            }
            try {
                collect(root, 0)
                val target = candidates.firstOrNull { node ->
                    val labels = listOf(node.text, node.contentDescription, node.hintText)
                        .filterNotNull().map { it.toString().trim().lowercase(Locale.ROOT) }
                    labels.any { it in acceptedLabels }
                }
                if (target != null && clickNodeOrAncestor(AccessibilityNodeInfo.obtain(target))) return true
            } finally {
                candidates.forEach { it.recycle() }
                root.recycle()
            }
        }
        return false
    }

    /** Submit a semantically identified search editor, then fall back to a visible Search control. */
    fun submitSearch(): Boolean {
        val root = activeApplicationRoot() ?: return false
        try {
            val focused = runCatching { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
            if (focused != null) {
                try {
                    // Do not invoke the keyboard's action on an arbitrary form field.
                    if (focused.isEditable && isSemanticSearchField(focused) && Build.VERSION.SDK_INT >= 30 &&
                        focused.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
                } finally { focused.recycle() }
            }
        } finally { root.recycle() }
        if (clickImeSearchAction()) return true
        // Never tap generic Submit/Go controls here: they may commit a form, purchase,
        // or message. Search actions are restricted to clearly labelled search controls.
        val labels = listOf(
            "Search", "Search YouTube", "Buscar", "Recherche",
            "Поиск", "検索", "검색", "ค้นหา", "खोजें", "खोज"
        )
        return labels.any { label -> runCatching { clickText(label) }.getOrDefault(false) }
    }

    /** Dispatches a directional swipe over the central portion of the screen. */
    fun swipe(direction: String): Boolean {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels.toFloat()
        val h = metrics.heightPixels.toFloat()
        val cx = w * .5f
        val cy = h * .52f
        val (sx, sy, ex, ey) = when (direction.lowercase()) {
            "up" -> floatArrayOf(cx, h * .78f, cx, h * .30f)
            "down" -> floatArrayOf(cx, h * .30f, cx, h * .78f)
            "left" -> floatArrayOf(w * .82f, cy, w * .18f, cy)
            "right" -> floatArrayOf(w * .18f, cy, w * .82f, cy)
            else -> return false
        }
        val path = Path().apply { moveTo(sx, sy); lineTo(ex, ey) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 360)).build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }

    fun tapNormalized(x: Float, y: Float): Boolean {
        val metrics = resources.displayMetrics
        val px = x.coerceIn(0f, 1f) * metrics.widthPixels
        val py = y.coerceIn(0f, 1f) * metrics.heightPixels
        return tap(px, py)
    }

    fun activePackageName(): String? {
        val root = activeApplicationRoot() ?: return null
        return try { root.packageName?.toString() } finally { root.recycle() }
    }

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun clickTextInPackage(packageName: String, text: String): Boolean {
        val root = activeApplicationRoot() ?: return false
        val activePackage = root.packageName?.toString()
        root.recycle()
        if (activePackage != packageName) return false
        return clickText(text)
    }

    companion object {
        @Volatile private var active: UltronAccessibilityService? = null
        fun instance(): UltronAccessibilityService? = active
    }
}
