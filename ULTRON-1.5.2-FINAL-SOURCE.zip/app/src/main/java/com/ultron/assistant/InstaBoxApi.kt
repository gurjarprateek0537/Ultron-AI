package com.ultron.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Direct InstaBox cloud-computer API client. This is deliberately separate from LLM inference URLs. */
data class InstaBoxMachine(val id: String, val name: String, val status: String)
data class InstaBoxAccountCheck(val authenticated: Boolean, val summary: String, val machines: List<InstaBoxMachine>)

object InstaBoxConnectionStore {
    private const val PREFS = "ultron_instabox_connection"
    private const val KEY = "api_key_cipher"
    fun loadKey(context: Context): String {
        val encrypted = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return ""
        return runCatching { PrivateTextVault.decrypt(encrypted) }.getOrDefault("")
    }
    fun saveKey(context: Context, apiKey: String) {
        val value = apiKey.trim()
        val editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (value.isBlank()) editor.remove(KEY) else editor.putString(KEY, PrivateTextVault.encrypt(value))
        editor.apply()
    }
}

object InstaBoxApi {
    private const val API_BASE = "https://api.instabox.sh/v1"

    /** GET /machines validates the key and its machine-list scope; it does not create or bill a machine. */
    fun checkAccount(apiKey: String): InstaBoxAccountCheck {
        val key = apiKey.trim()
        require(key.startsWith("ibk_") && key.length >= 12) {
            "Enter an InstaBox API key beginning with ibk_. Create it in your InstaBox dashboard → API keys."
        }
        val connection = (URL("$API_BASE/machines").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            instanceFollowRedirects = false
            connectTimeout = 12_000
            readTimeout = 20_000
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-API-Key", key)
            setRequestProperty("Idempotency-Key", UUID.randomUUID().toString())
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(256_000) }.orEmpty()
            if (code == 401) {
                val errorCode = runCatching { JSONObject(body).optJSONObject("error")?.optString("code") }.getOrNull().orEmpty()
                throw IllegalStateException("InstaBox rejected this API key (401${if (errorCode.isNotBlank()) ": $errorCode" else ""}). Check that it is valid, not expired or revoked, and belongs to the intended workspace.")
            }
            if (code == 403) throw IllegalStateException("InstaBox authenticated the key but denied machine-list access (403). The key may be missing the required scope or this route may require a different account permission.")
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(body).optJSONObject("error")?.optString("message") }.getOrNull().orEmpty()
                throw IllegalStateException("InstaBox API returned HTTP $code${if (detail.isNotBlank()) ": ${detail.take(300)}" else ". Check https://status.instabox.sh and your workspace access."}")
            }
            val json = JSONObject(body)
            val array = when {
                json.opt("machines") is JSONArray -> json.optJSONArray("machines")
                json.opt("data") is JSONArray -> json.optJSONArray("data")
                else -> JSONArray()
            } ?: JSONArray()
            val machines = (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                InstaBoxMachine(id, item.optString("name", id), item.optString("status", item.optString("state", "unknown")))
            }
            val machineSummary = machines.take(8).joinToString("\n") { "• ${it.name} · ${it.status}" }
            val suffix = if (machines.size > 8) "\n…and ${machines.size - 8} more" else ""
            return InstaBoxAccountCheck(true, "Authenticated with InstaBox API · ${machines.size} machine(s) visible in this workspace." +
                if (machineSummary.isBlank()) "\nNo machines in this workspace yet." else "\n$machineSummary$suffix", machines)
        } finally { connection.disconnect() }
    }
}
