package com.ultron.assistant

/** Known OAuth/API starting points. Provider app registration, scopes and callback support remain provider-controlled. */
data class UltronProviderPreset(
    val id: String,
    val label: String,
    val authorizationUrl: String,
    val tokenUrl: String,
    val scope: String,
    val endpoint: String,
    val method: String = "GET",
    val extraAuthorizationParameters: String = "{}",
    val note: String
)

object UltronProviderPresets {
    val all = listOf(
        UltronProviderPreset(
            id = "google-drive", label = "Google Drive",
            authorizationUrl = "https://accounts.google.com/o/oauth2/v2/auth",
            tokenUrl = "https://oauth2.googleapis.com/token",
            scope = "https://www.googleapis.com/auth/drive",
            endpoint = "https://www.googleapis.com/drive/v3/files?q={query}&pageSize=20",
            extraAuthorizationParameters = "{\"access_type\":\"offline\",\"prompt\":\"consent\",\"include_granted_scopes\":\"true\"}",
            note = "Lists matching Drive files. Register an OAuth client and the exact ULTRON redirect URI; Drive scope is broad and sensitive."
        ),
        UltronProviderPreset(
            id = "google-calendar", label = "Google Calendar",
            authorizationUrl = "https://accounts.google.com/o/oauth2/v2/auth",
            tokenUrl = "https://oauth2.googleapis.com/token",
            scope = "https://www.googleapis.com/auth/calendar.events",
            endpoint = "https://www.googleapis.com/calendar/v3/calendars/primary/events?q={query}&maxResults=20",
            extraAuthorizationParameters = "{\"access_type\":\"offline\",\"prompt\":\"consent\",\"include_granted_scopes\":\"true\"}",
            note = "Searches the primary calendar events endpoint. Additional event-create/update endpoints must be configured separately."
        ),
        UltronProviderPreset(
            id = "github", label = "GitHub",
            authorizationUrl = "https://github.com/login/oauth/authorize",
            tokenUrl = "https://github.com/login/oauth/access_token",
            scope = "read:user user:email repo",
            endpoint = "https://api.github.com/user",
            extraAuthorizationParameters = "{}",
            note = "Connects the GitHub user endpoint. Repository, issue and pull-request actions need separate API operation endpoints and appropriate scopes."
        )
    )
}
