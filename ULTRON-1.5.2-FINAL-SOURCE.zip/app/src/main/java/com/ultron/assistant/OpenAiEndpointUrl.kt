package com.ultron.assistant

/** Normalizes gateway-root and OpenAI /v1 URLs without duplicating endpoint paths. */
object OpenAiEndpointUrl {
    fun chatCompletions(baseUrl: String): String {
        val base = baseUrl.trim().trimEnd('/')
        require(base.isNotBlank()) { "Enter the InstaBox gateway URL." }
        val parsed = java.net.URI(base)
        val path = parsed.path.orEmpty().trimEnd('/')
        return when {
            path.endsWith("/chat/completions", ignoreCase = true) -> base
            path.isBlank() || path == "/" -> "$base/v1/chat/completions"
            path.endsWith("/v1", ignoreCase = true) -> "$base/chat/completions"
            else -> "$base/chat/completions"
        }
    }
}
