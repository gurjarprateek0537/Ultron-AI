# Building ULTRON 1.5.0

Requirements: JDK 17, Gradle 8.9, Android SDK platform/build-tools 35, NDK 27.2.12479018 and CMake 3.22.1.

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

Install `app/build/outputs/apk/debug/app-debug.apk` on a compatible Android device. The app declares minSdk 26; Android 8.1 is API 27. Runtime behavior still depends on permissions, installed speech provider, device RAM and ColorOS background policy.

The CI workflow uploads `ULTRON-1.5.0-debug-apk` and `ultron-1.5.0-unit-test-reports`.

Do not treat a successful build as proof of wake-word accuracy, external API permissions, remote InstaBox worker availability or universal app automation. Test those on the target device and connected services.
