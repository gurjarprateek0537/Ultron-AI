# Building ULTRON 1.1.0

Open this project in Android Studio with JDK 17, Android SDK Platform 35, Android Build Tools 35, NDK 27.2.12479018 and CMake 3.22.1. The project does not include a Gradle wrapper; use a compatible installed Gradle 8.9 distribution or Android Studio's configured Gradle installation.

Run:

```bash
gradle --no-daemon :app:testDebugUnitTest
 gradle --no-daemon :app:assembleDebug
```

The source archive was integrity-checked and the coordinator Kotlin file was compiled independently with the installed Kotlin compiler. Full Android Gradle tests, APK compilation and physical-device testing were not run in the packaging environment because Android SDK/Gradle are unavailable.
