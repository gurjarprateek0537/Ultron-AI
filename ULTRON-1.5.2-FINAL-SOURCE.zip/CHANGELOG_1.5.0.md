# ULTRON 1.5.0 — Chat, gateway and integration reliability upgrade

## Implemented in this source update

- Added a chat-composer attachment action using Android's Storage Access Framework document picker. Text, Markdown, JSON, XML, PDF and image files are imported through the existing local text/OCR pipeline; extracted content is attached to the next prompt with a 24,000-character cap. The attachment is shown in the composer and can be removed before sending.
- Removed the Pause / Resume / Stop text row from the chat thinking state. Existing safe-boundary task-control infrastructure remains available to the agent/task layer.
- Removed the nonfunctional Online / Local / Hybrid buttons from the inference settings dialog. Saved routing remains in place; local-model management remains under Model Manager.
- Added OpenAI-compatible endpoint normalization: a gateway-root URL maps to `/v1/chat/completions`, a `/v1` base maps to `/v1/chat/completions`, and a full chat-completions URL is not duplicated.
- Increased bounded retry handling for transient 502/503/504 and transport I/O failures to five attempts with exponential backoff and longer connection/read timeouts. Final errors now explain that a gateway can be reachable while its remote sandbox/model worker is disconnected. The Android app cannot restart an external gateway worker.
- Simplified the Plugins landing screen to a Connect an account entry point; detailed website/API/OAuth setup is hidden until opened. Existing HTTPS REST execution, OAuth PKCE callback/token exchange and encrypted local credential storage are retained.
- Added conservative recognizer-truncation matching for `altron` and first-token `ultra` variants, plus shorter speech silence windows. Existing stale-callback suppression, watchdog, partial-result merge and bounded service recovery remain.
- Added JVM tests for gateway URL normalization and expanded wake-word matcher coverage.
- Bumped Android version to 1.5.0 (versionCode 30).

## Existing agent architecture retained

- 28 logical specialist roles, dynamic role selection and shared task state.
- General/Vision/Coding profiles and a single authoritative Android action executor.
- Vision observation before planning when a fresh screen capture is explicitly shared.
- Multi-model All-in-One parallel first pass, peer review and General-role synthesis when at least two online profiles are configured and the user enables that mode.

These are logical specialist roles, not 28 independent LLM instances. The specialist registry and coordinator do not provide a production MCP/A2A network or guarantee that every role independently invokes a model on every request.

## Verification boundary

This archive has not been built with Gradle/Android SDK/NDK in this authoring environment, and no APK has been assembled from this exact 1.5.0 source. Pure Kotlin wake-word and endpoint-normalization smoke checks are run separately where possible. GitHub Actions and OPPO CPH1803 physical-device verification are still required. A five-attempt client retry cannot repair an actually disconnected remote sandbox worker; the gateway operator must restore that service.
