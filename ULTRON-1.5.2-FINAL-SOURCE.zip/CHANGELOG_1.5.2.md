# ULTRON 1.5.2

## Implementation changes

- Added `UltronAgentCollaborationRuntime`: selected logical specialists now execute bounded role-specific inference calls in ordered observation, planning, and review phases. Successful findings from each phase are passed to the next phase and then to the single central General planner.
- Kept the 28 specialist registry and made the selector cover all 28 roles across relevant task types. Per-request execution remains resource-bounded; not all 28 run for every command. The role workers reuse the three configured General, Vision, and Coding profiles and are not 28 separate model deployments.
- Specialist workers are analysis-only. The central planner authors the action plan and `UltronAgentExecutor` remains the only Android action executor. Existing fresh-screen inspection, action validation, verification, approval, and recovery behavior is preserved.
- Improved wake-phrase handling to evaluate all recognizer alternatives, merge a wake-word partial with a shorter final hypothesis, recognize common split/truncated variants, and retain a useful partial when an older Android speech service returns `NO_MATCH` or `SPEECH_TIMEOUT`.
- Added a consented experimental voice-familiarity profile. Three samples produce an encrypted acoustic descriptor; raw recordings are discarded. This is not a trained speaker embedding or secure speaker authenticator and must never unlock Android or approve sensitive actions.
- Added Google Drive, Google Calendar, and GitHub connection presets; OAuth provider-specific authorization parameters; visible endpoint testing; and clearer connected/authorization state. Tokens continue to be encrypted using Android Keystore and OAuth PKCE/state validation remains in use.
- Clarified in the UI that one saved integration currently represents one configured API endpoint/action. Additional resource operations require additional endpoint configuration and provider-granted scopes.
- Removed the custom GIF upload/picker option. The bundled ULTRON GIF is the fixed asset, displayed crop-to-fill in the Voice and Dashboard cards and full-screen on startup. Dashboard ring overlays are removed.
- Retained chat document attachments, on-device extraction, and the attachment action in the prompt composer. Enhanced chat bubbles and input styling are retained.
- Updated source version metadata and CI artifact labels to 1.5.2.
- Corrected the action preflight so opening “Purchase history” is treated as read-only navigation rather than a purchase commitment; added a regression test.
- Bounded model import/download to 16 GiB, added a finite network read timeout and HTTPS-only redirect validation, made failed redirect negotiation close its connection, and assigned unique staging files to concurrent import/download operations. Model replacement is recoverable so a failed update does not discard the previously installed GGUF.
- Converted JNI model text through explicit UTF-16/UTF-8 routines so Hindi and supplementary Unicode characters are not corrupted by JNI Modified UTF-8 handling.
- Corrected microphone foreground-service type selection to API 30+, where Android introduced that type, and added API 29/30 boundary coverage.

## Explicit non-goals / safety restrictions

- No voice-based bypass of Android's secure lock screen. Voice similarity is not authentication; Android BiometricPrompt/device credential remains the security boundary.
- No covert/secret remote camera or microphone recording. Any future remote assistance capture must be visible, explicitly user-authorized, time-limited, permissioned, and auditable.
- No root access, hidden system permission grants, or unrestricted control of protected Android settings.
