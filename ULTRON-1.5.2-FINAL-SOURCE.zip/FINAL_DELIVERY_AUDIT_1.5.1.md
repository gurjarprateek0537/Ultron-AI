# ULTRON 1.5.1 — Source Delivery Audit

## Changes
- Dashboard hero uses the animated GIF instead of the still hero image.
- Dashboard rotating circle/ring overlays removed.
- Voice core GIF is displayed in a wider crop-to-fill panel; the rotating rings were removed.
- Added a GIF document picker on the Voice screen. Persisted SAF read permission and selected URI are shared by Voice, Dashboard and startup splash. Bundled GIF fallback remains.
- Startup splash now renders the GIF edge-to-edge/full-screen behind the startup text.

## Checks
- Source ZIP integrity checked after packaging.
- Existing 1.5.0 core checks remain documented in FINAL_DELIVERY_AUDIT_1.5.0.md.

## Not performed
- No Gradle unit-test or assembleDebug run for this exact 1.5.1 source.
- No emulator or OPPO CPH1803 device test.
- GIF picker persistence, full-screen crop framing, performance, memory use and frame playback need device verification.
- This update does not fix remote InstaBox sandbox-worker disconnects.
- The 28 specialist roles remain logical routing roles, not 28 independent LLMs.
