# Building ULTRON 1.2.0

## Toolchain

- Android Studio with JDK 17
- Android SDK Platform 35 and Build Tools 35.0.0
- NDK 27.2.12479018
- CMake 3.22.1
- Gradle 8.9

The source ZIP intentionally does not bundle a Gradle wrapper. Open the extracted root in Android Studio or run with a compatible Gradle 8.9 installation:

```bash
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:assembleDebug
```

The CI workflow at `.github/workflows/android.yml` installs the pinned SDK/NDK/CMake packages, runs the JVM unit tests and assembles the debug APK. The expected APK path is `app/build/outputs/apk/debug/app-debug.apk`.

## Device compatibility

The configured minSdk is 26 (Android 8.0+); the target phone OPPO CPH1803 on Android 8.1/API 27 meets the declared minimum. This does not guarantee every capability is available: Accessibility, microphone, notifications, camera, screen capture, Modify System Settings, Device Admin and Storage Access Framework access each require their corresponding user grant or Android support. ColorOS autostart/battery policies can stop foreground or scheduled work.

## Testing before installation

1. Run the complete CI workflow and review unit-test reports.
2. Install the debug APK on the actual phone.
3. Check the permission/health dashboard, wake-word service lifecycle, screen capture, basic device controls, accessibility and app workflows.
4. Verify that message sending, calls, purchases, destructive file operations and other external commitments are blocked until their exact action is explicitly approved.
5. Test pause/resume/stop, including immediately resuming a just-requested pause, interrupted-task resume-by-replanning, and screen changes in several third-party apps.
6. Verify battery-aware/offline resource selection, and inspect the Agent diagnostics after verified, unverified, failed and recovery actions.

No APK or physical-device test is claimed by this source-only delivery. See `IMPLEMENTATION_STATUS.md` for detailed feature boundaries.
