# ULTRON 1.5.2 — implementation and verification audit

## Scope

This archive is based on the supplied ULTRON 1.5.1 source and preserves its Android app structure, current assets, three model-profile design, plugin store, document ingestion/retrieval, vision entry points, and existing task executor.

## What changed

### Multi-agent runtime

- 28 named specialist roles are present in `UltronMultiAgentCoordinator`.
- The selector can select every registered role for at least one relevant task type (smoke-tested against all 28 enum values).
- Selected roles are partitioned into ordered execution phases. The phase partition smoke check verifies no selected role is duplicated or omitted.
- `UltronAgentCollaborationRuntime` invokes actual `InferenceRepository.completeProfile` calls for selected workers when Online/Hybrid remote execution is available. It limits parallelism to at most three calls, caps each worker output, enforces phase deadlines, passes completed earlier-phase findings to later phases, and returns failures rather than claiming an unavailable worker succeeded.
- The General profile remains the central planner. Specialists cannot execute phone actions. `UltronAgentExecutor` remains the sole validated Android executor.
- Resource budgets select a relevant subset for each request. All 28 roles are available across supported request classes, but not all 28 are called for every request. Only three configured General/Vision/Coding model profiles are reused; this is not 28 independent model endpoints.
- Local-only mode skips remote specialist fan-out and continues with the configured local planner.

### Phone control

The source already contained a closed-loop task executor with fresh accessibility snapshots, screen-generation/fingerprint checks, app/window settling, stale-node prevention, bounded recovery, action verification, pause/resume/cancel handling, and high-impact action approval. This version preserves that implementation and routes specialist analysis into the planner. No new claim is made that every third-party app, protected screen, or system setting can be controlled: Android/OEM restrictions still apply.

### Voice and speaker familiarity

- Wake-word improvements affect the existing Android `SpeechRecognizer` pipeline: all returned alternatives are considered, partials are retained more carefully, common recognizer variants are accepted, and useful partial wake matches can survive some no-match/time-out callbacks.
- The listener still uses session-based Android `SpeechRecognizer`, not a dedicated continuously-running acoustic hotword model such as a separately licensed/packaged keyword engine. Provider availability, noise, latency, network behavior and ColorOS battery/service policy can still cause missed detections. Device testing is required.
- Experimental speaker familiarity stores only an encrypted spectral descriptor derived from three consented recordings. It is not a trained speaker-identification model, has no validated false-accept/false-reject rates, and must not be used as owner authentication.
- Secure device unlock is not bypassed. Android biometric/device-credential APIs remain required.
- Covert remote recording is not implemented. Future capture/remote-assistance features must be visible, consented and time-limited.

### Plugins and accounts

- Existing custom REST and OAuth 2.0 authorization-code + PKCE foundations are retained, including encrypted local credential storage, OAuth state validation and refresh-token support where a provider supplies one.
- Added provider presets for Google Drive, Google Calendar and GitHub, extra authorization parameters (for example offline consent), and an endpoint test action.
- These are configuration starting points, not turnkey universal account control. The owner must register/configure provider OAuth applications, client IDs, allowed redirect URIs and scopes. Each saved integration currently maps to one API endpoint/action. Read/create/edit/delete access exists only where the service API exposes the operation and the granted scope allows it; further endpoints/actions must be configured separately.
- Browser-only websites without usable APIs need a separate, visible UI automation skill; no blanket full access is claimed.

### Knowledge, documents and vision

- Existing local document ingestion supports text/Markdown/JSON/XML, PDFs (limited extraction/OCR path) and images via the existing OCR/vision components. Existing lexical retrieval is retained.
- This version does not add a vector database or semantic embedding model. It should not be described as full vector RAG.
- Existing vision capture remains on-demand and subject to Android capture permission. Cloud sharing remains separately opt-in. Secure app windows can remain blank.

### Interface and GIF

- Removed the selectable/upload GIF UI. The bundled GIF is now the fixed core asset.
- Voice and dashboard cards use crop-to-fill rendering; dashboard rotating ring overlays are removed; startup GIF rendering fills the splash container/screen.
- Retained chat attachment selection and local text extraction, and improved message-bubble/input presentation.


## Final source-audit fixes

The final fixed source archive includes these additional corrections after the earlier CI test failure review:

- The main action safety policy and the dry-run simulator now agree that **Purchase history** is read-only navigation. The simulator no longer labels that navigation as a payment/purchase commitment, and `UltronActionSimulationTest` contains a regression case. The earlier wake-phrase start-of-utterance fix remains included.
- Local GGUF import and download now reject files over 16 GiB, validate the GGUF signature after copying, use a finite 120-second network read timeout, and manually allow at most five HTTPS-only redirects. This prevents unbounded file growth, reduces indefinite stalled reads, and blocks HTTPS-to-HTTP redirect downgrade. Failed redirect negotiation now disconnects its candidate connection.
- Each simultaneous GGUF import/download gets a unique staging file, avoiding collisions where overlapping operations could truncate or delete one another's partial data. Replacing the active GGUF stages and validates the new file before changing the selected model. A backup/restore path preserves the old file when the replacement or settings write fails, and recovers an interrupted two-file swap on the next model-path lookup.
- JNI text conversion now explicitly converts Java UTF-16 to standard UTF-8 for llama.cpp and generated UTF-8 back to Java UTF-16. This avoids relying on JNI Modified UTF-8 for Hindi and supplementary Unicode such as emoji.
- Corrected the cumulative implementation-status note: the 1.5.1 GIF picker is historical; 1.5.2 intentionally removes selectable/upload GIF functionality and uses the bundled fixed asset.
- The wake-word foreground service now passes Android’s microphone service-type flag only from API 30 (the API where the flag was introduced); API 26–29 use the original two-argument `startForeground` overload. A new API 29/30 boundary test covers this selection.

## Supplemental checks for the final fixed archive

- All 91 `@Test` methods across all 17 project JVM test classes ran in an isolated Kotlin/JVM harness; all 91 passed. It used the project logic sources directly where they are standalone and small compatibility stubs for Android-dependent action/planner/report wrappers; the inference-mode, model-profile routing and context-budget declarations were compiled from their exact source sections. This is not the official Gradle/JUnit task and does not replace GitHub Actions.
- `NativeLlamaRuntime.kt` compiled with the standalone Kotlin compiler against minimal Android API stubs.
- GGUF copy/validation, zero-length stream fallback, active-model replacement, and interrupted-swap recovery passed focused storage smoke tests. Per-operation temporary filenames were added in the final review to remove overlapping-import/download collisions.
- The complete `ultron_llama.cpp` translation unit passed a strict host C++ syntax check with JNI headers and local declarations for the llama.cpp API. This is not an Android NDK cross-compile or linker test; the native library still needs the CI build.
- The prior GitHub Actions run reported two failing tests: the “Purchase history” safety boundary and the mid-sentence wake-word fallback. Both source conditions are corrected here, and a regression test was added for the simulator. This fixed archive has not yet been pushed or run through a fresh GitHub Actions job.

## Tests performed in this environment

- `UltronWakeWordPhrase.kt` compiled with standalone Kotlin compiler and wake-phrase smoke checks passed (`WAKE_WORD_SMOKE_OK`).
- `UltronMultiAgentCoordinator.kt` compiled with test stubs and selector/phase smoke checks passed (`AGENT_SELECTION_SMOKE_OK roles=28`).
- `UltronAgentCollaborationRuntime.kt` compiled with lightweight dependency stubs and a fake inference repository; bounded multi-phase worker smoke check passed (`AGENT_RUNTIME_SMOKE_OK`). This is a runtime-logic smoke test, not a live provider integration test.
- `UltronProviderPresets.kt` compiled with standalone Kotlin compiler.
- Android XML resources and manifest parsed successfully.
- ZIP integrity was checked after packaging.

## Not verified

- Full Android Gradle compile, JVM JUnit test suite, native C/C++ build, APK assembly, signing, installation, or runtime behavior on OPPO CPH1803 were not performed in this environment. There is no Android SDK/platform jar, Gradle executable/wrapper, or ADB available in the current runtime.
- No live InstaBox gateway request or sandbox service recovery was performed. The 502/sandbox-disconnected error is not claimed fixed; this source can only report the remote-provider failure and use bounded retry/fallback logic that existed in the supplied source.
- No real-world voice enrollment accuracy or wake-word hit-rate test was performed. The experimental speaker descriptor is not security-grade.
- OAuth presets were not connected to real provider accounts. Provider callback registration and API scope approval remain required.

## Reproducible CI build

The included GitHub Actions workflow uses JDK 17, Android platform/build-tools 35, NDK 27.2.12479018, CMake 3.22.1, and Gradle 8.9. On a connected GitHub Actions runner, run `:app:testDebugUnitTest` and `:app:assembleDebug`. A successful run against this exact archive/commit is required before describing an APK as built.
