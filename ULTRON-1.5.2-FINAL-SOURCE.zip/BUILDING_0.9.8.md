# Building ULTRON 0.9.8

Requirements: JDK 17, Gradle 8.9, Android SDK platform/build-tools 35, NDK 27.2.12479018 and CMake 3.22.1.

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

The CI workflow is `.github/workflows/android.yml`. It uploads test reports and the `ULTRON-0.9.8-debug-apk` artifact.

## Device acceptance tests
1. Enable microphone, notification and Accessibility permissions; test wake-only, wake-plus-command, no-match recovery, recognizer-busy recovery and a 10-minute standby session.
2. Test multi-step tasks on Instagram, Chrome, Settings and an unfamiliar app. Include icon-only controls, search, same-app page transitions, cross-app navigation and ambiguous duplicate names.
3. Confirm the planner receives fresh semantic snapshots and never reuses stale bounds after a screen-generation change.
4. Test alarm handoff, volume readback, screen lock/power menu restrictions and the sensitive-action approval flow.
5. Verify local mode screen context stays on-device; Online/Hybrid modes withhold screen contents under the current privacy behavior.

## Known limits
The source cannot guarantee access to secure windows, inaccessible app content, hidden controls, OEM-killed background services or actions blocked by Android permissions. Android 8.1 does not provide the Accessibility screenshot API used for local screen OCR on Android 11+, so visual interpretation on API 27 is limited to what the accessibility tree exposes.

**Build status for this archive:** source-level checks and ZIP integrity can be performed here, but no Android SDK/Gradle installation is available in this environment; no APK build or device test is claimed.
