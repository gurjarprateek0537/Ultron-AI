# Building ULTRON 1.5.2

The included GitHub Actions workflow `.github/workflows/android.yml` is configured to use:

- Temurin JDK 17
- Android platform 35 and Build Tools 35.0.0
- NDK 27.2.12479018
- CMake 3.22.1
- Gradle 8.9

It runs the JVM unit tests and assembles a debug APK:

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

The expected debug APK path is:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The workflow uploads `ULTRON-1.5.2-debug-apk` and `ultron-1.5.2-unit-test-reports` artifacts. A green run must be performed against this exact source commit before the APK is described as verified.

## Current environment limitations

This authoring runtime has no Gradle executable/wrapper, Android SDK platform, or ADB. Therefore no full Android compile, JUnit run, NDK build, APK assembly, install, or OPPO CPH1803 runtime test has been performed for this archive. See `ULTRON_1.5.2_IMPLEMENTATION_AUDIT.md` for the exact limited checks that did pass.
