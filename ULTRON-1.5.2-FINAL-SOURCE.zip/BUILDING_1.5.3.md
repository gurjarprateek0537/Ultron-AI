# Building ULTRON 1.5.3

## Requirements

- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- NDK 27.2.12479018
- CMake 3.22.1
- Gradle 8.9

## Build and test

From the extracted project root:

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

The included `.github/workflows/android.yml` runs those commands on GitHub Actions and uploads the `ULTRON-1.5.3-debug-apk` and unit-test reports. Upload this source archive's contents to the repository root (or extract the ZIP into the checked-out project root) before running the workflow.

## Verification caveat

This source was not built with the Android Gradle/NDK toolchain in the current authoring environment. A green GitHub Actions run against this exact 1.5.3 source is required before calling an APK build verified. A live InstaBox API key is also required to verify authentication; no key is included in this archive. Device testing is still required for ColorOS wake-word behavior and acoustic speaker resemblance.
